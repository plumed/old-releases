#!/bin/bash
#
#  Patch to interface DL_POLY_2.16 with the PluMeD plugin
#  The patched files are:
#     config_module.f
#     define_system_module.f
#     forces_module.f
#     dlpoly.f 
#
#  Example of an alternative way to patch dlpoly 2.16 with the PluMeD plugin and compile it with gfortran and gcc
#  
#  put in a directory the dlpoly tar file (dl_poly_2.16.tar.gz) and
#  the PluMeD directory (here named plumed) then use the following command sequence:
#  
#  tar zxf dl_poly_2.16.tar.gz
#  export plumedir=${PWD}/plumed
#  cd dl_poly_2.16
#  $plumedir/patches/plumedpatch_dlpoly_2.16.sh -patch
#  cp build/MakeSEQ srcf90/Makefile
#  cd srcf90
#  make gfortran
#
#  Have fun!
#

if [ "$#" -eq 0 ];then
  echo "USAGE :"
  echo "./plumedpatch_dlpoly_2.16.sh  (-patch) (-revert)   "
  echo " -patch  : apply PluMeD patch "
  echo " -revert : revert code to original "
  exit
elif [ "$#" -eq 1  ];then
  if [ "$1" =  "-patch" ] ; then
    cd srcf90


    file="dlpoly.f"
    if  [ -e "${file}.premeta" ];
    then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** dlpoly.f.bak	Wed May 28 10:28:58 2008
--- dlpoly.f	Wed May 28 10:35:42 2008
***************
*** 94,99 ****
--- 94,105 ----
        real*8, allocatable :: tbuffer(:)
        
  CFFTW      pointer fplan, bplan 
+ 
+ c PluMeD variables
+       logical lplumed
+       character(len=20) :: plumedfile
+       character(len=80) :: parse_file
+ c end PluMeD variables
        
        integer fplan, bplan
        
***************
*** 170,176 ****
       x  keytrj,kmax1,kmax2,kmax3,multt,nstack,nstbgr,nstbpo,nhko,
       x  nlatt,nstbts,nsteql,nstraj,nstrun,nospl,fplan,bplan,alpha,
       x  delr,epsq,fmax,press,quattol,rcut,rprim,rvdw,taup,taut,temp,
!      x  timcls,timjob,tolnce,tstep)
        
  c     input the system force field
        
--- 176,182 ----
       x  keytrj,kmax1,kmax2,kmax3,multt,nstack,nstbgr,nstbpo,nhko,
       x  nlatt,nstbts,nsteql,nstraj,nstrun,nospl,fplan,bplan,alpha,
       x  delr,epsq,fmax,press,quattol,rcut,rprim,rvdw,taup,taut,temp,
!      x  timcls,timjob,tolnce,tstep,lplumed,plumedfile,parse_file)
        
  c     input the system force field
        
***************
*** 209,214 ****
--- 264,280 ----
       x  nstep,numacc,numrdf,ntpatm,ntpmet,nzden,chip,chit,
       x  conint,elrc,engunit,virlrc,rvdw,volm,virtot,vircom)
        
+ c PluMeD modifications
+       if(idnode==0 .and. lplumed)then
+         call init_metadyn
+      x (natms, tstep, weight, chge, imcon, engunit,
+      x  trim(plumedfile)//char(0))
+         write(nrite,'(/a22)' )"-- PLUMED ENABLED --  "
+         write(nrite,'(a22,a)')"   PLUMED INPUT FILE: ",trim(plumedfile)
+         call flush(nrite)
+       endif
+ c end PluMeD modifications
+ 
  c     kinetic stress tensor at start
        
        if(keyver.gt.0.and.nstep.eq.0)then
***************
*** 554,559 ****
--- 566,578 ----
            
            if(keyfld.gt.0) call extnfld
       x      (idnode,imcon,keyfld,mxnode,natms,engfld,virfld)
+ 
+ c PluMeD modifications
+           if(lplumed)then  
+              call 
+      c       meta_force_calculation(cell,nstep,xxx,yyy,zzz,fxx,fyy,fzz)
+           endif  
+ c end PluMeD modifications
            
  c     global summation of force arrays (basic replicated data strategy)
EOF
      patch -c -l -b --suffix=.premeta ${file}  < ${file}.patch
      rm -rf ${file}.patch 
    fi 
    #
    # define_system.f 
    #
    file="define_system.f"
    if  [ -e "${file}.premeta" ];
    then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** define_system.f	Wed May 28 10:28:39 2008
--- define_system.f.meta	Wed May 28 10:45:19 2008
***************
*** 4,10 ****
       x  keytrj,kmax1,kmax2,kmax3,multt,nstack,nstbgr,nstbpo,nhko,
       x  nlatt,nstbts,nsteql,nstraj,nstrun,nospl,fplan,bplan,alpha,
       x  delr,epsq,fmax,press,quattol,rcut,rprim,rvdw,taup,taut,temp,
!      x  timcls,timjob,tolnce,tstep)
        
  c***********************************************************************
  c     
--- 4,10 ----
       x  keytrj,kmax1,kmax2,kmax3,multt,nstack,nstbgr,nstbpo,nhko,
       x  nlatt,nstbts,nsteql,nstraj,nstrun,nospl,fplan,bplan,alpha,
       x  delr,epsq,fmax,press,quattol,rcut,rprim,rvdw,taup,taut,temp,
!      x  timcls,timjob,tolnce,tstep,lplumed,plumedfile,parse_file)
        
  c***********************************************************************
  c     
***************
*** 70,75 ****
--- 70,83 ----
        logical lstep,ltemp,lcut,ldelr,lprim,lforc,lens,lvdw,lrvdw,kill
        logical lnsq,lzden,lewald,lspme,lhke,loop,findstring
  
+ c PluMeD variables
+       logical lplumed
+       character(len=20) :: plumedfile
+       character(len=80) :: parse_file
+       integer :: i
+       plumedfile="plumed.dat"
+ c end  PluMeD variables
+ 
        data blank/'                    '/
  CVAM
  CVAM      call VTBEGIN(3, ierr)
***************
*** 141,146 ****
--- 145,155 ----
        lnsq=.false.
        lzden=.false.
  
+ c PluMeD defaults
+       lplumed   = .false.
+       plumedfile="plumed.dat"
+ c PluMeD defaults
+ 
  c     open the simulation input file
        
        if(idnode.eq.0) open(nread,file='CONTROL',status='old')
***************
*** 174,179 ****
--- 182,201 ----
          
          if(record(1).eq.'#'.or.record(1).eq.' ') then
  
+ c PluMeD modifications
+ 
+         elseif(findstring('plumed ',directive,idum)) then
+              if(findstring('on',directive,idum) ) lplumed=.true.
+              if(findstring('off',directive,idum)) lplumed=.false.
+ 
+         elseif(findstring('plumedfile',directive,idum)) then
+              do i=1,80
+                parse_file(i:i)=record(i)
+              enddo
+              read(parse_file,*)plumedfile,plumedfile
+ 
+ c end PluMeD modifications
+ 
  c     record is commented out
  
          elseif(findstring('steps',directive,idum))then
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch 
    fi 

    # link PluMeD files from common_files directory into Plumed
    mkdir Plumed ; cd Plumed
    ln -s ${plumedir}/common_files/*.h ./
    ln -s ${plumedir}/common_files/*.c ./
    cd ../

    # Patch makefiles
    cd ../build
    file="MakeSEQ"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** ../build/MakeSEQ.premeta    2006-02-15 18:48:28.000000000 +0800
--- Makefile    2008-10-27 15:05:59.000000000 +0900
***************
*** 55,60 ****
--- 55,83 ----
  
  OBJ_PAR = serial.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o 
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 90,95 ****
--- 113,124 ----
        FFLAGS="-c -dp -O3,aggress,unroll2,nojump" \
        EX=$(EX) BINROOT=$(BINROOT) $(TYPE)
  
+ #========== GNU Fortran =================================================
+ gfortran:
+ 	$(MAKE) LD="gfortran -o" LDFLAGS="" FC=gfortran \
+ 	FFLAGS="-c -O2 -ffast-math" \
+ 	EX=$(EX) BINROOT=$(BINROOT) $(TYPE)
+ 
  #============= MacOSX (Darwin) version: derived from AIX ===============
  macosx: 
        $(MAKE) FC=xlf FFLAGS="-c -O3 -qstrict -qipa -qarch=g5 -qnosave" \
***************
*** 205,227 ****
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  #=====================================================================
--- 233,255 ----
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 236,242 ****
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
!       $(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
--- 264,270 ----
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) $(OBJ_METAD) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
***************
*** 244,250 ****
        $(FC) $(FFLAGS) $*.f
  
  .c.o: 
!       $(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 272,278 ----
        $(FC) $(FFLAGS) $*.f
  
  .c.o: 
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi

    file="MakePAR"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** MakePAR.premeta     2006-02-15 18:48:28.000000000 +0800
--- makefile    2008-10-27 15:16:00.000000000 +0900
***************
*** 55,60 ****
--- 55,83 ----
  
  OBJ_PAR = basic_comms.o merge_tools.o pass_tools.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o 
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 114,136 ****
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV)
        mv $(EX) $(EXE)
  
  #=====================================================================
--- 137,159 ----
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) $(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR) \
!	 $(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 145,151 ****
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
--- 168,174 ----
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) $(OBJ_METAD) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
***************
*** 153,159 ****
        $(FC) $(FFLAGS) $*.f
  
  .c.o: 
! 	$(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 176,182 ----
        $(FC) $(FFLAGS) $*.f
  
  .c.o: 
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi

    file="MakeWIN"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** MakeWIN.premeta     2006-02-15 18:48:28.000000000 +0800
--- makefile    2008-10-27 15:19:40.000000000 +0900
***************
*** 55,60 ****
--- 55,83 ----
  
  OBJ_PAR = serial.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o 
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 77,99 ****
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR)\
        mv $(EX) $(EXE)
  
  #=====================================================================
--- 100,122 ----
  
  # Default code. Force tables interpolation in r-space 3pt interpolation
  3pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in r-space, 4pt interpolation
  4pt: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_4PT) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  # Force tables interpolation in  r-squared
  rsq: check $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_METAD)
        $(LD) /exe:$(EX) $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RSQ) \
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_PAR) $(OBJ_METAD)
        mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 108,114 ****
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
--- 131,137 ----
  # Clean up the source directory
  clean:
        rm -f $(OBJ_MOD) $(OBJ_ALL) $(OBJ_RRR) $(OBJ_PAR)\
! 	$(OBJ_LF) $(OBJ_VV) $(OBJ_RSQ) $(OBJ_4PT) $(OBJ_METAD) *.mod
  
  #=====================================================================
  # Declare dependencies : c preprocess all .f files
***************
*** 116,122 ****
        $(FC) $(FFLAGS) $*.f
        mv $*.obj $*.o
  .c.o: 
!       $(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 139,145 ----
        $(FC) $(FFLAGS) $*.f
        mv $*.obj $*.o
  .c.o: 
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi
    cd ../
  elif [ "$1" =  "-revert" ] ; then
    echo "REVERTING TO OLD FILES:"
    cd srcf90
    for file in config_module.f define_system_module.f forces_module.f dlpoly.f ; do
      if  [ -e "${file}.premeta" ];   
      then
        echo "REVERTING ${file}"
        mv ${file}.premeta ${file}
      else
        echo "IT LOOKS YOU DON'T HAVE A BACKUP FILE of ${file} (maybe you never patched)"
      fi
    done
    # remove PluMeD files from current directory 
    rm -fr Plumed

    # Makefiles
    cd ../build
    for file in MakeSEQ MakePAR MakeWIN ; do
      if  [ -e "${file}.premeta" ];   
      then
        echo "REVERTING ${file}"
        mv ${file}.premeta ${file}
      else
        echo "IT LOOKS YOU DON'T HAVE A BACKUP FILE of ${file} (maybe you never patched)"
      fi
    done
    cd ../

  else
    echo "WRONG KEYWORD "
    echo "USAGE :"
    echo "./plumedpatch_dlpoly_2.16.sh  (-patch) (-revert)   "
    echo " -patch  : apply PluMeD patch "
    echo " -revert : revert code to original "
    exit
  fi
fi
