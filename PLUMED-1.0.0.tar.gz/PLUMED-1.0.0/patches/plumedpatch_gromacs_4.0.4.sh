#!/bin/bash
#
# PluMeD patch for gromacs 4.0.4 
#
plumedir="/Users/max/build/PLUMED/md_meta"
found_flag=0 
if [ "$#" -eq 0 ];
then
 echo "USAGE :"
 echo "./plumedpatch_gromacs_4.0.4.sh  (-patch) (-revert)   "
 echo " -patch  : apply PluMeD patch " 
 echo " -revert : revert code to original "
 exit
elif [ "$#" -eq 1  ]
   then 
   if [ "$1" =  "-patch" ] ; then
         found_flag=1
   #
   # link metadynamics file from  directory 
   #
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS | grep -v rex`
        do
            ln -s ${plumedir}/common_files/$i ./src/kernel/$i
        done
   #
   # Patch kernel files 
   # 
        cd src/kernel 
   #
   # md.c 
   # 
        file="md.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** /share/home33/carlo/Download/gromacs-4.0.2/src/kernel/md.c	2008-11-07 18:16:02.000000000 +0100
--- md.c	2008-11-11 10:27:37.000000000 +0100
***************
*** 86,93 ****
--- 86,97 ----
  #ifdef GMX_MPI
  #include <mpi.h>
  #endif
  
+ // Carlo Wed Oct 10 14:37:58 CEST 2007 
+ // // to include metadynamics routine
+ #include "metadyn.h"
+ 
  /* The following two variables and the signal_handler function
   * is used from pme.c as well 
   */
  extern bool bGotTermSignal, bGotUsr1Signal;
***************
*** 814,821 ****
--- 818,835 ----
    } else {
      scale_tot = NULL;
    }
  
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Initialize stuff for metadynamics and replica-methods */
+   if(MASTER(cr)&&logical.meta_inp) {
+     /* Initialize metadynamics */
+     init_metadyn(mdatoms->nr, state->box, ir->ePBC,  mdatoms->chargeA, mdatoms->massT,
+                  ir->delta_t, (repl_ex_nst>0?repl_ex_nst:-1), 
+                 (repl_ex_nst>0?repl_ex->repl:-1), (repl_ex_nst>0?repl_ex->nrepl:1), 
+                 (repl_ex_nst>0?repl_ex->q[0]:0), (repl_ex_nst>0?repl_ex->q[repl_ex->repl]:0), cr, fplog);
+   }
+ 
    /* Write start time */
    start_t=print_date_and_time(fplog,cr->nodeid,"Started mdrun");
    wallcycle_start(wcycle,ewcRUN);
    if (fplog)
***************
*** 1087,1094 ****
--- 1101,1125 ----
  	       state->lambda,graph,
  	       fr,vsite,mu_tot,t,fp_field,ed,
  	       GMX_FORCE_STATECHANGED | (bNS ? GMX_FORCE_NS : 0) |
  	       GMX_FORCE_ALLFORCES);
+ 
+       // Carlo Wed Oct 10 14:37:58 CEST 2007 
+       // Metadynamics forces
+       if(MASTER(cr)&&logical.meta_inp) {
+         if(colvar.nconst>0) {
+           rvec *meta_force;
+           snew(meta_force, mdatoms->nr);
+           meta_force_calculation(state->x, meta_force, state->v, state->box, step);
+           int iii;
+           for(iii=0;iii<mdatoms->nr;iii++) {
+             f[iii][0] += meta_force[iii][0];
+             f[iii][1] += meta_force[iii][1];
+             f[iii][2] += meta_force[iii][2];
+           }
+           sfree(meta_force);
+         }
+       }
      }
  
      GMX_BARRIER(cr->mpi_comm_mygroup);
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # Patch the 
   # 
        file="repl_ex.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** repl_ex.c.premeta	Wed Feb  4 10:18:38 2009
--- repl_ex.c	Mon Feb 23 13:53:53 2009
***************
*** 51,71 ****
  #include "domdec.h"
  #include "partdec.h"
  
! typedef struct gmx_repl_ex {
!   int  repl;
!   int  nrepl;
!   real temp;
!   int  type;
!   real *q;
!   bool bNPT;
!   real *pres;
!   int  *ind;
!   int  nst;
!   int  seed;
!   int  nattempt[2];
!   real *prob_sum;
!   int  *nexchange;
! } t_gmx_repl_ex;
  
  enum { ereTEMP, ereLAMBDA, ereNR };
  char *erename[ereNR] = { "temperature", "lambda" };
--- 51,59 ----
  #include "domdec.h"
  #include "partdec.h"
  
! // Carlo Wed Oct 10 14:37:58 CEST 2007 
! // to include metadynamics variables
! #include "metadyn.h"
  
  enum { ereTEMP, ereLAMBDA, ereNR };
  char *erename[ereNR] = { "temperature", "lambda" };
***************
*** 81,89 ****
    qall[re->repl] = q;
    gmx_sum_sim(ms->nsim,qall,ms);
  
!   bDiff = FALSE;
!   for(s=1; s<ms->nsim; s++)
!     if (qall[s] != qall[0])
        bDiff = TRUE;
  
    if (bDiff) {
--- 69,77 ----
    qall[re->repl] = q;
    gmx_sum_sim(ms->nsim,qall,ms);
  
! //  bDiff = FALSE;
! //  for(s=1; s<ms->nsim; s++)
! //    if (qall[s] != qall[0])
        bDiff = TRUE;
  
    if (bDiff) {
***************
*** 149,160 ****
      case ereTEMP:
        repl_quantity(fplog,ms,re,i,re->temp);
        break;
!     case ereLAMBDA:
!       if (ir->efep != efepNO)
! 	repl_quantity(fplog,ms,re,i,ir->init_lambda);
!       break;
!     default:
!       gmx_incons("Unknown replica exchange quantity");
      }
    }
    if (re->type == -1)
--- 137,148 ----
      case ereTEMP:
        repl_quantity(fplog,ms,re,i,re->temp);
        break;
! //    case ereLAMBDA:
! //      if (ir->efep != efepNO)
! //	repl_quantity(fplog,ms,re,i,ir->init_lambda);
! //      break;
! //    default:
!  //     gmx_incons("Unknown replica exchange quantity");
      }
    }
    if (re->type == -1)
***************
*** 197,202 ****
--- 185,195 ----
    /* Make an index for increasing temperature order */
    for(i=0; i<re->nrepl; i++)
      re->ind[i] = i;
+ 
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* This code is commented out to permit replicas with same temperature */
+   /* It's usefull for Replica Metadynamics (Laio's way) */
+   /*
    for(i=0; i<re->nrepl; i++) {
      for(j=i+1; j<re->nrepl; j++) {
        if (re->q[re->ind[j]] < re->q[re->ind[i]]) {
***************
*** 208,213 ****
--- 201,207 ----
        }
      }
    }
+   */
    fprintf(fplog,"Repl   ");
    for(i=0; i<re->nrepl; i++)
      fprintf(fplog," %3d  ",re->ind[i]);
***************
*** 439,444 ****
--- 433,443 ----
    bool *bEx,bPrint;
    int  exchange;
  
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Replica-methods stuff */
+   real Epotab, Epotba, Epota, Epotb;
+   real delta1, delta2, delta_meta;
+ 
    fprintf(fplog,"Replica exchange at step %d time %g\n",step,time);
    
    switch (re->type) {
***************
*** 457,481 ****
      break;
    }
  
    snew(bEx,re->nrepl);
    snew(prob,re->nrepl);
  
    exchange = -1;
    m = (step / re->nst) % 2;
    for(i=1; i<re->nrepl; i++) {
      a = re->ind[i-1];
      b = re->ind[i];
      bPrint = (re->repl==a || re->repl==b);
      if (i % 2 == m) {
        switch (re->type) {
        case ereTEMP:
  	/* Use equations from:
  	 * Okabe et. al. Chem. Phys. Lett. 335 (2001) 435-439
  	 */
! 	ediff = Epot[b] - Epot[a];
  	betaA = 1.0/(re->q[a]*BOLTZ);
  	betaB = 1.0/(re->q[b]*BOLTZ);
! 	delta = (betaA - betaB)*ediff;
  	break;
        case ereLAMBDA:
  	/* Here we exchange based on a linear extrapolation of dV/dlambda.
--- 456,503 ----
      break;
    }
  
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Exchange replica hills bias potential */
+   if(logical.remd) ptmetad_sharepot(re->nrepl, re->repl);
+ 
    snew(bEx,re->nrepl);
    snew(prob,re->nrepl);
  
    exchange = -1;
    m = (step / re->nst) % 2;
+ 
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Choose replica for bias-exchange */
+   if(logical.rpxm) bias_exchange_traj(re->nrepl, &(re->seed), re->ind);
+ 
+ 
    for(i=1; i<re->nrepl; i++) {
      a = re->ind[i-1];
      b = re->ind[i];
+     // Carlo
+     Epotab =  0.;
+     Epotba =  0.; 
+     Epota  =  0.;
+     Epotb  =  0.;
      bPrint = (re->repl==a || re->repl==b);
      if (i % 2 == m) {
        switch (re->type) {
        case ereTEMP:
+         /* Carlo  Wed Oct 10 14:37:58 CEST 2007 */
+         /* tempering metadynamics */
+         if(logical.remd) ptmetad(&Epota, &Epotb, &Epotba, &Epotab, a, b);
+         delta1 = Epota - Epotab;
+         delta2 = Epotb - Epotba;
  	/* Use equations from:
  	 * Okabe et. al. Chem. Phys. Lett. 335 (2001) 435-439
  	 */
! 	//ediff = Epot[b] - Epot[a];
  	betaA = 1.0/(re->q[a]*BOLTZ);
  	betaB = 1.0/(re->q[b]*BOLTZ);
!         delta_meta = betaA * delta1 + betaB * delta2;
! 	//delta = (betaA - betaB)*ediff;
!         delta = - (( betaA - betaB ) * ( Epot[a] - Epot[b] ) + delta_meta ); 
! 
  	break;
        case ereLAMBDA:
  	/* Here we exchange based on a linear extrapolation of dV/dlambda.
***************
*** 512,519 ****
--- 534,543 ----
        if (bEx[i]) {
  	if (a == re->repl) {
  	  exchange = b;
+           if(logical.widthadapt) ptmetad_exchflut(b);
  	} else if (b == re->repl) {
  	  exchange = a;
+           if(logical.widthadapt) ptmetad_exchflut(a);
  	}
  	re->nexchange[i]++;
        }
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # mdrun.c 
   # 
        file="mdrun.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** mdrun-2.c	2009-01-27 15:53:09.000000000 +0100
--- mdrun.c	2009-01-27 16:27:58.000000000 +0100
***************
*** 52,59 ****
--- 52,61 ----
  
  /* afm stuf */
  #include "pull.h"
  
+ #include "metadyn.h"
+ 
  int main(int argc,char *argv[])
  {
    static char *desc[] = {
      "The mdrun program is the main computational chemistry engine",
***************
*** 273,281 ****
      { efXVG, "-runav",  "runaver",  ffOPTWR },
      { efXVG, "-px",     "pullx",    ffOPTWR },
      { efXVG, "-pf",     "pullf",    ffOPTWR },
      { efMTX, "-mtx",    "nm",       ffOPTWR },
!     { efNDX, "-dn",     "dipole",   ffOPTWR }
    };
  #define NFILE asize(fnm)
  
    /* Command line options ! */
--- 275,284 ----
      { efXVG, "-runav",  "runaver",  ffOPTWR },
      { efXVG, "-px",     "pullx",    ffOPTWR },
      { efXVG, "-pf",     "pullf",    ffOPTWR },
      { efMTX, "-mtx",    "nm",       ffOPTWR },
!     { efNDX, "-dn",     "dipole",   ffOPTWR },
!     { efDAT, "-plumed", "plumed",   ffOPTRD }
    };
  #define NFILE asize(fnm)
  
    /* Command line options ! */
***************
*** 483,490 ****
--- 486,501 ----
      
    ddxyz[XX] = (int)(realddxyz[XX] + 0.5);
    ddxyz[YY] = (int)(realddxyz[YY] + 0.5);
    ddxyz[ZZ] = (int)(realddxyz[ZZ] + 0.5);
+ 
+   if (opt2bSet("-plumed",NFILE,fnm)) {
+     logical.meta_inp=1;
+     char *metaFilename=ftp2fn(efDAT, NFILE, fnm);
+     strcpy(mtd_data.metaFilename,metaFilename);
+   } else {
+     logical.meta_inp=0;
+   }
    
    mdrunner(fplog,cr,NFILE,fnm,bVerbose,bCompact,
  	   ddxyz,dd_node_order,rdd,rconstr,
  	   dddlb_opt[0],dlb_scale,ddcsx,ddcsy,ddcsz,
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # Patch the Makefile 
   # 
    
        file="Makefile"

        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** Makefile	2008-12-16 19:40:49.428932228 +0100
--- /cluster/home/chab/mbonomi/Makefile	2008-12-16 19:39:24.261852659 +0100
***************
*** 82,88 ****
  luck_LDADD = $(LDADD)
  luck_DEPENDENCIES = $(noinst_LTLIBRARIES) ../mdlib/libmd_mpi_d.la \
  	../gmxlib/libgmx_mpi_d.la
! am_mdrun_OBJECTS = glaasje.$(OBJEXT) gctio.$(OBJEXT) ionize.$(OBJEXT) \
  	do_gct.$(OBJEXT) repl_ex.$(OBJEXT) xutils.$(OBJEXT) \
  	md.$(OBJEXT) mdrun.$(OBJEXT) genalg.$(OBJEXT)
  mdrun_OBJECTS = $(am_mdrun_OBJECTS)
--- 82,97 ----
  luck_LDADD = $(LDADD)
  luck_DEPENDENCIES = $(noinst_LTLIBRARIES) ../mdlib/libmd_mpi_d.la \
  	../gmxlib/libgmx_mpi_d.la
! am_mdrun_OBJECTS = \
! 	biasexchange.$(OBJEXT) 		hills.$(OBJEXT) 		ptmetad.$(OBJEXT) 	\
! 	read_restraint.$(OBJEXT) 	restraint_alfabeta.$(OBJEXT) 	restraint_angle.$(OBJEXT) 	\
! 	restraint_coord.$(OBJEXT) 	restraint_dihcor.$(OBJEXT) 	restraint_dipole.$(OBJEXT) 	\
! 	restraint_dist.$(OBJEXT) 	restraint_hbonds.$(OBJEXT) 	restraint_mindist.$(OBJEXT) 	\
! 	restraint_rgyr.$(OBJEXT) 	restraint_rmsdtor.$(OBJEXT) 	restraint_spath.$(OBJEXT) 	\
! 	restraint_zpath.$(OBJEXT) 	restraint_position.$(OBJEXT) 	testderivatives.$(OBJEXT) 	\
! 	restraint_torsion.$(OBJEXT) 	restraint_waterbridge.$(OBJEXT)		\
! 	metadyn.$(OBJEXT) 	restraint.$(OBJEXT) 	\
! 	glaasje.$(OBJEXT) gctio.$(OBJEXT) ionize.$(OBJEXT) \
  	do_gct.$(OBJEXT) repl_ex.$(OBJEXT) xutils.$(OBJEXT) \
  	md.$(OBJEXT) mdrun.$(OBJEXT) genalg.$(OBJEXT)
  mdrun_OBJECTS = $(am_mdrun_OBJECTS)
***************
*** 113,122 ****
  depcomp = $(SHELL) $(top_srcdir)/config/depcomp
  am__depfiles_maybe = depfiles
  COMPILE = $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) \
! 	$(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)
  LTCOMPILE = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) \
! 	$(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)
  CCLD = $(CC)
  LINK = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=link $(CCLD) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) \
--- 122,131 ----
  depcomp = $(SHELL) $(top_srcdir)/config/depcomp
  am__depfiles_maybe = depfiles
  COMPILE = $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) \
! 	$(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -DGROMACS4 
  LTCOMPILE = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) \
! 	$(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -DGROMACS4 
  CCLD = $(CC)
  LINK = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=link $(CCLD) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) \
***************
*** 305,310 ****
--- 314,327 ----
  gmxcheck_SOURCES = gmxcheck.c
  x2top_SOURCES = x2top.c nm2type.c x2top.h
  mdrun_SOURCES = \
+ 	biasexchange.c 		hills.c 		ptmetad.c 	\
+ 	read_restraint.c 	restraint_alfabeta.c 	restraint_angle.c 	\
+ 	restraint_coord.c 	restraint_dihcor.c 	restraint_dipole.c 	\
+ 	restraint_dist.c 	restraint_hbonds.c 	restraint_mindist.c 	\
+ 	restraint_rgyr.c 	restraint_rmsdtor.c 	restraint_spath.c 	\
+ 	restraint_zpath.c 	restraint_position.c 	testderivatives.c 	\
+ 	restraint_torsion.c 	restraint_waterbridge.c 	\
+ 	metadyn.c 	restraint.c 	\
  	glaasje.c       glaasje.h       gctio.c         \
  	ionize.c        ionize.h        xmdrun.h        \
  	do_gct.c        repl_ex.c       repl_ex.h       \
***************
*** 418,423 ****
--- 435,462 ----
  distclean-compile:
  	-rm -f *.tab.c
  
+ include ./$(DEPDIR)/biasexchange.Plo
+ include ./$(DEPDIR)/hills.Plo
+ include ./$(DEPDIR)/metadyn.Plo
+ include ./$(DEPDIR)/ptmetad.Plo
+ include ./$(DEPDIR)/read_restraint.Plo
+ include ./$(DEPDIR)/restraint.Plo
+ include ./$(DEPDIR)/restraint_alfabeta.Plo
+ include ./$(DEPDIR)/restraint_angle.Plo
+ include ./$(DEPDIR)/restraint_coord.Plo
+ include ./$(DEPDIR)/restraint_dihcor.Plo
+ include ./$(DEPDIR)/restraint_dipole.Plo
+ include ./$(DEPDIR)/restraint_dist.Plo
+ include ./$(DEPDIR)/restraint_hbonds.Plo
+ include ./$(DEPDIR)/restraint_mindist.Plo
+ include ./$(DEPDIR)/restraint_position.Plo
+ include ./$(DEPDIR)/restraint_rgyr.Plo
+ include ./$(DEPDIR)/restraint_rmsdtor.Plo
+ include ./$(DEPDIR)/restraint_spath.Plo
+ include ./$(DEPDIR)/restraint_torsion.Plo
+ include ./$(DEPDIR)/restraint_waterbridge.Plo
+ include ./$(DEPDIR)/restraint_zpath.Plo
+ include ./$(DEPDIR)/testderivatives.Plo
  include ./$(DEPDIR)/add_par.Plo
  include ./$(DEPDIR)/compute_io.Plo
  include ./$(DEPDIR)/convparm.Plo
EOF
             patch -c -l -b -F 3 --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
#
# creating empty (and useless) Plo files...
#
echo "# dummy" > ./.deps/biasexchange.Plo
echo "# dummy" > ./.deps/hills.Plo
echo "# dummy" > ./.deps/metadyn.Plo
echo "# dummy" > ./.deps/ptmetad.Plo
echo "# dummy" > ./.deps/read_restraint.Plo
echo "# dummy" > ./.deps/restraint_alfabeta.Plo
echo "# dummy" > ./.deps/restraint_angle.Plo
echo "# dummy" > ./.deps/restraint.Plo
echo "# dummy" > ./.deps/restraint_coord.Plo
echo "# dummy" > ./.deps/restraint_dihcor.Plo
echo "# dummy" > ./.deps/restraint_dipole.Plo
echo "# dummy" > ./.deps/restraint_dist.Plo
echo "# dummy" > ./.deps/restraint_hbonds.Plo
echo "# dummy" > ./.deps/restraint_mindist.Plo
echo "# dummy" > ./.deps/restraint_position.Plo
echo "# dummy" > ./.deps/restraint_rgyr.Plo
echo "# dummy" > ./.deps/restraint_rmsdtor.Plo
echo "# dummy" > ./.deps/restraint_spath.Plo
echo "# dummy" > ./.deps/restraint_torsion.Plo
echo "# dummy" > ./.deps/restraint_waterbridge.Plo
echo "# dummy" > ./.deps/restraint_zpath.Plo
echo "# dummy" > ./.deps/testderivatives.Plo
cd ../../
#
# reverts
#
   elif [ "$1" =  "-revert" ] ; then
        found=1
   	echo "REVERTING TO OLD FILES:"
        cd src/kernel
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS | grep -v rex`
        do
            rm $i
        done
        rm ./.deps/biasexchange.Plo
        rm ./.deps/hills.Plo
        rm ./.deps/metadyn.Plo
        rm ./.deps/ptmetad.Plo
        rm ./.deps/read_restraint.Plo
        rm ./.deps/restraint_alfabeta.Plo
        rm ./.deps/restraint_angle.Plo
        rm ./.deps/restraint.Plo
        rm ./.deps/restraint_coord.Plo
        rm ./.deps/restraint_dihcor.Plo
        rm ./.deps/restraint_dipole.Plo
        rm ./.deps/restraint_dist.Plo
        rm ./.deps/restraint_hbonds.Plo
        rm ./.deps/restraint_mindist.Plo
        rm ./.deps/restraint_position.Plo
        rm ./.deps/restraint_rgyr.Plo
        rm ./.deps/restraint_rmsdtor.Plo
        rm ./.deps/restraint_spath.Plo
        rm ./.deps/restraint_torsion.Plo
        rm ./.deps/restraint_waterbridge.Plo
        rm ./.deps/restraint_zpath.Plo
        rm ./.deps/testderivatives.Plo
        file="Makefile"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="md.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="mdrun.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="repl_ex.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
   #
        cd ../../
   elif [ "$found" = "0" ]  
   then
     echo "WRONG KEYWORD "
     echo "USAGE :"
     echo "./plumedpatch_gromacs_4.0.4.sh  (-patch) (-revert)   "
     echo " -patch  : apply PluMeD patch " 
     echo " -revert : revert code to original "
     exit
   fi
fi
