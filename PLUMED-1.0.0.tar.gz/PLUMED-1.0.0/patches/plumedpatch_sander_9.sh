#!/bin/bash
#
# PluMeD patch for SANDER 9 
#
plumedir="/Users/chicco/Programs/gronamd/md_meta/"
found_flag=0 
if [ "$#" -eq 0 ];
then
 echo "USAGE :"
 echo "./plumedpatch_sander_9.sh  (-patch) (-revert)   "
 echo " -patch  : apply PluMeD patch "  
 echo " -revert : revert code to original "
 exit
elif [ "$#" -eq 1  ]
   then 
     
echo "   remember to modify by hand  the c compiler flags with the -DAMBER option" 
echo ""
echo "CFLAGS= -D_FILE_OFFSET_BITS=64 -D_LARGEFILE_SOURCE -O2 -m32 -DAMBER "
echo "CPPFLAGS= \$(AMBERBUILDFLAGS) -DAMBER"

   if [ "$1" =  "-patch" ] ; then
         found_flag=1
         #
         # SimParameters.h
         #
         file="md.h"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** md.h    Mon May 26 17:59:37 2008
--- md.h.meta	Mon May 26 18:01:02 2008
***************
*** 15,36 ****
        ibgwat,ienwat,iorwat,              &!36
        iwatpr,nsolw,igb,alpb,iyammp,           &!41
        gbsa,vrand,iwrap,nrespa,irespa,nrespai,icfe,  &!48
        rbornstat,ivcap,iconstreff,        &!51
        neb,vv,tmode,ipol,iesp,ievb,nodeid,num_noshake,    &!59
!       idecomp,icnstph,ntcnstph,maxdup,numexchg,repcrd,numwatkeep     !66
! parameter (BC_MDI=66)
  
  common/mdi/nrp,nspm,ig, &
        ntx,ntcx,ntxo,ntt,ntp,ntr,init,ntcm,nscm, &
        isolvp,nsolut,ntc,ntcc,ntf,ntid,ntn,ntnb,nsnb,ndfmin, &
        nstlim,nrc,ntrx,npscal,imin,maxcyc,ncyc,ntmin, &
        irest,jfastw,ibgwat,ienwat,iorwat, &
        iwatpr,nsolw,igb,alpb,iyammp,gbsa,vrand,numexchg,repcrd,numwatkeep, &
        iwrap,nrespa,irespa,nrespai,icfe,rbornstat, &
        ivcap,iconstreff,idecomp,klambda,icnstph,ntcnstph,maxdup,neb,vv, &
! 	  tmode,ipol,iesp,ievb,nodeid,num_noshake
  
  ! ... floats:
  
  _REAL_ t,dt,temp0,tautp,pres0,comp,taup,temp,tempi, & !9
        tol,taur,dx0,drms,vlimit,rbtarg(9),tmass,tmassinv,  & !25
--- 15,37 ----
        ibgwat,ienwat,iorwat,              &!36
        iwatpr,nsolw,igb,alpb,iyammp,           &!41
        gbsa,vrand,iwrap,nrespa,irespa,nrespai,icfe,  &!48
        rbornstat,ivcap,iconstreff,        &!51
        neb,vv,tmode,ipol,iesp,ievb,nodeid,num_noshake,    &!59
!       idecomp,icnstph,ntcnstph,maxdup,numexchg,repcrd,numwatkeep,     &!66
!       plumed  !67
! parameter (BC_MDI=67)
  
  common/mdi/nrp,nspm,ig, &
        ntx,ntcx,ntxo,ntt,ntp,ntr,init,ntcm,nscm, &
        isolvp,nsolut,ntc,ntcc,ntf,ntid,ntn,ntnb,nsnb,ndfmin, &
        nstlim,nrc,ntrx,npscal,imin,maxcyc,ncyc,ntmin, &
        irest,jfastw,ibgwat,ienwat,iorwat, &
        iwatpr,nsolw,igb,alpb,iyammp,gbsa,vrand,numexchg,repcrd,numwatkeep, &
        iwrap,nrespa,irespa,nrespai,icfe,rbornstat, &
        ivcap,iconstreff,idecomp,klambda,icnstph,ntcnstph,maxdup,neb,vv, &
! 	  tmode,ipol,iesp,ievb,nodeid,num_noshake,plumed
  
  ! ... floats:
  
  _REAL_ t,dt,temp0,tautp,pres0,comp,taup,temp,tempi, & !9
        tol,taur,dx0,drms,vlimit,rbtarg(9),tmass,tmassinv,  & !25
***************
*** 47,57 ****
        v11,v12,v22,kevb,evbt,Arad
  
  ! ... strings:
  
  character(len=4) iwtnm,iowtnm,ihwtnm
! character(len=256) restraintmask,bellymask,tgtfitmask,tgtrmsmask,noshakemask
  common/mds/ restraintmask,bellymask,tgtfitmask,tgtrmsmask,noshakemask,  &
!             iwtnm,iowtnm,ihwtnm(2)
  
  !-------------END    md.h  ------------------------------------------------
  
--- 48,58 ----
        v11,v12,v22,kevb,evbt,Arad
  
  ! ... strings:
  
  character(len=4) iwtnm,iowtnm,ihwtnm
! character(len=256) restraintmask,bellymask,tgtfitmask,tgtrmsmask,noshakemask,plumedfile
  common/mds/ restraintmask,bellymask,tgtfitmask,tgtrmsmask,noshakemask,  &
!             iwtnm,iowtnm,ihwtnm(2),plumedfile
  
  !-------------END    md.h  ------------------------------------------------
EOF
             patch -c -l -b --suffix=.premeta ${file}  < ${file}.patch
             rm -rf ${file}.patch 
         fi 
         #
         # mdread 
         #
         file="mdread.f"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** mdread.f	Mon May 26 17:59:50 2008
--- mdread.f.meta	Mon May 26 18:01:02 2008
***************
*** 78,88 ****
           cut_inner,icfe,clambda,klambda, rbornstat,lastrst,lastist,  &
           itgtmd,tgtrmsd,tgtmdfrc,tgtfitmask,tgtrmsmask, &
           idecomp,temp0les,restraintmask,restraint_wt,bellymask, &
           noshakemask, &
           mmtsb_switch, mmtsb_iterations,rdt,icnstph,solvph,ntcnstph, &
!          ifqnt,ievb, &
  #ifdef PIMD
           pimd_runtype, pimd_use_original_mass, ineb, &
  #endif
           dtemp, dxm, heat, timlim  !all retired 
  
--- 78,88 ----
           cut_inner,icfe,clambda,klambda, rbornstat,lastrst,lastist,  &
           itgtmd,tgtrmsd,tgtmdfrc,tgtfitmask,tgtrmsmask, &
           idecomp,temp0les,restraintmask,restraint_wt,bellymask, &
           noshakemask, &
           mmtsb_switch, mmtsb_iterations,rdt,icnstph,solvph,ntcnstph, &
!          ifqnt,ievb,plumed,plumedfile, &
  #ifdef PIMD
           pimd_runtype, pimd_use_original_mass, ineb, &
  #endif
           dtemp, dxm, heat, timlim  !all retired 
  
***************
*** 129,138 ****
--- 129,140 ----
     ig = 71277
     tempi = ZERO
     ntb = 1
     ntt = 0
     temp0 = 300.0d0
+    plumed = 0    
+    plumedfile = 'plumed.dat'
  #if defined(LES) || defined(PIMD)
     
     ! alternate temp for LES copies, if negative then use single bath
     ! single bath not the same as 2 baths with same target T
     
***************
*** 306,315 ****
--- 308,321 ----
     else
        write(6, '(1x,a,/)') 'Could not find cntrl namelist'
        call mexit(6,1)
     end if
  
+    if (plumed.eq.1) then
+      write(6, '(1x,a,/)') 'PLUMED is on'
+      write(6, '(1x,a,a,/)') 'PLUMEDfile is ',plumedfile
+    endif
     if (ifqnt>0) then
       qmmm_nml%ifqnt = .true.
       if (saltcon /= 0.0d0) then
         qm_gb%saltcon_on = .true.
       else
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch 
         fi 
         #
         # runmd.f 
         #
         file="runmd.f"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** runmd.f	Mon May 26 18:00:16 2008
--- runmd.f.meta	Tue May 27 15:06:51 2008
***************
*** 483,492 ****
--- 483,499 ----
     
     ekcmt(1:4) = 0.d0
     nitp = 0
     nits = 0
     
+    ! init PLUMED 
+    if(plumed.eq.1) then 
+       call init_metadyn_(nr,dt,amass,xx(l15),trim(adjustl(plumedfile))//char(0))
+    endif
+    ! end init PLUMED 
+  
+    
     !=======================================================================
     !     ----- MAKE A FIRST DYNAMICS STEP -----
     !=======================================================================
     !  init = 3:  general startup if not continuing a previous run
     
***************
*** 825,834 ****
--- 832,845 ----
  #endif
     call force(xx,ix,ih,ipairs,x,f,ener(23),vir, &
           xx(l96),xx(l97),xx(l98),xx(l99), qsetup,qpsander, &
              do_list_update)
  
+    !PLUMED force added
+    call  meta_force_calculation_(box,x,f,nstep);   
+    !PLUMED end  
+ 
     ! Constant pH transition evaluation
     if ((icnstph /= 0) .and. (mod(irespa,ntcnstph) == 0)) then
        call cnstphendstep(ix(icpstinf),ix(icpresst),ix(icpptcnt), &
              ix(icptrsct), xx(lcpene),xx(lcpcrg),xx(l190),xx(l15),ener(39), &
              icpselres,icpselstat,cnstph_rand_gen)
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch 
         fi 
   #
   # cp PLUMED file from  directory 
   #
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS | grep -v rex`
        do
            ss=`echo $i | cut -d. -f2`
            name=`echo $i | cut -d. -f1`
            if [ "$ss" = "c" ] ;
            then
              ln -s ${plumedir}/common_files/$i ./$name.c 
            else
              ln -s ${plumedir}/common_files/$i  
            fi
        done
   #
   # Patch the makefile
   # 
        file="Makefile"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<EOF
*** Makefile	Mon May 26 17:59:28 2008
--- Makefile.meta	Mon May 26 18:01:02 2008
***************
*** 85,94 ****
      matinv.o assert.o mmtsb.o mmtsb_client.o erfcfun.o veclib.o \\
      is_init.o constantph.o prn_dipoles.o ips.o sglds.o \\
      \$(AMOEBAOBJ) bintraj.o \\
!     spatial_recip.o spatial_fft.o parms.o
  
  LESOBJ=             \\
!     \$(EVBOBJ) constants.o qmmm_module.o trace.o lmod.o decomp.o icosasurf.o \\
      egb.LES.o findmask.o pb_force.o pb_exmol.o pb_mpfrc.o \\
      pb_direct.o \\
      pb_list.o np_force.o sa_driver.o relax_mat.o nmr.LES.o \\
--- 85,117 ----
      matinv.o assert.o mmtsb.o mmtsb_client.o erfcfun.o veclib.o \\
      is_init.o constantph.o prn_dipoles.o ips.o sglds.o \\
      \$(AMOEBAOBJ) bintraj.o \\
!     spatial_recip.o spatial_fft.o parms.o \$(METAOBJ) 
! 
! METAOBJ=     \\
!     hills.o \\
!     metadyn.o \\
!     ptmetad.o \\
!     read_restraint.o \\
!     restraint.o \\
!     restraint_alfabeta.o \\
!     restraint_angle.o \\
!     restraint_coord.o \\
!     restraint_dihcor.o \\
!     restraint_dipole.o \\
!     restraint_dist.o \\
!     restraint_hbonds.o \\
!     restraint_mindist.o \\
!     restraint_rgyr.o \\
!     restraint_rmsdtor.o \\
!     restraint_spath.o \\
!     restraint_torsion.o \\
!     restraint_waterbridge.o \\
!     restraint_zpath.o \\
!     restraint_position.o \\
!     testderivatives.o
  
  LESOBJ=             \\
!     \$(EVBOBJ) \$(METAOBJ) constants.o qmmm_module.o trace.o lmod.o decomp.o icosasurf.o \\
      egb.LES.o findmask.o pb_force.o pb_exmol.o pb_mpfrc.o \\
      pb_direct.o \\
      pb_list.o np_force.o sa_driver.o relax_mat.o nmr.LES.o \\
***************
*** 109,115 ****
      spatial_recip.o spatial_fft.o pimd_vars.PIMD.o parms.o
  
  PIMDOBJ= \\
!     parms.o constants.o qmmm_module.PIMD.o \\
      qm_link_atoms.PIMD.o qm_nb_list.PIMD.o qm_mm.PIMD.o \\
      pimd_vars.PIMD.o pimd_init.PIMD.o pimd_force.PIMD.o \\
      dynlib.PIMD.o ew_force.PIMD.o force.PIMD.o mdread.PIMD.o \\
--- 132,138 ----
      spatial_recip.o spatial_fft.o pimd_vars.PIMD.o parms.o
  
  PIMDOBJ= \\
!     parms.o constants.o qmmm_module.PIMD.o \$(METAOBJ) \\
      qm_link_atoms.PIMD.o qm_nb_list.PIMD.o qm_mm.PIMD.o \\
      pimd_vars.PIMD.o pimd_init.PIMD.o pimd_force.PIMD.o \\
      dynlib.PIMD.o ew_force.PIMD.o force.PIMD.o mdread.PIMD.o \\
***************
*** 262,267 ****
--- 285,293 ----
  	-/bin/rm *nbflag
  	cd ../dcqtp; make clean
  
+ metaclean:
+ 	rm -rf \$(METAOBJ) 
+ 
  depend::
  	./makedepend > depend
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   elif [ "$1" =  "-revert" ] ; then
        found=1
   	echo "REVERTING TO OLD FILES:"
        file="md.h"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="mdread.f"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="runmd.f"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
   #
   # remove PLUMED files from current directory 
   #
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS`
        do
            ss=`echo $i | cut -d. -f2`
            name=`echo $i | cut -d. -f1`
            if [ "$ss" = "c" ] ;
            then
              # adapt c suffix
              rm ./$name.c 
            else
              rm  ./$i  
            fi
        done
        file="Makefile"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
   elif [ "$found" = "0" ]  
   then
     echo "WRONG KEYWORD "
     echo "USAGE :"
     echo "./plumedpatch_sander_9.sh  (-patch) (-revert)   "
     echo " -patch  : apply PluMeD patch "  
     echo " -revert : revert code to original "
     exit
   fi
fi
