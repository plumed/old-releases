#!/bin/bash
#
# PluMeD patch for NAMD 2.6 
#
plumedir="/Users/max/build/PLUMED/md_meta"
myarch="MacOSX-i686-g++"
found_flag=0 
if [ "$#" -eq 0 ];
then
 echo "USAGE :"
 echo "./plumedpatch_namd_2.6.sh  (-patch) (-revert)   "
 echo " -patch  : apply PluMeD patch "
 echo " -revert : revert code to original "
 exit
elif [ "$#" -eq 1  ]
   then 
   if [ "$1" =  "-patch" ] ; then
         found_flag=1
         #
         # SimParameters.h
         #
         file="SimParameters.h"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** SimParameters.h	Mon Jan 14 19:28:42 2008
--- SimParameters.h.meta	Tue Jan 15 19:28:59 2008
***************
*** 290,295 ****
--- 290,301 ----
  	Bool freeEnergyOn;		//  Doing free energy perturbation?
  	Bool miscForcesOn;		//  Using misc forces?
  
+       // begin PLUMED changes
+                Bool metaDynamicsOn;            //  Using PLUMED?
+                char metaFilename[129];         //  PLUMED filename
+      // end PLUMED changes
+       
+ 
  	Bool fixedAtomsOn;		//  Are there fixed atoms?
  	Bool fixedAtomsForces;		//  Calculate forces anyway?
 
EOF
             patch -c -l -b --suffix=.premeta ${file}  < ${file}.patch
             rm -rf ${file}.patch 
         fi 
         #
         # SimParameters.C
         #
         file="SimParameters.C"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** SimParameters.C	Fri Aug 25 20:54:42 2006
--- SimParameters.C.meta	Tue Jan 15 19:28:59 2008
***************
*** 1039,1044 ****
--- 1039,1052 ----
     opts.optional("miscForces", "miscForcesScript",
       "script for misc forces", PARSE_MULTIPLES);
  
+    // begin PLUMED changes
+    ////  Global Forces / PLUMED 
+    opts.optionalB("main", "plumed", "Is PLUMED active?",
+      &metaDynamicsOn, FALSE);
+    opts.require("plumed", "plumedfile",
+      "PLUMED script", PARSE_STRING);
+    // end PLUMED changes
+ 
     ////  Free Energy Perturbation
     opts.optionalB("main", "freeEnergy", "Perform free energy perturbation?",
       &freeEnergyOn, FALSE);
***************
*** 3042,3049 ****
     
     // Global forces configuration
  
     globalForcesOn = ( tclForcesOn || freeEnergyOn || miscForcesOn ||
!                       (IMDon) || SMDOn || TMDOn);
  
     if (tclForcesOn)
     {
--- 3050,3059 ----
     
     // Global forces configuration
  
+   // begin PLUMED changes
     globalForcesOn = ( tclForcesOn || freeEnergyOn || miscForcesOn ||
!                       (IMDon) || SMDOn || TMDOn || metaDynamicsOn );
!   // end PLUMED changes
  
     if (tclForcesOn)
     {
***************
*** 3083,3088 ****
--- 3093,3115 ----
       iout << endi;
     }
  
+    // begin PLUMED changes
+    if (metaDynamicsOn)
+    {
+      iout << iINFO << "PLUMED ACTIVE\n";
+ 
+      current = config->find("plumedfile");
+      iout << iINFO << "PLUMED CONFIG FILE   "
+         << current->data << "\n" << endi;
+      strcpy(metaFilename,current->data);
+ 
+      ifstream metaFile(current->data);
+      if ( ! metaFile ) NAMD_die("Error reading PLUMED config file.\n");
+ 
+    }
+    // end PLUMED changes
+ 
+ 
     if (freeEnergyOn)
     {
       iout << iINFO << "FREE ENERGY PERTURBATION ACTIVE\n";
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch 
         fi 
         #
         # ComputeMgr.C
         #
         file="ComputeMgr.C"
         if  [ -e "${file}.premeta" ];
         then
            echo "${file} FILE ALREADY PATCHED: skipped" 
         else
             cat >${file}.patch<<EOF
*** ComputeMgr.C	Tue Aug 15 02:37:44 2006
--- ComputeMgr.C.meta	Tue Jan 15 19:28:59 2008
***************
*** 67,72 ****
--- 67,75 ----
  #include "GlobalMasterTMD.h"
  #include "GlobalMasterEasy.h"
  #include "GlobalMasterMisc.h"
+ // begin PLUMED changes
+ #include "metadyn.h"
+ // end PLUMED changes
  #include "GlobalMasterFreeEnergy.h"
  
  ComputeMgr::ComputeMgr()
***************
*** 439,444 ****
--- 442,452 ----
        masterServerObject->addClient(new GlobalMasterTMD());
      if(simParams->miscForcesOn)
        masterServerObject->addClient(new GlobalMasterMisc());
+     // begin PLUMED changes
+     if(simParams->metaDynamicsOn){
+       masterServerObject->addClient(new GlobalMasterMetaDynamics());
+     }
+     // end PLUMED changes
      if ( simParams->freeEnergyOn )
        masterServerObject->addClient(new GlobalMasterFreeEnergy());
    }

EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch 
         fi 
   #
   # cp PLUMED file from  directory 
   #
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS | grep -v rex`
        do
            ss=`echo $i | cut -d. -f2`
            name=`echo $i | cut -d. -f1`
            if [ "$ss" = "c" ] ;
            then
              ln -s ${plumedir}/common_files/$i ./$name.C 
            else
              ln -s ${plumedir}/common_files/$i  
            fi
        done
   #
   # Patch the makefile
   # 
        cd ../
        file="Makefile"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<EOF
*** Makefile	Thu Jan 17 13:28:57 2008
--- Makefile.meta	Thu Jan 17 13:30:45 2008
***************
*** 10,16 ****
  include Makearch
  
  # pass version/platform information to compile
! RELEASE=\$(COPTD)NAMD_VERSION=\\"\$(NAMD_VERSION)\\" \$(COPTD)NAMD_PLATFORM=\\"\$(NAMD_PLATFORM)\\" \$(SCYLDFLAGS)
  
  # directories
  SRCDIR = src
--- 10,16 ----
  include Makearch
  
  # pass version/platform information to compile
! RELEASE=\$(COPTD)NAMD_VERSION=\\"\$(NAMD_VERSION)\\" \$(COPTD)NAMD_PLATFORM=\\"\$(NAMD_PLATFORM)\\" \$(COPTD)NAMD \$(SCYLDFLAGS)
  
  # directories
  SRCDIR = src 
***************
*** 122,127 ****
--- 122,147 ----
  	\$(DSTDIR)/GlobalMasterTMD.o \\
  	\$(DSTDIR)/GlobalMasterFreeEnergy.o \\
  	\$(DSTDIR)/GlobalMasterEasy.o \\
+ 	\$(DSTDIR)/metadyn.o \\
+       \$(DSTDIR)/read_restraint.o \\
+       \$(DSTDIR)/restraint.o \\
+       \$(DSTDIR)/hills.o \\
+       \$(DSTDIR)/testderivatives.o \\
+       \$(DSTDIR)/restraint_dist.o \\
+       \$(DSTDIR)/restraint_mindist.o \\
+       \$(DSTDIR)/restraint_coord.o \\
+       \$(DSTDIR)/restraint_angle.o \\
+       \$(DSTDIR)/restraint_torsion.o \\
+       \$(DSTDIR)/restraint_alfabeta.o \\
+       \$(DSTDIR)/restraint_hbonds.o \\
+       \$(DSTDIR)/restraint_dipole.o \\
+       \$(DSTDIR)/restraint_rgyr.o \\
+       \$(DSTDIR)/restraint_rmsdtor.o \\
+       \$(DSTDIR)/restraint_dihcor.o \\
+       \$(DSTDIR)/restraint_waterbridge.o \\
+       \$(DSTDIR)/restraint_spath.o \\
+       \$(DSTDIR)/restraint_zpath.o \\
+       \$(DSTDIR)/restraint_position.o \\
  	\$(DSTDIR)/GlobalMasterMisc.o \\
        \$(DSTDIR)/GromacsTopFile.o \\
  	\$(DSTDIR)/heap.o \\
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # make depends
   #
        cd ./$myarch/
        make depends 
        cd ../src 
   elif [ "$1" =  "-revert" ] ; then
        found=1
   	echo "REVERTING TO OLD FILES:"
        file="SimParameters.h"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="SimParameters.C"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="ComputeMgr.C"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
   #
   # remove PLUMED files from current directory 
   #
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS`
        do
            ss=`echo $i | cut -d. -f2`
            name=`echo $i | cut -d. -f1`
            if [ "$ss" = "c" ] ;
            then
              rm ./$name.C 
            else
              rm  ./$i  
            fi
        done
        cd ..
        file="Makefile"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
   #
   # make depends
   #
        cd ./$myarch/
        make depends 
        cd ../src 

   elif [ "$found" = "0" ]  
   then
     echo "WRONG KEYWORD "
     echo "USAGE :"
     echo "./plumedpatch_namd_2.6.sh  (-patch) (-revert)   "
     echo " -patch  : apply PluMeD patch "
     echo " -revert : revert code to original "
     exit
   fi
fi
