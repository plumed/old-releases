#!/bin/bash
#
# PluMeD patch for gromacs 3.3.3 
#
plumedir="/share/home33/carlo/Templates/source/plug-in/md_meta/"
found_flag=0
if [ "$#" -eq 0 ];
then
 echo "USAGE :"
 echo "./plumedpatch_gromacs_3.3.3.sh  (-patch) (-revert)   "
 echo " -patch  : apply PluMeD patch " 
 echo " -revert : revert code to original "
 exit
elif [ "$#" -eq 1  ]
   then
   if [ "$1" =  "-patch" ] ; then
         found_flag=1
   #
   # link metadynamics file from  directory 
   #
        for i in `ls -1 ${plumedir}/common_files | grep -v CVS | grep -v rex`
        do
            ln -s ${plumedir}/common_files/$i ./src/kernel/$i
        done
   #
   # Patch kernel files 
   # 
        cd src/kernel
   #
   # md.c 
   #
           file="md.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** ../../../gromacs-3.3.3/src/kernel/md.c	Fri Feb 29 08:02:45 2008
--- md.c	Fri Jul 25 11:22:20 2008
***************
*** 77,82 ****
--- 77,85 ----
  #include "mpelogging.h"
  #endif
  
+ // Carlo Wed Oct 10 14:37:58 CEST 2007 
+ // to include metadynamics routine
+ #include "metadyn.h"
  
  volatile bool bGotTermSignal = FALSE, bGotUsr1Signal = FALSE;
  
***************
*** 467,472 ****
--- 470,486 ----
    /* Initialize values for invmass, etc. */
    update_mdatoms(mdatoms,state->lambda,TRUE);
  
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Initialize stuff for metadynamics and replica-methods */
+   if(MASTER(cr)&&logical.meta_inp) {
+     /* Initialize metadynamics */
+     init_metadyn(mdatoms->nr, state->box, mdatoms->chargeA, mdatoms->massA, 
+                  inputrec->delta_t, 
+                 (repl_ex_nst>0?repl_ex_nst:-1), (repl_ex_nst>0?repl_ex->repl:-1), 
+                 (repl_ex_nst>0?repl_ex->nrepl:1), (repl_ex_nst>0?repl_ex->temp[0]:0), 
+                 (repl_ex_nst>0?repl_ex->temp[repl_ex->repl]:0), mcr, log);
+   }
+ 
    /* Set the node time counter to 0 after initialisation */
    start_time();
    debug_gmx();
***************
*** 640,645 ****
--- 654,677 ----
  	       state->box,state->x,f,buf,mdatoms,ener,fcd,bVerbose && !PAR(cr),
  	       state->lambda,graph,
  	       TRUE,bNS,FALSE,TRUE,fr,mu_tot,FALSE,t,fp_field,edyn);
+ 
+       // Carlo Wed Oct 10 14:37:58 CEST 2007 
+       // Metadynamics forces
+       if(MASTER(cr)&&logical.meta_inp) { 
+         if(colvar.nconst>0) {
+           rvec *meta_force;
+           snew(meta_force, mdatoms->nr);
+           meta_force_calculation(state->x, meta_force, state->v, state->box, step);
+           int iii;
+           for(iii=0;iii<mdatoms->nr;iii++) {
+             f[iii][0] += meta_force[iii][0];
+             f[iii][1] += meta_force[iii][1];
+             f[iii][2] += meta_force[iii][2];
+           }
+           sfree(meta_force);
+         }
+       }
+ 
      }
     
  	
***************
*** 965,974 ****
        print_time(stderr,start_t,step,inputrec);
      }
  
      bExchanged = FALSE;
!     if ((repl_ex_nst > 0) && (step > 0) && !bLastStep &&
! 	do_per_step(step,repl_ex_nst))
!       bExchanged = replica_exchange(log,mcr,repl_ex,state,ener[F_EPOT],step,t);
      
      bFirstStep = FALSE;
  
--- 996,1008 ----
        print_time(stderr,start_t,step,inputrec);
      }
  
+     /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+     /* Modified for soulute tempering and metadynamics */
+     real stpme=0;
      bExchanged = FALSE;
!     if ((repl_ex_nst > 0) && (step > 0) && !bLastStep && 
!         do_per_step(step,repl_ex_nst)) 
!       bExchanged = replica_exchange(log, mcr, repl_ex, state, ener[F_EPOT], step, t, grps, stpme, inputrec->opts.ref_t[0]);
      
      bFirstStep = FALSE;
  
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # mdrun.c 
   # 
        file="mdrun.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** mdrun.c.bak	2009-01-29 10:33:58.000000000 +0100
--- mdrun.c	2009-01-29 10:43:39.000000000 +0100
***************
*** 49,56 ****
--- 49,59 ----
  #include "xmdrun.h"
  /* afm stuf */
  #include "pull.h"
  
+ /* plumed stuff */
+ #include "metadyn.h"
+ 
  int main(int argc,char *argv[])
  {
    static char *desc[] = {
      "The mdrun program is the main computational chemistry engine",
***************
*** 159,167 ****
      { efPPA, "-po",     "pullout",  ffOPTWR },
      { efPDO, "-pd",     "pull",     ffOPTWR },
      { efNDX, "-pn",     "pull",     ffOPTRD },
      { efMTX, "-mtx",    "nm",       ffOPTWR },
!     { efNDX, "-dn",     "dipole",   ffOPTWR }
    };
  #define NFILE asize(fnm)
  
    /* Command line options ! */
--- 162,171 ----
      { efPPA, "-po",     "pullout",  ffOPTWR },
      { efPDO, "-pd",     "pull",     ffOPTWR },
      { efNDX, "-pn",     "pull",     ffOPTRD },
      { efMTX, "-mtx",    "nm",       ffOPTWR },
!     { efNDX, "-dn",     "dipole",   ffOPTWR },
!     { efDAT, "-plumed", "plumed",   ffOPTRD }
    };
  #define NFILE asize(fnm)
  
    /* Command line options ! */
***************
*** 251,258 ****
--- 255,270 ----
    Flags = Flags | (bIonize   ? MD_IONIZE   : 0);
    Flags = Flags | (bMultiSim ? MD_MULTISIM : 0);
    Flags = Flags | (bGlas     ? MD_GLAS     : 0);
  
+   if (opt2bSet("-plumed",NFILE,fnm)) {
+     logical.meta_inp=1;
+     char *metaFilename=ftp2fn(efDAT, NFILE, fnm);
+     strcpy(mtd_data.metaFilename,metaFilename);
+   } else {
+     logical.meta_inp=0;
+   }
+ 
    mdrunner(cr,mcr,NFILE,fnm,bVerbose,bCompact,nDLB,nstepout,
  	   edyn,repl_ex_nst,repl_ex_seed,Flags);
    
    if (gmx_parallel_env)
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # repl_ex.c 
   # 
        file="repl_ex.c"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** ../../../gromacs-3.3.3/src/kernel/repl_ex.c	Fri Feb 29 08:02:50 2008
--- repl_ex.c	Fri Jul 25 11:20:55 2008
***************
*** 48,53 ****
--- 48,57 ----
  #include "vec.h"
  #include "names.h"
  
+ // Carlo Wed Oct 10 14:37:58 CEST 2007 
+ // to include metadynamics variables
+ #include "metadyn.h"
+ 
  gmx_repl_ex_t *init_replica_exchange(FILE *fplog,
  				     const t_commrec *mcr,
  				     const t_state *state,
***************
*** 117,122 ****
--- 121,131 ----
    /* Make an index for increasing temperature order */
    for(i=0; i<re->nrepl; i++)
      re->ind[i] = i;
+ 
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* This code is commented out to permit replicas with same temperature */
+   /* It's usefull for Replica Metadynamics (Laio's way) */
+   /*
    for(i=0; i<re->nrepl; i++) {
      for(j=i+1; j<re->nrepl; j++) {
        if (re->temp[re->ind[j]] < re->temp[re->ind[i]]) {
***************
*** 128,133 ****
--- 137,143 ----
        }
      }
    }
+   */
    fprintf(fplog,"Repl   ");
    for(i=0; i<re->nrepl; i++)
      fprintf(fplog," %3d  ",re->ind[i]);
***************
*** 275,282 ****
    fprintf(fplog,"\n");
  }
  
  bool replica_exchange(FILE *fplog,const t_commrec *mcr,gmx_repl_ex_t *re,
! 		      t_state *state,real epot,int step,real time)
  {
    int  m,i,a,b;
    real *Epot,*prob,ediff,delta,dpV,*Vol,betaA,betaB;
--- 285,295 ----
    fprintf(fplog,"\n");
  }
  
+ /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+ /* Replica exchange coupled with metadynamics */ 
  bool replica_exchange(FILE *fplog,const t_commrec *mcr,gmx_repl_ex_t *re,
! 		      t_state *state,real epot,int step,real time,t_groups *grps, 
!                       real VpmePP, real nowtemp)
  {
    int  m,i,a,b;
    real *Epot,*prob,ediff,delta,dpV,*Vol,betaA,betaB;
***************
*** 287,314 ****
    snew(Vol,re->nrepl);
    Epot[re->repl] = epot;
    Vol[re->repl]  = det(state->box);
    gmx_sum(re->nrepl,Epot,mcr);
    gmx_sum(re->nrepl,Vol,mcr);
  
    snew(bEx,re->nrepl);
    snew(prob,re->nrepl);
  
    bExchanged = FALSE;
    m = (step / re->nst) % 2;
    for(i=1; i<re->nrepl; i++) {
      a = re->ind[i-1];
      b = re->ind[i];
      bPrint = (re->repl==a || re->repl==b);
      if (i % 2 == m) {
-       /* Use equations from:
-        * Okabe et. al. Chem. Phys. Lett. 335 (2001) 435-439
-        */
-       ediff = Epot[b] - Epot[a];
        betaA = 1.0/(re->temp[a]*BOLTZ);
        betaB = 1.0/(re->temp[b]*BOLTZ);
!       delta = (betaA-betaB)*ediff;
        if (bPrint)
! 	fprintf(fplog,"Repl %d <-> %d  dE = %10.3e",a,b,delta);
        if (re->bNPT) {
  	dpV = (betaA*re->pres[a]-betaB*re->pres[b])*(Vol[b]-Vol[a])/PRESFAC;
  	if (bPrint)
--- 300,349 ----
    snew(Vol,re->nrepl);
    Epot[re->repl] = epot;
    Vol[re->repl]  = det(state->box);
+ 
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Replica-methods stuff */
+   real Epotab, Epotba;
+   for(i=0;i<re->nrepl;i++) re->temp[i] = 0.;
+   re->temp[re->repl] = nowtemp;
+   gmx_sum(re->nrepl,re->temp,mcr);
+ 
    gmx_sum(re->nrepl,Epot,mcr);
    gmx_sum(re->nrepl,Vol,mcr);
  
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Exchange replica hills bias potential */
+   if(logical.remd) ptmetad_sharepot(re->nrepl, re->repl);
+ 
    snew(bEx,re->nrepl);
    snew(prob,re->nrepl);
  
    bExchanged = FALSE;
    m = (step / re->nst) % 2;
+   
+   /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
+   /* Choose replica for bias-exchange */
+   if(logical.rpxm) bias_exchange_traj(re->nrepl, &(re->seed), re->ind);
+ 
    for(i=1; i<re->nrepl; i++) {
      a = re->ind[i-1];
      b = re->ind[i];
+     Epotab = Epot[b]; 
+     Epotba = Epot[a];
      bPrint = (re->repl==a || re->repl==b);
      if (i % 2 == m) {
        betaA = 1.0/(re->temp[a]*BOLTZ);
        betaB = 1.0/(re->temp[b]*BOLTZ);
! 
!       /* Carlo  Wed Oct 10 14:37:58 CEST 2007 */
!       /* tempering metadynamics */
!       if(logical.remd) ptmetad(&Epot[a], &Epot[b], &Epotba, &Epotab, a, b);
! 
!       delta = betaA*(Epotab-Epot[a])+betaB*(Epotba-Epot[b]);
! 
        if (bPrint)
! 	fprintf(fplog,"Repl %d <-> %d  dE = %10.3e, Ta = %.1f Tb = %.1f", a, b, 
!                 delta, re->temp[a], re->temp[b]);
        if (re->bNPT) {
  	dpV = (betaA*re->pres[a]-betaB*re->pres[b])*(Vol[b]-Vol[a])/PRESFAC;
  	if (bPrint)
***************
*** 333,341 ****
--- 368,382 ----
  	if (a == re->repl) {
  	  scale_velocities(state,sqrt(re->temp[a]/re->temp[b]));
  	  bExchanged = TRUE;
+           /* Carlo  Wed Oct 10 14:37:58 CEST 2007 */
+           /* hills widthadapt stuff */
+           if(logical.remd && logical.widthadapt) ptmetad_exchflut(b);
  	} else if (b == re->repl) {
  	  scale_velocities(state,sqrt(re->temp[b]/re->temp[a]));
  	  bExchanged = TRUE;
+           /* Carlo  Wed Oct 10 14:37:58 CEST 2007 */
+           /* hills widthadapt stuff */
+           if(logical.remd && logical.widthadapt) ptmetad_exchflut(a);
  	}
  	re->nexchange[i]++;
        }
***************
*** 354,359 ****
--- 395,401 ----
    sfree(Vol);
    
    re->nattempt[m]++;
+   fflush(fplog);
  
    return bExchanged;
  }
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # repl_ex.h 
   # 
        file="repl_ex.h"
        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** ../../../gromacs-3.3.3/src/kernel/repl_ex.h	Fri Feb 29 08:02:50 2008
--- repl_ex.h	Fri Feb 29 11:51:36 2008
***************
*** 59,68 ****
  					    const t_inputrec *ir,
  					    int nst,int init_seed);
  
! extern bool replica_exchange(FILE *fplog,
! 			     const t_commrec *mcr,
! 			     gmx_repl_ex_t *re,
! 			     t_state *state,real epot,int step,real time);
  /* Attempts replica exchange.
   * Returns TRUE if this state has been exchanged.
   */
--- 59,69 ----
  					    const t_inputrec *ir,
  					    int nst,int init_seed);
  
! /* Carlo Wed Oct 10 14:37:58 CEST 2007 */
! /* Replica Exchange coupled with metadynamics */
! extern bool replica_exchange(FILE *fplog, const t_commrec *mcr, gmx_repl_ex_t *re,
! 			     t_state *state, real epot, int step, real time, t_groups *grps, 
!                              real VpmePP, real nowtemp);
  /* Attempts replica exchange.
   * Returns TRUE if this state has been exchanged.
   */
EOF
             patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
   #
   # Patch the Makefile 
   # 
    
        file="Makefile"

        if  [ -e "${file}.premeta" ];
        then
           echo "${file} FILE ALREADY PATCHED: skipped" 
        else
             cat >${file}.patch<<\EOF
*** Makefile.premeta	Wed Jan 28 17:01:01 2009
--- Makefile	Wed Jan 28 17:14:12 2009
***************
*** 55,61 ****
  am_ffscan_OBJECTS = ffscan.$(OBJEXT) glaasje.$(OBJEXT) gctio.$(OBJEXT) \
  	init_sh.$(OBJEXT) ionize.$(OBJEXT) md.$(OBJEXT) \
  	genalg.$(OBJEXT) do_gct.$(OBJEXT) relax_sh.$(OBJEXT) \
! 	repl_ex.$(OBJEXT) xutils.$(OBJEXT) compute_io.$(OBJEXT)
  ffscan_OBJECTS = $(am_ffscan_OBJECTS)
  ffscan_LDADD = $(LDADD)
  ffscan_DEPENDENCIES = ../mdlib/libmd_d.la \
--- 55,69 ----
  am_ffscan_OBJECTS = ffscan.$(OBJEXT) glaasje.$(OBJEXT) gctio.$(OBJEXT) \
  	init_sh.$(OBJEXT) ionize.$(OBJEXT) md.$(OBJEXT) \
  	genalg.$(OBJEXT) do_gct.$(OBJEXT) relax_sh.$(OBJEXT) \
! 	repl_ex.$(OBJEXT) xutils.$(OBJEXT) compute_io.$(OBJEXT) \
! 	biasexchange.$(OBJEXT) 		hills.$(OBJEXT) 		ptmetad.$(OBJEXT) 	\
! 	read_restraint.$(OBJEXT) 	restraint_alfabeta.$(OBJEXT) 	restraint_angle.$(OBJEXT) 	\
! 	restraint_coord.$(OBJEXT) 	restraint_dihcor.$(OBJEXT) 	restraint_dipole.$(OBJEXT) 	\
! 	restraint_dist.$(OBJEXT) 	restraint_hbonds.$(OBJEXT) 	restraint_mindist.$(OBJEXT) 	\
! 	restraint_rgyr.$(OBJEXT) 	restraint_rmsdtor.$(OBJEXT) 	restraint_spath.$(OBJEXT) 	\
! 	restraint_zpath.$(OBJEXT) 	restraint_position.$(OBJEXT) 	testderivatives.$(OBJEXT) 	\
! 	restraint_torsion.$(OBJEXT) 	restraint_waterbridge.$(OBJEXT)		\
! 	metadyn.$(OBJEXT) 	restraint.$(OBJEXT) 	
  ffscan_OBJECTS = $(am_ffscan_OBJECTS)
  ffscan_LDADD = $(LDADD)
  ffscan_DEPENDENCIES = ../mdlib/libmd_d.la \
***************
*** 85,91 ****
  luck_LDADD = $(LDADD)
  luck_DEPENDENCIES = ../mdlib/libmd_d.la \
  	../gmxlib/libgmx_d.la
! am_mdrun_OBJECTS = glaasje.$(OBJEXT) gctio.$(OBJEXT) init_sh.$(OBJEXT) \
  	ionize.$(OBJEXT) do_gct.$(OBJEXT) relax_sh.$(OBJEXT) \
  	repl_ex.$(OBJEXT) xutils.$(OBJEXT) compute_io.$(OBJEXT) \
  	md.$(OBJEXT) mdrun.$(OBJEXT) genalg.$(OBJEXT)
--- 93,108 ----
  luck_LDADD = $(LDADD)
  luck_DEPENDENCIES = ../mdlib/libmd_d.la \
  	../gmxlib/libgmx_d.la
! am_mdrun_OBJECTS = \
! 	biasexchange.$(OBJEXT) 		hills.$(OBJEXT) 		ptmetad.$(OBJEXT) 	\
! 	read_restraint.$(OBJEXT) 	restraint_alfabeta.$(OBJEXT) 	restraint_angle.$(OBJEXT) 	\
! 	restraint_coord.$(OBJEXT) 	restraint_dihcor.$(OBJEXT) 	restraint_dipole.$(OBJEXT) 	\
! 	restraint_dist.$(OBJEXT) 	restraint_hbonds.$(OBJEXT) 	restraint_mindist.$(OBJEXT) 	\
! 	restraint_rgyr.$(OBJEXT) 	restraint_rmsdtor.$(OBJEXT) 	restraint_spath.$(OBJEXT) 	\
! 	restraint_zpath.$(OBJEXT) 	restraint_position.$(OBJEXT) 	testderivatives.$(OBJEXT) 	\
! 	restraint_torsion.$(OBJEXT) 	restraint_waterbridge.$(OBJEXT)		\
! 	metadyn.$(OBJEXT) 	restraint.$(OBJEXT) 	\
! 	glaasje.$(OBJEXT) gctio.$(OBJEXT) init_sh.$(OBJEXT) \
  	ionize.$(OBJEXT) do_gct.$(OBJEXT) relax_sh.$(OBJEXT) \
  	repl_ex.$(OBJEXT) xutils.$(OBJEXT) compute_io.$(OBJEXT) \
  	md.$(OBJEXT) mdrun.$(OBJEXT) genalg.$(OBJEXT)
***************
*** 131,140 ****
  depcomp = $(SHELL) $(top_srcdir)/config/depcomp
  am__depfiles_maybe = depfiles
  COMPILE = $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) \
! 	$(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)
  LTCOMPILE = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) \
! 	$(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS)
  CCLD = $(CC)
  LINK = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=link $(CCLD) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) \
--- 148,157 ----
  depcomp = $(SHELL) $(top_srcdir)/config/depcomp
  am__depfiles_maybe = depfiles
  COMPILE = $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) \
! 	$(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -DGROMACS3 
  LTCOMPILE = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) \
! 	$(AM_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -DGROMACS3 
  CCLD = $(CC)
  LINK = $(LIBTOOL) --tag=CC $(AM_LIBTOOLFLAGS) $(LIBTOOLFLAGS) \
  	--mode=link $(CCLD) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) \
***************
*** 335,340 ****
--- 352,365 ----
  	x2top.h
  
  mdrun_SOURCES = \
+ 	biasexchange.c 		hills.c 		ptmetad.c 	\
+ 	read_restraint.c 	restraint_alfabeta.c 	restraint_angle.c 	\
+ 	restraint_coord.c 	restraint_dihcor.c 	restraint_dipole.c 	\
+ 	restraint_dist.c 	restraint_hbonds.c 	restraint_mindist.c 	\
+ 	restraint_rgyr.c 	restraint_rmsdtor.c 	restraint_spath.c 	\
+ 	restraint_zpath.c 	restraint_position.c 	testderivatives.c 	\
+ 	restraint_torsion.c 	restraint_waterbridge.c 	\
+ 	metadyn.c 	restraint.c 	\
  	glaasje.c 	glaasje.h 	gctio.c 	init_sh.c 	\
  	ionize.c 	ionize.h 	xmdrun.h	\
  	do_gct.c 	relax_sh.c	repl_ex.c	repl_ex.h	\
***************
*** 447,452 ****
--- 472,499 ----
  distclean-compile:
  	-rm -f *.tab.c
  
+ include ./$(DEPDIR)/biasexchange.Plo
+ include ./$(DEPDIR)/hills.Plo
+ include ./$(DEPDIR)/metadyn.Plo
+ include ./$(DEPDIR)/ptmetad.Plo
+ include ./$(DEPDIR)/read_restraint.Plo
+ include ./$(DEPDIR)/restraint.Plo
+ include ./$(DEPDIR)/restraint_alfabeta.Plo
+ include ./$(DEPDIR)/restraint_angle.Plo
+ include ./$(DEPDIR)/restraint_coord.Plo
+ include ./$(DEPDIR)/restraint_dihcor.Plo
+ include ./$(DEPDIR)/restraint_dipole.Plo
+ include ./$(DEPDIR)/restraint_dist.Plo
+ include ./$(DEPDIR)/restraint_hbonds.Plo
+ include ./$(DEPDIR)/restraint_mindist.Plo
+ include ./$(DEPDIR)/restraint_position.Plo
+ include ./$(DEPDIR)/restraint_rgyr.Plo
+ include ./$(DEPDIR)/restraint_rmsdtor.Plo
+ include ./$(DEPDIR)/restraint_spath.Plo
+ include ./$(DEPDIR)/restraint_torsion.Plo
+ include ./$(DEPDIR)/restraint_waterbridge.Plo
+ include ./$(DEPDIR)/restraint_zpath.Plo
+ include ./$(DEPDIR)/testderivatives.Plo
  include ./$(DEPDIR)/add_par.Po
  include ./$(DEPDIR)/compute_io.Po
  include ./$(DEPDIR)/convparm.Po
EOF
             patch -c -l -b -F 3 --suffix=.premeta ${file} < ${file}.patch
             rm -rf ${file}.patch
         fi
#
#
# creating empty (and useless) Plo files...
#
echo "# dummy" > ./.deps/biasexchange.Plo
echo "# dummy" > ./.deps/hills.Plo
echo "# dummy" > ./.deps/metadyn.Plo
echo "# dummy" > ./.deps/ptmetad.Plo
echo "# dummy" > ./.deps/read_restraint.Plo
echo "# dummy" > ./.deps/restraint_alfabeta.Plo
echo "# dummy" > ./.deps/restraint_angle.Plo
echo "# dummy" > ./.deps/restraint.Plo
echo "# dummy" > ./.deps/restraint_coord.Plo
echo "# dummy" > ./.deps/restraint_dihcor.Plo
echo "# dummy" > ./.deps/restraint_dipole.Plo
echo "# dummy" > ./.deps/restraint_dist.Plo
echo "# dummy" > ./.deps/restraint_hbonds.Plo
echo "# dummy" > ./.deps/restraint_mindist.Plo
echo "# dummy" > ./.deps/restraint_position.Plo
echo "# dummy" > ./.deps/restraint_rgyr.Plo
echo "# dummy" > ./.deps/restraint_rmsdtor.Plo
echo "# dummy" > ./.deps/restraint_spath.Plo
echo "# dummy" > ./.deps/restraint_torsion.Plo
echo "# dummy" > ./.deps/restraint_waterbridge.Plo
echo "# dummy" > ./.deps/restraint_zpath.Plo
echo "# dummy" > ./.deps/testderivatives.Plo
cd ../../
#
# reverts
#
   elif [ "$1" =  "-revert" ] ; then
        found=1
   	echo "REVERTING TO OLD FILES:"
        cd src/kernel
        for i in `ls -1 ${plumedir}/common_files  | grep -v CVS | grep -v rex`
        do
            rm $i
        done
        rm ./.deps/biasexchange.Plo
        rm ./.deps/hills.Plo
        rm ./.deps/metadyn.Plo
        rm ./.deps/ptmetad.Plo
        rm ./.deps/read_restraint.Plo
        rm ./.deps/restraint_alfabeta.Plo
        rm ./.deps/restraint_angle.Plo
        rm ./.deps/restraint.Plo
        rm ./.deps/restraint_coord.Plo
        rm ./.deps/restraint_dihcor.Plo
        rm ./.deps/restraint_dipole.Plo
        rm ./.deps/restraint_dist.Plo
        rm ./.deps/restraint_hbonds.Plo
        rm ./.deps/restraint_mindist.Plo
        rm ./.deps/restraint_position.Plo
        rm ./.deps/restraint_rgyr.Plo
        rm ./.deps/restraint_rmsdtor.Plo
        rm ./.deps/restraint_spath.Plo
        rm ./.deps/restraint_torsion.Plo
        rm ./.deps/restraint_waterbridge.Plo
        rm ./.deps/restraint_zpath.Plo
        rm ./.deps/testderivatives.Plo
        file="Makefile"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="md.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="mdrun.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="repl_ex.h"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        file="repl_ex.c"
        if  [ -e "${file}.premeta" ];   
        then
   	    echo "REVERTING ${file}"
            mv ${file}.premeta ${file}
        else
           echo "IT LOOKS YOU DON'T A BACKUP FILE of ${file} (maybe you never patched)"
        fi
        cd ../../
   elif [ "$found" = "0" ]  
   then
     echo "WRONG KEYWORD "
     echo "USAGE :"
     echo "./plumedpatch_gromacs_3.3.3.sh  (-patch) (-revert)   "
     echo " -patch  : apply PluMeD patch " 
     echo " -revert : revert code to original "     
     exit
   fi
fi
