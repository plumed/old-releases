#!/bin/bash
#
#  Patch to interface DL_POLY_2.19 with the PluMeD plugin
#  The patched files are:
#     config_module.f
#     define_system_module.f
#     forces_module.f
#     dlpoly.f 
#
#  Example of an alternative way to patch dlpoly 2.19 with the PluMeD plugin and compile it with gfortran and gcc
#  
#  put in a directory the dlpoly tar file (dl_poly_2.19.tar.gz) and
#  the PluMeD directory (here named plumed) then use the following command sequence:
#  
#  tar zxf dl_poly_2.19.tar.gz
#  export plumedir=${PWD}/plumed
#  cd dl_poly_2.19
#  $plumedir/patches/plumedpatch_dlpoly_2.19.sh -patch
#  cp build/MakeSEQ srcmod/Makefile
#  cd srcmod
#  make gfortran
#
#  Have fun!
#

if [ "$#" -eq 0 ];then
  echo "USAGE :"
  echo "./plumedpatch_dlpoly_2.19.sh  (-patch) (-revert)   "
  echo " -patch  : apply PluMeD patch "
  echo " -revert : revert code to original "
  exit
elif [ "$#" -eq 1  ];then
  if [ "$1" =  "-patch" ] ; then
    cd srcmod

    file="config_module.f"
    if  [ -e "${file}.premeta" ];then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** ../original_srcmod/config_module.f	2008-07-22 17:39:21.000000000 +0800
--- ./config_module.f	2008-10-22 10:38:41.000000000 +0800
***************
*** 37,42 ****
--- 37,48 ----
  
        real(8), allocatable :: buffer(:)
  
+ c PluMeD variables
+       logical, save :: lplumed  
+       character(len=20) :: plumedfile
+       character(len=80) :: parse_file
+ c end PluMeD variables
+ 
        save atmnam,neulst,lstneu,cfgname,sysname
        save cell,xxx,yyy,zzz,vxx,vyy,vzz,fxx,fyy,fzz
        save buffer,weight,chge,ltype,lstfrz,flx,fly,flz
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch 
    fi 

    file="define_system_module.f"
    if  [ -e "${file}.premeta" ];then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** ../original_srcmod/define_system_module.f	2008-07-22 17:39:21.000000000 +0800
--- ./define_system_module.f	2008-10-22 15:10:48.000000000 +0800
***************
*** 215,220 ****
--- 214,224 ----
        prechk=.false.
        tadall=.false.
  
+ c PluMeD defaults
+       lplumed   = .false.
+       plumedfile="plumed.dat"
+ c end PluMeD defaults
+ 
  c     open the simulation input file
        
        if(idnode.eq.0) open(nread,file='CONTROL',status='old')
***************
*** 248,253 ****
--- 249,268 ----
          
          if(record(1).eq.'#'.or.record(1).eq.' ') then
  
+ c PluMeD modifications
+ 
+         elseif(findstring('plumed ',directive,idum)) then
+              if(findstring('on',directive,idum) ) lplumed=.true.
+              if(findstring('off',directive,idum)) lplumed=.false.
+ 
+         elseif(findstring('plumedfile',directive,idum)) then
+              do i=1,80
+                parse_file(i:i)=record(i)
+              enddo
+              read(parse_file,*)plumedfile,plumedfile
+ 
+ c end PluMeD modifications
+ 
  c     record is commented out
            
          elseif(findstring('steps',directive,idum))then
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch 
    fi 

    file="forces_module.f"
    if  [ -e "${file}.premeta" ];then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** ../original_srcmod/forces_module.f	2008-07-22 17:39:21.000000000 +0800
--- ./forces_module.f	2008-10-22 16:16:07.000000000 +0800
***************
*** 246,251 ****
--- 246,258 ----
        if(keyfld.gt.0)call extnfld
       x  (idnode,imcon,keyfld,mxnode,natms,engfld,virfld)
        
+ c PluMeD modifications
+ 
+       if(idnode==0 .and. lplumed) call meta_force_calculation
+      x  (cell,nstep,xxx,yyy,zzz,fxx,fyy,fzz) 
+ 
+ c PluMeD modifications
+ 
  c     global summation of force arrays (basic replicated data strategy)
        
        call global_sum_forces(natms,mxnode,fxx,fyy,fzz)
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch 
    fi 


    file="dlpoly.f"
    if  [ -e "${file}.premeta" ];then
      echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** ../original_srcmod/dlpoly.f	2008-07-22 17:39:21.000000000 +0800
--- ./dlpoly.f	2008-10-24 18:04:27.000000000 +0800
***************
*** 227,232 ****
--- 230,248 ----
       x  chip,chit,conint,elrc,engunit,virlrc,rvdw,volm,virtot,
       x  vircom,tboost)
        
+ c PluMeD modifications
+ 
+       if(idnode==0 .and. lplumed)then
+         call init_metadyn
+      x (natms, tstep, weight, chge, imcon, engunit,
+      x  trim(plumedfile)//char(0))
+         write(nrite,'(/a22)' )"-- PLUMED ENABLED --  "
+         write(nrite,'(a22,a)')"   PLUMED INPUT FILE: ",trim(plumedfile)
+         call flush(nrite)
+       endif
+ 
+ c PluMeD modifications
+ 
  c     zero long range component of stress
        
        do i=1,9
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch 
    fi 

    # link PluMeD files from common_files directory into Plumed
    mkdir Plumed ; cd Plumed
    ln -s ${plumedir}/common_files/*.h ./
    ln -s ${plumedir}/common_files/*.c ./
    cd ../

    # to be removed whem a pbc routine common to all the codes will be written
    awk '/subroutine images/{print;for(i=0;i<230;i++){getline;print;if($2=="subroutine")exit}}' utility_module.f >  images.f
    awk '/subroutine invert/{print;for(i=0;i<230;i++){getline;print;if($2=="subroutine")exit}}' utility_module.f >> images.f

    # Patch makefiles
    cd ../build
    file="MakeSEQ"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** /Users/paolo/Programs/Suites/dlpoly/dl_poly_2.19/build/MakeSEQ	Thu Apr 10 18:26:22 2008
--- ./MakeSEQ	Mon Jul 21 21:33:23 2008
***************
*** 36,41 ****
--- 36,65 ----
  
  OBJ_PAR = serial.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o \
+ 	images.o
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 190,197 ****
  #=====================================================================
  # Default code for sequential execution
  
! seq: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
--- 215,222 ----
  #=====================================================================
  # Default code for sequential execution
  
! seq: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 205,218 ****
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
  .c.o: 
! 	$(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 230,244 ----
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
+ 
  .c.o:  
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi

    file="MakePAR"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** /Users/paolo/Programs/Suites/dlpoly/dl_poly_2.19/build/MakePAR	Thu Apr 10 18:26:22 2008
--- ./MakePAR	Mon Jul 21 21:33:14 2008
***************
*** 36,41 ****
--- 36,65 ----
  
  OBJ_PAR = basic_comms.o merge_tools.o pass_tools.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o \
+ 	images.o
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 99,106 ****
  #=====================================================================
  # Default code for parallel (MPI) execution
  
! par: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
--- 124,131 ----
  #=====================================================================
  # Default code for parallel (MPI) execution
  
! par: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 114,127 ****
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
  .c.o: 
! 	$(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 139,153 ----
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
+ 
  .c.o:  
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi

    file="MakeWIN"
    if  [ -e "${file}.premeta" ];
    then
       echo "${file} FILE ALREADY PATCHED: skipped" 
    else
      cat >${file}.patch<<\EOF
*** /Users/paolo/Programs/Suites/dlpoly/dl_poly_2.19/build/MakeWIN	Thu Apr 10 18:26:22 2008
--- ./MakeWIN	Mon Jul 21 21:35:01 2008
***************
*** 36,41 ****
--- 36,65 ----
  
  OBJ_PAR = serial.o
  
+ HEAD_METAD = Plumed/metadyn.h
+ 
+ OBJ_METAD = Plumed/hills.o \
+ 	Plumed/metadyn.o \
+ 	Plumed/read_restraint.o \
+ 	Plumed/restraint.o \
+ 	Plumed/restraint_alfabeta.o \
+ 	Plumed/restraint_angle.o \
+ 	Plumed/restraint_coord.o \
+ 	Plumed/restraint_dihcor.o \
+ 	Plumed/restraint_dipole.o \
+ 	Plumed/restraint_dist.o \
+ 	Plumed/restraint_hbonds.o \
+ 	Plumed/restraint_mindist.o \
+ 	Plumed/restraint_rgyr.o \
+ 	Plumed/restraint_rmsdtor.o \
+ 	Plumed/restraint_spath.o \
+ 	Plumed/restraint_torsion.o \
+ 	Plumed/restraint_waterbridge.o \
+ 	Plumed/restraint_zpath.o \
+ 	Plumed/restraint_position.o \
+ 	Plumed/testderivatives.o \
+ 	images.o
+ 
  #=====================================================================
  # Define targets
  all:
***************
*** 62,69 ****
  #=====================================================================
  # Default code for Windows execution
  
! win: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
--- 87,94 ----
  #=====================================================================
  # Default code for Windows execution
  
! win: check $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
! 	$(LD) $(EX) $(LDFLAGS) $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC)
  	mv $(EX) $(EXE)
  
  #=====================================================================
***************
*** 77,90 ****
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
  .c.o: 
! 	$(CC) -c $*.c
  
  #=====================================================================
  # Declare dependency on module files
--- 102,116 ----
  #=====================================================================
  # Clean up the source directory
  clean:
! 	rm -f $(OBJ_MOD) $(OBJ_PAR) $(OBJ_METAD) $(OBJ_SRC) *.mod
  
  #=====================================================================
  # Declare dependencies
  .f.o: 
  	$(FC) $(FFLAGS) $*.f
+ 
  .c.o:  
! 	$(CC) -DDL_POLY -c $(CFLAGS) $(HEAD_METAD) $< -o $@
  
  #=====================================================================
  # Declare dependency on module files
EOF
      patch -c -l -b --suffix=.premeta ${file} < ${file}.patch
      rm -rf ${file}.patch
    fi
    cd ../
  elif [ "$1" =  "-revert" ] ; then
    echo "REVERTING TO OLD FILES:"
    cd srcmod
    for file in config_module.f define_system_module.f forces_module.f dlpoly.f ; do
      if  [ -e "${file}.premeta" ];   
      then
        echo "REVERTING ${file}"
        mv ${file}.premeta ${file}
      else
        echo "IT LOOKS YOU DON'T HAVE A BACKUP FILE of ${file} (maybe you never patched)"
      fi
    done
    # remove metadynamics files from current directory 
    rm -fr Plumed

    # Makefiles
    cd ../build
    for file in MakeSEQ MakePAR MakeWIN ; do
      if  [ -e "${file}.premeta" ];   
      then
        echo "REVERTING ${file}"
        mv ${file}.premeta ${file}
      else
        echo "IT LOOKS YOU DON'T HAVE A BACKUP FILE of ${file} (maybe you never patched)"
      fi
    done
    cd ../

  else
    echo "WRONG KEYWORD "
    echo "USAGE :"
    echo "./plumedpatch_dlpoly_2.19.sh  (-patch) (-revert)   "
    echo " -patch  : apply PluMeD patch "
    echo " -revert : revert code to original "
    exit
  fi
fi
