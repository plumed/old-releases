/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#include "metadyn.h"

void PREFIX restraint(struct mtd_data_s *mtd_data)
{
  int i_c, ncv, nth, ntrh, ntp, rpxm;             	// indexes for cycles and time

  Vhills = Vwall = 0.;                                 	// Hills and Walls potential energy initialization

  colvar.it=mtd_data->istep;                                                  // update microdynamics step
  if(colvar.it==mtd_data->istep_old){
    logical.not_same_step=0;
  } else {
    logical.not_same_step=1;
    mtd_data->istep_old=colvar.it;
  }

  ncv  = colvar.nconst;                                                  	                // number of CVs
  ntp  = (logical.not_same_step)&&(logical.print)&&(!(colvar.it%colvar.nt_print));			                // have I got to print COLVAR?
  nth  = (logical.not_same_step)&&(logical.do_hills)&&(!(colvar.it%hills.nt_hills))&&(!firstTime);	                // have I got to add HILL?
  ntrh = (logical.not_same_step)&&(logical.do_hills)&&(!(colvar.it%hills.nr_hills))&&(nwalkers>1)&&(!firstTime) ;	// period in steps to read HILLS

  #ifdef GROMACS3
  set_pbc(&metapbc, mtd_data->cell);                                              // set pbc
  if(logical.rpxm) rpxm = !(colvar.it%mtd_data->repl_ex_nst) && (logical.not_same_step);                    // have I got a replica exchange trial
  #endif
  #ifdef GROMACS4
  set_pbc(&metapbc, mtd_data->ePBC, mtd_data->cell);                                              // set pbc
  if(logical.rpxm) rpxm = !(colvar.it%mtd_data->repl_ex_nst);                    // have I got a replica exchange trial
  #endif

  if(logical.debug){						// debug is a GROMACS global which identifies
    test_derivatives(mtd_data);		                       // the use of -debug options in mdrun
    EXIT();			        // allow for only one step of dynamics
  }

  // this cycle is intended to calculate CVs values and derivatives
  for(i_c=0;i_c<ncv;i_c++){
    colvar.ff_hills[i_c] = 0.;                 	// initialization hills forces
    cvw.fwall[i_c] = 0.;      			// initialization walls forces

    if((!colvar.on[i_c])&&(logical.rpxm)&&(!rpxm)&&(!ntp)) continue;

    switch(colvar.type_s[i_c]){
      // geometric CVs
      case 1: dist_restraint(i_c, mtd_data); break;			// DISTANCE
      case 2: mindist_restraint(i_c, mtd_data); break;               	// MINDIST
      case 3: coord_restraint(i_c, mtd_data); break;	              	// COORD
      case 4: angle_restraint(i_c, mtd_data); break;	                // ANGLE
      case 5: torsion_restraint(i_c, mtd_data); break;                  // TORSION
      case 6: alfabeta_restraint(i_c, mtd_data); break;                	// ALPHA-BETA
      // interaction CVs
      case 7: hbonds_restraint(i_c, mtd_data); break;                   // HBONDS
      case 8: dipole_restraint(i_c, mtd_data); break;       		// DIPOLE
      // conformations CVs
      case 11: radgyr_restraint(i_c, mtd_data); break;   	       	// RGYR
      case 14: rmsdtor_restraint(i_c, mtd_data); break;	               	// RMSDTOR
      case 16: dihcor_restraint(i_c, mtd_data); break;                 	// DIHEDRAL-COR
      // water CVs
      case 20: waterbridge_restraint(i_c, mtd_data); break;            	// WATERBRIDGE
      // trajectory CVs
      case 30: spath_restraint(i_c, mtd_data); break;                   // S_MAPPATH
      case 31: zpath_restraint(i_c, mtd_data); break;                   // Z_MAPPATH
      case 32: position_restraint(i_c, mtd_data); break;                // ATOM POSITION
    }
  }


  mtd_data->time=colvar.it*(mtd_data->dt);

  if(logical.commitment) commit_analysis();     // commitment analysis

  // this is the really dynamics code in which we calculate hills forces and then forces on CVs.
  if(logical.do_hills){
    if(logical.widthadapt) hills_adapt();			// to adapt gaussian width 
    if(nth)  hills_add(mtd_data);	                   	// add HILL
    if(ntrh) {
       read_hills(mtd_data,0,repmeta.first);                   	// is it time to read_hills?
       repmeta.first = 0;
    }
    hills_force();						// compute hills force and energy
  }

  for(i_c=0;i_c<ncv;i_c++) apply_force(i_c, mtd_data);          // add force coming from hills, restraint, walls... 

  if(ntp) print_colvar_enercv(mtd_data->time);	        	// dump COLVAR

  if(firstTime)firstTime = 0;			                // the first PluMed step 

}

//------------------------------------------------------------------------------------------

void PREFIX soft_walls_up(int i_c, real ssscale)
{
  real uexp;
  
  // Wall potential: V_wall(s) = sigma*((s-s0+offset)/redux)**n
  // WARNING: n must be even, sigma>0, redux>0; offset>0; s0 can be positive or negative
  uexp = (real) cvw.uexp[i_c];
  cvw.fwall[i_c] += -(cvw.sigma[i_c]/cvw.ueps[i_c])*uexp*pow(ssscale, cvw.uexp[i_c]-1);
  Vwall += cvw.sigma[i_c]*pow(ssscale, cvw.uexp[i_c]);		// in this way we keep in account wall energy
}

void PREFIX  soft_walls_lo(int i_c, real ssscale)
{
  real lexp;

  // Wall potential: V_wall(s) = sigma*((s-s0-offset)/redux)**n
  // WARNING: n must be even, sigma>0, offset>0; redux>0; s0 can be positive or negative
  lexp = (real) cvw.lexp[i_c];
  cvw.fwall[i_c] += -(cvw.lsigma[i_c]/cvw.leps[i_c])*lexp*pow(ssscale, cvw.lexp[i_c]-1);
  Vwall += cvw.lsigma[i_c]*pow(ssscale, cvw.lexp[i_c]);		// in this way we keep in account wall energy
}

//-------------------------------------------------------------------------------------------

void PREFIX steer_cv(int i_c)
{ 
  real force,tmp;
// getting starting point the first time
//  if(colvar.it==0){
  if(firstTime){
   if ( cvsteer.impose_start[i_c] == 0 ) { 
          cvsteer.pos[i_c] = cvsteer.start[i_c] = colvar.ss0[i_c]; } 
   else {    cvsteer.pos[i_c] = cvsteer.start[i_c] ; }   

   fprintf(mtd_data.fplog,"|- STEERING %d CV : STARTVALUE %f\n",i_c+1,cvsteer.start[i_c]);
   fflush(mtd_data.fplog);
 
   if(cvsteer.max[i_c] < cvsteer.start[i_c]){
    cvsteer.sign[i_c] = -1; 
   } else {
    cvsteer.sign[i_c] = +1;
   } 
   // check if you're there since the beginning
   if(cvsteer.pos[i_c]==cvsteer.max[i_c]) {
          fprintf(mtd_data.fplog,"|- STEERING %d CV ARRIVED TO TARGET POINT %f in %d STEPS\n",i_c+1,cvsteer.max[i_c],colvar.it);
          fflush(mtd_data.fplog);
   } 
  } 
  else{ // increase when you're not at the first step 
      if((logical.not_same_step) && fabs(cvsteer.pos[i_c]-cvsteer.start[i_c])<fabs(cvsteer.max[i_c]-cvsteer.start[i_c])) {
              cvsteer.pos[i_c] += cvsteer.sign[i_c] * cvsteer.delta[i_c] / 1000.0;
      }
  } 
  if(fabs(cvsteer.pos[i_c]-cvsteer.start[i_c])>fabs(cvsteer.max[i_c]-cvsteer.start[i_c])) {
    cvsteer.pos[i_c] = cvsteer.max[i_c];
    fprintf(mtd_data.fplog,"|- STEERING %d CV ARRIVED TO TARGET POINT %f in %d STEPS\n",i_c+1,cvsteer.max[i_c],colvar.it);  
    fflush(mtd_data.fplog); 
  }
      /* HERE PUT THE PERIODICITY YOU NEED!!!!!!!! */ 
  tmp=colvar.ss0[i_c]-cvsteer.pos[i_c];
  if(colvar.type_s[i_c]==5 ){
                   if(tmp > M_PI)
                     tmp -= 2.*M_PI;
                   if(tmp < -M_PI)
                    tmp += 2.*M_PI;
  } 
  force = -cvsteer.spring[i_c]*tmp;
  cvw.fwall[i_c] += force;
  Vwall += -0.5*force*tmp; 
}

//---------------------------------------------------------------------------------------------

void PREFIX print_colvar_enercv(real time_s)
{
    int i_c;
    FILE *cv_file;

    cv_file = fopen(colfilen, "at");
    fprintf(cv_file, "%10.3f", time_s);
    for(i_c=0;i_c<colvar.nconst;i_c++) fprintf(cv_file, "   %10.5f", colvar.ss0[i_c]);
    fprintf(cv_file, "   %10.3f   %10.3f ", Vhills/mtd_data.eunit, Vwall/mtd_data.eunit);
    for(i_c=0;i_c<colvar.nconst;i_c++){  if(logical.steer[i_c]){fprintf(cv_file," RESTRAINT %d %10.5f ",i_c+1,cvsteer.pos[i_c] );} }
    fprintf(cv_file, "\n");
    fclose(cv_file);
}

//-----------------------------------------------------------------------------------------------------------------------------

void PREFIX commit_analysis()
{
  int i, a, b;
  FILE *commit_file;

  if(firstTime){
    commit_file = fopen("COMMIT", "at");
    for(i=0;i<colvar.nconst;i++) fprintf(commit_file, "   %14.7f", colvar.ss0[i]);
    fclose(commit_file);
  }

  a = 0;
  b = 0;
  for(i=0;i<colvar.nconst;i++){
    if(colvar.Amin[i]<colvar.ss0[i] && colvar.ss0[i]<colvar.Amax[i]) a++;
    if(colvar.Bmin[i]<colvar.ss0[i] && colvar.ss0[i]<colvar.Bmax[i]) b++;
  }
  if(a==colvar.commit||b==colvar.commit) {
    printf("|- SYSTEM HAS REACHED AN ENDING REGION\n");
    EXIT(); 
    logical.commitment = 0;
    commit_file = fopen("COMMIT", "at");
    if(a==colvar.commit) fprintf(commit_file, " A\n");
    if(b==colvar.commit) fprintf(commit_file, " B\n");
    fclose(commit_file);
  }
}

//----------------------------------------------------------------------------------------------------------------------

void PREFIX apply_force(int i_c, struct mtd_data_s *mtd_data )
{
  real ddr, uscale, lscale, dsdt, nor, fact;
  int ix, i, iat, wall;
  #ifdef NAMD
  Vector f;   
  #endif 

  if(i_c==0){
   for(i=0;i<mtd_data->natoms;i++){
    mtd_data->force[i][0] = 0.0; 
    mtd_data->force[i][1] = 0.0;
    mtd_data->force[i][2] = 0.0;
   }  
  }

  // Soft Walls
  if(logical.upper[i_c]) {							// if there is a soft wall on this cv
    uscale = (colvar.ss0[i_c]-cvw.upper[i_c]+cvw.uoff[i_c])/cvw.ueps[i_c];	// calculates the position on the wall 
    if(uscale>0.) soft_walls_up(i_c, uscale);					// apply the force
  }
  if(logical.lower[i_c]) {							// if there is a soft wall on this cv
    lscale = (colvar.ss0[i_c]-cvw.lower[i_c]-cvw.loff[i_c])/cvw.leps[i_c];	// calculates the position on the wall
    if(lscale<0.) soft_walls_lo(i_c, lscale);					// apply the force
  }

  if(logical.steer[i_c]) steer_cv(i_c);			// do you want to pull this cv with a quadratic potential?

  ddr = colvar.ff_hills[i_c] + cvw.fwall[i_c];		// soft wall and hills contribution
  for(i=0;i<colvar.natoms[i_c];i++) {
    iat = colvar.cvatoms[i_c][i];
#ifdef NAMD 
     f.x=ddr*colvar.myder[i_c][i][0];
     f.y=ddr*colvar.myder[i_c][i][1];
     f.z=ddr*colvar.myder[i_c][i][2];
     addForce(iat,f);
#else
    mtd_data->force[iat][0] += ddr*colvar.myder[i_c][i][0];     // PluMeD forces
    mtd_data->force[iat][1] += ddr*colvar.myder[i_c][i][1];
    mtd_data->force[iat][2] += ddr*colvar.myder[i_c][i][2];
#endif    

  }
}
