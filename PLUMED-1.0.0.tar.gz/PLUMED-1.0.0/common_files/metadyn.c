/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#define EXTERNALS 1
#include "metadyn.h"

#ifdef GROMACS3
void mtd_data_init (real *charge, real *mass, 
                    int natoms, real dt, int repl_ex_nst, int repl, 
                    int nrepl, real rte0, real rteio, const t_commrec *mcr, FILE *fplog)
{
   mtd_data.pos = float_2d_array_alloc(natoms,3);
   mtd_data.force = float_2d_array_alloc(natoms,3);
   mtd_data.vel = float_2d_array_alloc(natoms,3);
   mtd_data.charge = charge;
   mtd_data.mass = mass;
   mtd_data.natoms = natoms;
   mtd_data.repl_ex_nst = repl_ex_nst;
   mtd_data.repl = repl;
   mtd_data.nrepl = nrepl;
   mtd_data.rte0 = rte0;
   mtd_data.rteio = rteio;
   mtd_data.dt = dt;
   mtd_data.mcr = mcr;
   mtd_data.fplog = fplog;
   mtd_data.eunit = 1.;
   mtd_data.istep_old = -1;
   logical.not_same_step=1;
   sprintf(hills.dir, ".");
}

void meta_force_calculation(real (*pos)[3], real (*force)[3], real (*vel)[3], real box[3][3], int istep)
{
   int i;

   copy_mat(box, mtd_data.cell);

   mtd_data.istep = istep;

   for(i=0;i<mtd_data.natoms;i++){
     mtd_data.pos[i][0] = pos[i][0];
     mtd_data.pos[i][1] = pos[i][1];
     mtd_data.pos[i][2] = pos[i][2];
     mtd_data.vel[i][0] = vel[i][0];
     mtd_data.vel[i][1] = vel[i][1];
     mtd_data.vel[i][2] = vel[i][2];
   }

   restraint(&mtd_data);
 
   for(i=0;i<mtd_data.natoms;i++){
     force[i][0] = mtd_data.force[i][0];
     force[i][1] = mtd_data.force[i][1];
     force[i][2] = mtd_data.force[i][2];
   }
}
#elif GROMACS4
void mtd_data_init (int ePBC, real *charge, real *mass, 
                    int natoms, real dt, int repl_ex_nst, int repl, 
                    int nrepl, real rte0, real rteio, const t_commrec *mcr, FILE *fplog)
{
   mtd_data.pos = float_2d_array_alloc(natoms,3);
   mtd_data.force = float_2d_array_alloc(natoms,3);
   mtd_data.vel = float_2d_array_alloc(natoms,3);
   mtd_data.charge = charge;
   mtd_data.mass = mass;
   mtd_data.natoms = natoms;
   mtd_data.repl_ex_nst = repl_ex_nst;
   mtd_data.repl = repl;
   mtd_data.nrepl = nrepl;
   mtd_data.rte0 = rte0;
   mtd_data.rteio = rteio;
   mtd_data.dt = dt;
   mtd_data.mcr = mcr;
   mtd_data.fplog = fplog;
   mtd_data.eunit = 1.;
   mtd_data.ePBC = ePBC;
   mtd_data.istep_old = -1;
   logical.not_same_step=1;
   sprintf(hills.dir, ".");
}

void meta_force_calculation(real (*pos)[3], real (*force)[3], real (*vel)[3], real box[3][3], int istep)
{
   int i;

   copy_mat(box, mtd_data.cell);

   mtd_data.istep = istep;

   for(i=0;i<mtd_data.natoms;i++){
     mtd_data.pos[i][0] = pos[i][0];
     mtd_data.pos[i][1] = pos[i][1];
     mtd_data.pos[i][2] = pos[i][2];
     mtd_data.vel[i][0] = vel[i][0];
     mtd_data.vel[i][1] = vel[i][1];
     mtd_data.vel[i][2] = vel[i][2];
   }

   restraint(&mtd_data);
 
   for(i=0;i<mtd_data.natoms;i++){
     force[i][0] = mtd_data.force[i][0];
     force[i][1] = mtd_data.force[i][1];
     force[i][2] = mtd_data.force[i][2];
   }
}
#elif DRIVER
void mtd_data_init(int atoms, real *mass, real *charge, char *metainp, int pbc, real *box)
{
 int i;
 mtd_data.pos       = float_2d_array_alloc(atoms,3);
 mtd_data.vel       = float_2d_array_alloc(atoms,3);
 mtd_data.force     = float_2d_array_alloc(atoms,3);
 mtd_data.charge    = (real *)calloc(atoms,sizeof(real));
 mtd_data.mass      = (real *)calloc(atoms,sizeof(real));
 mtd_data.natoms    = atoms;
 mtd_data.dt        = 1;
 mtd_data.istep_old = -1;
 mtd_data.istep     = 0;  
 mtd_data.fplog     = stdout;
 mtd_data.imcon     = pbc;
 mtd_data.mcr       = NULL;
 mtd_data.eunit     = 1.;
 logical.not_same_step=1;
 if(mtd_data.imcon==1){
  mtd_data.cell[0]=box[0];
  mtd_data.cell[1]=box[1];
  mtd_data.cell[2]=box[2]; 
 } 

 for(i=0;i<mtd_data.natoms;i++) {
   mtd_data.mass[i]   = mass[i];
   mtd_data.charge[i] = charge[i];
 }
 strcpy(mtd_data.metaFilename, metainp);
}

void cv_calculation_(real *pos, int *ncv, real *cv)
{
 int i;
 for(i=0;i<mtd_data.natoms;i++){
 mtd_data.pos[i][0] = pos[i];
 mtd_data.pos[i][1] = pos[i + mtd_data.natoms];
 mtd_data.pos[i][2] = pos[i + 2*mtd_data.natoms];
 }

 restraint(&mtd_data);
 // step increment
 mtd_data.istep++;

 for(i=0;i<*ncv;i++) cv[i] = colvar.ss0[i];
}


#elif OPEP
void mtd_data_init(int pbc, real tstep,int atoms, int repl, int nrepl, real rte0, real rteio, real *mass, char *lpath, char *logfile, char *metainp)
{
 int i;
 mtd_data.pos       = float_2d_array_alloc(atoms,3); 
 mtd_data.vel       = float_2d_array_alloc(atoms,3);
 mtd_data.force     = float_2d_array_alloc(atoms,3);
 mtd_data.charge    = (real *)calloc(atoms,sizeof(real));
 mtd_data.mass      = (real *)calloc(atoms,sizeof(real));
 mtd_data.natoms    = atoms;
 mtd_data.repl      = repl; 
 mtd_data.nrepl     = nrepl;
 mtd_data.rte0      = rte0;
 mtd_data.rteio     = rteio;
 mtd_data.dt        = tstep; 
 mtd_data.istep_old = -1;
 mtd_data.istep     = 0; 
 mtd_data.mcr       = NULL;
 mtd_data.imcon     = pbc; 
 mtd_data.eunit     = 1.;
 logical.not_same_step=1;
 for(i=0;i<mtd_data.natoms;i++) mtd_data.mass[i] = mass[i];

 strcpy(mtd_data.metaFilename, metainp); 
 if(nrepl==1){
   strcpy(hills.dir, ".");
 }else{
  strcpy(hills.dir, lpath);
 }
 strcpy(mtd_data.log, logfile); 
 mtd_data.fplog = fopen(mtd_data.log,"a"); 

}

void meta_force_calculation_(real *pos, real *force)
{
 int i;
 for(i=0;i<mtd_data.natoms;i++){
 mtd_data.pos[i][0] = pos[i];
 mtd_data.pos[i][1] = pos[i + mtd_data.natoms];
 mtd_data.pos[i][2] = pos[i + 2*mtd_data.natoms];
 }

 restraint(&mtd_data);
 // step increment
 mtd_data.istep++; 
 
 for(i=0;i<mtd_data.natoms;i++){
 force[i]                     = mtd_data.force[i][0];
 force[i + mtd_data.natoms]   = mtd_data.force[i][1];
 force[i + 2*mtd_data.natoms] = mtd_data.force[i][2];
 }
}
void share_bias_(int *nrep, int *task)
{
  ptmetad_sharepot(*nrep,*task); 
}

void meta_corrections_(int *r1,int *r2, real *delta1, real *delta2)
{
 real Epota, Epotb, Epotba, Epotab;

 Epota  = 0.0; 
 Epotb  = 0.0; 
 Epotba = 0.0; 
 Epotab = 0.0; 

 ptmetad(&Epota,&Epotb,&Epotba,&Epotab,*r1,*r2);
 *delta1=Epota-Epotab;
 *delta2=Epotb-Epotba;

}
#elif AMBER 
void mtd_data_init(int atoms, real dt ,real *mass, real *charge, char *metainp)
{
 int i ;
 mtd_data.pos=float_2d_array_alloc(atoms,3); 
 mtd_data.vel=float_2d_array_alloc(atoms,3);
 mtd_data.force=float_2d_array_alloc(atoms,3);
 mtd_data.charge=(real *)calloc(atoms,sizeof(real));
 for (i=0;i<atoms;i++){mtd_data.charge[i]= charge[i]/18.2223; } // amber conversion 
 mtd_data.mass=(real *)calloc(atoms,sizeof(real));
 for (i=0;i<atoms;i++){mtd_data.mass[i]=mass[i]; } 
 mtd_data.fplog = fopen("log.file","w"); 
 mtd_data.natoms = atoms;
 mtd_data.dt = dt*1000. ; // timestep from ps to fs  
 mtd_data.repl  = -1;
 mtd_data.eunit = 1.;
 strcpy(mtd_data.metaFilename,metainp); 
 sprintf(hills.dir, ".");
 logical.not_same_step=1;
 mtd_data.istep_old = -1;
 mtd_data.istep = 0;
}
void meta_force_calculation__(real *box, real *rrr,real *fff, int *nn)
{
 int i;
 mtd_data.istep = (*nn);
 //cell ??
 if((box[0]==0.)&&(box[0]==box[1])&&(box[0]==box[2])) { 
    //no cell
     mtd_data.imcon=0;
 }else{
     mtd_data.imcon=1;
     mtd_data.cell[0]=box[0];
     mtd_data.cell[1]=box[1];
     mtd_data.cell[2]=box[2];
 }
 for (i=0;i<mtd_data.natoms;i++){
      mtd_data.pos[i][0]=rrr[i*3+0];
      mtd_data.pos[i][1]=rrr[i*3+1];
      mtd_data.pos[i][2]=rrr[i*3+2];
 } 
 restraint(&mtd_data);
 
 for(i=0;i<mtd_data.natoms;i++){
   // first convert in kcal
   fff[i*3+0]   += mtd_data.force[i][0]; // conversion from kcal to internal units
   fff[i*3+1]   += mtd_data.force[i][1];
   fff[i*3+2]   += mtd_data.force[i][2];
  // printf("FORCE %d %f %f %f\n",i, mtd_data.force[i][0], mtd_data.force[i][1], mtd_data.force[i][2]);
 }

}
#elif DL_POLY
void mtd_data_init(int atoms, real dt ,real *mass, real *charge, int *imcon, real *eunit, char *metainp)
{
 int i ;
 mtd_data.pos=float_2d_array_alloc(atoms,3);
 mtd_data.vel=float_2d_array_alloc(atoms,3);
 mtd_data.force=float_2d_array_alloc(atoms,3);
 mtd_data.charge=(real *)calloc(atoms,sizeof(real));
 for (i=0;i<atoms;i++){mtd_data.charge[i]= charge[i]; }
 mtd_data.mass=(real *)calloc(atoms,sizeof(real));
 for (i=0;i<atoms;i++){mtd_data.mass[i]=mass[i]; }
 mtd_data.fplog = fopen("PLUMED.OUT","a");
 mtd_data.natoms = atoms;
 mtd_data.dt = dt ; // the timestep is kept in ps
 mtd_data.repl = -1;
 mtd_data.istep_old = -1;
 mtd_data.eunit=(*eunit);
 mtd_data.imcon=(* imcon);
 strcpy(mtd_data.metaFilename,metainp);
 sprintf(hills.dir, ".");
 logical.not_same_step=1;
}
void meta_force_calculation_(real *cell, int *istep, real *xxx, real *yyy, real *zzz, real *fxx, real *fyy, real *fzz)
{
 int i;
 // cell type 
 // cell size 
 for(i=0;i<9;i++)mtd_data.cell[i]=cell[i]; 
 mtd_data.istep=(* istep); // <---paolo
 for(i=0;i<mtd_data.natoms;i++){
   mtd_data.pos[i][0] = xxx[i];
   mtd_data.pos[i][1] = yyy[i];
   mtd_data.pos[i][2] = zzz[i];
   //printf("POS %d %f %f %f\n",i, mtd_data.pos[i][0], mtd_data.pos[i][1], mtd_data.pos[i][2]);
 }

 restraint(&mtd_data);
 
 for(i=0;i<mtd_data.natoms;i++){
   fxx[i]   += mtd_data.force[i][0]; 
   fyy[i]   += mtd_data.force[i][1];
   fzz[i]   += mtd_data.force[i][2];
   //printf("FORCE %d %f %f %f\n",i, mtd_data.force[i][0], mtd_data.force[i][1], mtd_data.force[i][2]);
 }

}
#elif NAMD

PREFIX GlobalMasterMetaDynamics() :
    GlobalMasterEasy("metaDynamicsScript")
{
// Initialize subclass and get current config
    easy_init(config);
}

// easy_init and easy_calc are virtuals of GlobalMasterEasy: must be defined anyway
void PREFIX easy_init(const char *config) {
  int i,j,i_c;

// PluMeD initialization 
  init_metadyn();

// requesting atom to NAMD
    for(i_c=0;i_c<colvar.nconst;i_c++){
            for(i=0;i<colvar.natoms[i_c];i++){
                    j=colvar.cvatoms[i_c][i];
                    if(requestAtom(j)){
                     printf("ATOM ID %i DOESN'T EXIST\n",j);
                     EXIT(); 
                    }
            }
    }
}

void PREFIX  easy_calc() {
    Vector coord_from;
    int i,j,i_c;

// getting atom positions
    for(i_c=0;i_c<colvar.nconst;i_c++){
            for(i=0;i<colvar.natoms[i_c];i++){
                    j=colvar.cvatoms[i_c][i];
                    getPosition(j,coord_from);
                    mtd_data.pos[j][0]=coord_from.x;
                    mtd_data.pos[j][1]=coord_from.y;
                    mtd_data.pos[j][2]=coord_from.z;
            }
    }

// CV evaluation
    restraint(&mtd_data);
// step increment
    mtd_data.istep++;
}

void PREFIX mtd_data_init()
{
 int i ;
 
 // simparameters contains: cell,dt,lattice and all attributes coming from the namd input file
 SimParameters *spar=Node::Object()->simParameters; 
 // molecule contains atommass, atomcharge,isHydrogen,isOxygen,isWater,bonds_for_atoms,angle_for_atoms methods
 // and other public attributes numAtoms,numBonds,numDihedrals 
 mtd_data.natoms=Node::Object()->molecule->numAtoms; 
 // allocate the common vectors 
 mtd_data.charge=(real *)calloc(mtd_data.natoms,sizeof(real)); 
 mtd_data.mass=(real *)calloc(mtd_data.natoms,sizeof(real)); 
 mtd_data.pos=float_2d_array_alloc(mtd_data.natoms,3);
 mtd_data.vel=float_2d_array_alloc(mtd_data.natoms,3);
 mtd_data.force=float_2d_array_alloc(mtd_data.natoms,3);
 sprintf(hills.dir, ".");

 for(i=0;i<mtd_data.natoms;i++){mtd_data.mass[i]=Node::Object()->molecule->atommass(i);/* printf("ATOMMASS %d %f\n",i,mtd_data.mass[i]);*/};
 for(i=0;i<mtd_data.natoms;i++){mtd_data.charge[i]=Node::Object()->molecule->atomcharge(i);/*printf("ATOMCHARGE %d %f\n",i,mtd_data.charge[i]);*/};
 strcpy(mtd_data.metaFilename,spar->metaFilename);
 mtd_data.fplog = stdout;
 mtd_data.repl=-1;// always consider it as normal md
 mtd_data.dt=spar->dt;
 mtd_data.eunit = 1.;
 mtd_data.istep_old = -1;
 mtd_data.istep = 0;
 logical.not_same_step=1;
}
void PREFIX rvec2vec(rvec rv,Vector *v)
{
v->x=rv[0];
v->y=rv[1];
v->z=rv[2];
}
#endif
// Vector operation, angle etc etc...
#if !defined(GROMACS3) && !defined(GROMACS4)
void PREFIX oprod(const rvec a,const rvec b,rvec c)
{
  c[0]=a[1]*b[2]-a[2]*b[1];
  c[1]=a[2]*b[0]-a[0]*b[2];
  c[2]=a[0]*b[1]-a[1]*b[0];
}
real PREFIX iprod(const rvec a,const rvec b)
{
  return (a[0]*b[0]+a[1]*b[1]+a[2]*b[2]);
}
real PREFIX norm(const rvec a)
{
  return sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
}
real PREFIX norm2(const rvec a)
{
  return a[0]*a[0]+a[1]*a[1]+a[2]*a[2];
}
real PREFIX cos_angle(const rvec a,const rvec b)
{
  real   cos;
  int    m;
  real aa,bb,ip,ipa,ipb;
  ip=ipa=ipb=0.0;
  for(m=0; (m<3); m++) {
    aa   = a[m];
    bb   = b[m];
    ip  += aa*bb;
    ipa += aa*aa;
    ipb += bb*bb;
  }
  cos=ip/sqrt(ipa*ipb);
  if (cos > 1.0)
    return  1.0;
  if (cos <-1.0)
    return -1.0;
  return cos;
}
real PREFIX dih_angle(rvec xi, rvec xj, rvec xk, rvec xl,
               rvec r_ij,rvec r_kj,rvec r_kl,rvec m,rvec n,
               real *cos_phi,real *sign)
{
  real ipr,phi;
  real mod_rij, mod_rkj, mod_rkl;

  minimal_image(xi, xj, &mod_rij, r_ij);
  minimal_image(xk, xj, &mod_rkj, r_kj);
  minimal_image(xk, xl, &mod_rkl, r_kl); 

  oprod(r_ij,r_kj,m);               
  oprod(r_kj,r_kl,n);               
  *cos_phi=cos_angle(m,n);          
  phi=acos(*cos_phi);               
  ipr=iprod(r_ij,n);                
  (*sign)=(ipr<0.0)?-1.0:1.0;
  phi=(*sign)*phi;                 
                                   
  return phi;
}
void PREFIX clear_rvec(rvec a)
{
  a[0]=0.0;
  a[1]=0.0;
  a[2]=0.0;
}
#endif

// MPI stuff
#ifdef MPI
#if !defined(GROMACS3) && !defined(GROMACS4)
void gmx_sum(int nr,real r[], const t_commrec *mcr)
{
  static real *buf;
  static int nalloc=0;
  int i;

  if (nr > nalloc) {
    nalloc = nr;
    snew(buf,nalloc);
  }
  int myrank; MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
        MPI_Allgather(&r[myrank],1,MPI_DOUBLE,buf,1,MPI_DOUBLE,MPI_COMM_WORLD);
  for(i=0; i<nr; i++)
    r[i] = buf[i];
}
void gmx_sumi(int nr,int r[], const t_commrec *mcr)
{
  static int *buf;
  static int nalloc=0;
  int i;

  if (nr > nalloc) {
    nalloc = nr;
    snew(buf,nalloc);
  }
  int myrank; MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
        MPI_Allgather(&r[myrank],1,MPI_INT,buf,1,MPI_INT,MPI_COMM_WORLD);
  for(i=0; i<nr; i++)
    r[i] = buf[i];
}
#endif
#ifndef GROMACS4
void gmx_sumli(int nr,long int r[], const t_commrec *mcr)
{
  static long int *buf;
  static int nalloc=0;
  int i;

  if (nr > nalloc) {
    nalloc = nr;
    snew(buf,nalloc);
  }
  int myrank; MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
        MPI_Allgather(&r[myrank],1,MPI_LONG,buf,1,MPI_LONG,MPI_COMM_WORLD);
  for(i=0; i<nr; i++)
    r[i] = buf[i];
}
#else
void gmx_sumli_sim(int nr,long int r[],const gmx_multisim_t *ms)
{
  static long int *buf=NULL;
  static int nalloc=0;
  int i;

  if (nr > nalloc) {
    nalloc = nr;
    srenew(buf,nalloc);
  }
  MPI_Allreduce(r,buf,nr,MPI_LONG,MPI_SUM,ms->mpi_comm_masters);
  for(i=0; i<nr; i++)
    r[i] = buf[i];
}
#endif
#endif
// random number
#if defined (OPEP) || defined (DRIVER)
real rando(int *ig)
     /* generate a random number. */
{
  int  irand;

  int  m    = 100000000;
  real rm   = 100000000.0;  /* same number as m, but real format */
  int  m1   = 10000;
  int  mult = 31415821;

  real r;
  int  irandh,irandl,multh,multl;

  irand = abs(*ig) % m;

  /* multiply irand by mult, but take into account that overflow
   * must be discarded, and do not generate an error.
   */
  irandh = irand / m1;
  irandl = irand % m1;
  multh  = mult / m1;
  multl  = mult % m1;
  irand  = ((irandh*multl+irandl*multh) % m1) * m1 + irandl*multl;
  irand  = (irand + 1) % m;

  /* convert irand to a real random number between 0 and 1. */
  r = (irand / 10);
  r = r * 10 / rm;
  if ((r <= 0) || (r > 1))
    r = 0.0;
  *ig = irand;

  return r;
}
#endif
// different init_metadyn
#ifdef GROMACS3
void init_metadyn(int natoms, real box[3][3], real *charge, real *mass, 
                  real dt, int repl_ex_nst, int repl, int nrepl, 
                  real rte0, real rteio, const t_commrec *mcr, FILE *fplog)
#elif GROMACS4
void init_metadyn(int natoms, real box[3][3], int ePBC, real *charge, real *mass, 
                  real dt, int repl_ex_nst, int repl, int nrepl, 
                  real rte0, real rteio, const t_commrec *mcr, FILE *fplog)
#elif NAMD
void PREFIX init_metadyn()
#elif OPEP
void init_metadyn_(int *atoms, real *ddt, int *pbc_opep, 
                   int *repl, int *nrepl,real *rte0, real *rteio, real *mass,
                   char *lpath, char *logfile, char *metainp, int ll, int mm, int jj) 
#elif DL_POLY
void init_metadyn_(int *atoms, real *ddt, real *mass, real *charge, int *imcon, real *eunit, char *metainp, int pp) 
#elif DRIVER
void init_metadyn_(int *atoms, real *mass, real *charge, int *pbc, real *box, char *metainp, int ll)
#elif AMBER
void init_metadyn__( int *atoms, real *ddt,real *mass, real *charge ,char *metainp, int ll)
#endif
{
  int i;
  long int j;
  real k;
  char stringa[800], histfile[100];
  FILE *fp;

#ifdef GROMACS3
  copy_mat(box, mtd_data.cell); 
  mtd_data_init (charge, mass, natoms, dt, repl_ex_nst, repl, nrepl, 
                 rte0, rteio, mcr, fplog);
  set_pbc(&metapbc, mtd_data.cell);				// set pbc
#elif GROMACS4
  copy_mat(box, mtd_data.cell); 
  mtd_data_init (ePBC, charge, mass, natoms, dt, repl_ex_nst, repl, nrepl, 
                 rte0, rteio, mcr, fplog);
  set_pbc(&metapbc, ePBC, mtd_data.cell);				// set pbc
#elif NAMD
  mtd_data_init();
#elif OPEP
  mtd_data_init(*pbc_opep,*ddt,*atoms,*repl,*nrepl,*rte0,*rteio,mass,lpath,logfile,metainp);
#elif DL_POLY
  mtd_data_init( *atoms , *ddt , mass, charge , imcon, eunit, metainp);
#elif DRIVER
  mtd_data_init( *atoms, mass, charge, metainp, *pbc, box);
#elif AMBER
   mtd_data_init(*atoms, *ddt, mass,charge, metainp);
#endif

  read_restraint(&mtd_data);             // read META_INP


  if(colvar.nconst==0) return;                          // no CVs, no party!
  firstTime = 1;                                        // it is the first step!
  hills.ntothills = 0;
  sprintf(colfilen, "COLVAR");
  sprintf(hilfilen, "%s/HILLS", hills.dir);
  sprintf(locfilen, "%s/LOCK", hills.dir);
  if(logical.remd){                                     // in replica exchange case
    sprintf(colfilen, "%s/COLVAR%i", hills.dir, mtd_data.repl);
    sprintf(hilfilen, "%s/HILLS%i",  hills.dir, mtd_data.repl);
    sprintf(locfilen, "%s/LOCK%i",   hills.dir, mtd_data.repl);
  }
  if(logical.do_hills){
    if(logical.remd){
      repmeta.on = int_2d_array_alloc(colvar.nconst,mtd_data.nrepl);
      for(i=0;i<colvar.nconst; i++) {
        repmeta.on[i][mtd_data.repl] = colvar.on[i];
#ifdef MPI
#ifndef GROMACS4
        gmx_sumi(mtd_data.nrepl, repmeta.on[i], mtd_data.mcr);
#else
        gmx_sumi_sim(mtd_data.nrepl, repmeta.on[i], mtd_data.mcr->ms);
#endif
#endif
      }
    }
    if(logical.restart_hills) {
      read_hills(&mtd_data,1,repmeta.first);    	// if restart
    } else {                                           	// if not restart

      if(nwalkers==1){
        sprintf(stringa, "%s.old", hilfilen);
        rename(hilfilen, stringa);
        sprintf(histfile, "HISTOGRAM");
        if(logical.remd) sprintf(histfile, "HISTOGRAM%i", mtd_data.repl);
        sprintf(stringa, "%s.old", histfile);
        rename(histfile, stringa);
      }
      hills.ntothills = STACKDIM ;// dimesion of hills vector
      hills.ss0_t     = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst); 
      hills.ww        = (real *) calloc(hills.ntothills,sizeof(real));
      colvar.delta_s  = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst);
      if(logical.remd){
        repmeta.ww      = float_2d_array_alloc(hills.ntothills,mtd_data.nrepl);  
        repmeta.delta_r = float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data.nrepl);  
        repmeta.ss0_t   = float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data.nrepl); 
        repmeta.RVhills = (real *)calloc(mtd_data.nrepl,sizeof(real));
        repmeta.RVwalls = (real *)calloc(mtd_data.nrepl,sizeof(real));
        repmeta.ss0     = float_2d_array_alloc(colvar.nconst,mtd_data.nrepl);
        repmeta.nhills  = (long int *)calloc(mtd_data.nrepl,sizeof(long int));
        if(logical.widthadapt){
         repmeta.fluct   = float_2d_array_alloc(colvar.nconst,mtd_data.nrepl);
         repmeta.fluct2  = float_2d_array_alloc(colvar.nconst,mtd_data.nrepl);
        }
      }
    }

    for(j=0;j<GTAB;j++) {
      k = (real) DP2CUTOFF/GTAB*j;
      hills.exp[j] = exp(-k);
    }  
  }
}
void PREFIX minimal_image(rvec pos1, rvec pos2, real *mod_rij, rvec rij)
{
#ifdef NAMD
Vector Vect1,Vect2,rij_v;
rvec2vec(pos1,&Vect1);
rvec2vec(pos2,&Vect2);
rij_v=Node::Object()->simParameters->lattice.delta(Vect1,Vect2);
*mod_rij=rij_v.length();
rij[0]=rij_v.x;
rij[1]=rij_v.y;
rij[2]=rij_v.z;
#elif defined (GROMACS3) || defined (GROMACS4)
 pbc_dx(&metapbc, pos1, pos2, rij);
 *mod_rij = sqrt(rij[0]*rij[0] + rij[1]*rij[1] + rij[2]*rij[2]);
#elif OPEP
real rin;
int i;
for(i=0;i<3;i++){
 rin = pos1[i] - pos2[i];
 if(mtd_data.imcon==1) {
  rij[i] = pbc_mic_(&rin);
 } else {
  rij[i] = rin;
 }
}
*mod_rij = sqrt(rij[0]*rij[0] + rij[1]*rij[1] + rij[2]*rij[2]);
#elif DL_POLY
  int zero,one;
  zero=0;
  one=1;
  rij[0]=pos1[0]-pos2[0];   
  rij[1]=pos1[1]-pos2[1];   
  rij[2]=pos1[2]-pos2[2];   
  images_(&(mtd_data.imcon),&zero,&one,&one,mtd_data.cell,&rij[0],&rij[1],&rij[2]); 
  *mod_rij=sqrt(pow(rij[0],2)+pow(rij[1],2)+pow(rij[2],2));
#elif DRIVER
  int i;
  for(i=0;i<3;i++){
   rij[i] = pos1[i] - pos2[i];
   if(mtd_data.imcon==1){
    rij[i] -= mtd_data.cell[i]*rint(rij[i]/mtd_data.cell[i]);
   }
  }
*mod_rij = sqrt(rij[0]*rij[0] + rij[1]*rij[1] + rij[2]*rij[2]);
#elif AMBER 
  int i;
  rij[0]=pos1[0]-pos2[0];   
  rij[1]=pos1[1]-pos2[1];   
  rij[2]=pos1[2]-pos2[2];   
  if(mtd_data.imcon==1){
      rij[0] -= mtd_data.cell[0]*rint(rij[0]/mtd_data.cell[0]);
      rij[1] -= mtd_data.cell[1]*rint(rij[1]/mtd_data.cell[1]);
      rij[2] -= mtd_data.cell[2]*rint(rij[2]/mtd_data.cell[2]);
  } 
  *mod_rij=sqrt(pow(rij[0],2)+pow(rij[1],2)+pow(rij[2],2));
#endif
}
void PREFIX EXIT()
{
#ifdef NAMD
CkExit();
#else
exit(1);
#endif
} 
real  **** PREFIX float_4d_array_alloc(int ii,int jj,int kk,int ll){
real ****xx;
int i,j,k;
xx=(real ****)calloc(ii,sizeof(real *));
for (i=0;i<ii;i++){
        xx[i]=(real ***)calloc(jj,sizeof(real *));
        for(j=0;j<jj;j++){
                xx[i][j]=(real **)calloc(kk,sizeof(real *));
                for(k=0;k<kk;k++){
                        xx[i][j][k]=(real *)calloc(ll,sizeof(real));
                }
        }
}
return xx;
};

real  *** PREFIX float_3d_array_alloc(int ii,int jj,int kk){
real ***xx;
int i,j;
xx=(real ***)calloc(ii,sizeof(real *));
for (i=0;i<ii;i++){
        xx[i]=(real **)calloc(jj,sizeof(real *));
        for(j=0;j<jj;j++){
                xx[i][j]=(real *)calloc(kk,sizeof(real ));
        };
};
return xx;
};

real  ** PREFIX float_2d_array_alloc(int ii,int jj){
real **xx;
int i;
xx=(real **)calloc(ii,sizeof(real *));
for (i=0;i<ii;i++){
        xx[i]=(real *)calloc(jj,sizeof(real));
        }
return xx;
};
int  ** PREFIX int_2d_array_alloc(int ii,int jj){
int **xx;
int i;
xx=(int **)calloc(ii,sizeof(int *));
for (i=0;i<ii;i++){
        xx[i]=(int *)calloc(jj,sizeof(int));
        }
return xx;
};

int PREFIX free_4dr_array_alloc(real ****xx,int ii,int jj,int kk){
	int i,j,k;
	for (i=0;i<ii;i++){
        for(j=0;j<jj;j++){
			for(k=0;k<kk;k++){
				free(xx[i][j][k]);
			}
			free(xx[i][j]);
        }
		free(xx[i]);
	}
	free(xx);
	return 0;
};

int PREFIX free_3dr_array_alloc(real ***xx,int ii,int jj){
	int i,j;
	for (i=0;i<ii;i++){
        for(j=0;j<jj;j++){
			free(xx[i][j]);
        }
		free(xx[i]);
	}
	free(xx);
	return 0;
};

int PREFIX free_2dr_array_alloc(real **xx,int ii){
	int i;
	for (i=0;i<ii;i++){
		free(xx[i]);
	}
	free(xx);
	return 0;
};

int PREFIX free_2di_array_alloc(int **xx,int ii){
	int i;
	for (i=0;i<ii;i++){
		free(xx[i]);
	}
	free(xx);
	return 0;
};


int PREFIX free_4di_array_alloc(int ****xx,int ii,int jj,int kk){
	int i,j,k;
	for (i=0;i<ii;i++){
        for(j=0;j<jj;j++){
			for(k=0;k<kk;k++){
				free(xx[i][j][k]);
			}
			free(xx[i][j]);
        }
		free(xx[i]);
	}
	free(xx);
	return 0;
};

int PREFIX free_3di_array_alloc(int ***xx,int ii,int jj){
	int i,j;
	for (i=0;i<ii;i++){
        for(j=0;j<jj;j++){
			free(xx[i][j]);
        }
		free(xx[i]);
	}
	free(xx);
	return 0;
};

void PREFIX realquicksort ( real *v , int *ind , int left , int right ) {
        int i,last;
        if(left>=right)return;
        swap(v,ind,left,(left+right)/2);
        last=left;
        for(i=left+1;i<=right;i++){
           if ( v[i]<v[left] ) swap(v,ind,++last,i);
        }
        swap(v,ind,left,last);
        realquicksort(v,ind,left,last-1 );
        realquicksort(v,ind,last+1,right);
}
void PREFIX swap (real *v,int *ind,int i,int j){
        real temp;
        int tempi;
        temp=v[i];
        v[i]=v[j];
        v[j]=temp;
        tempi=ind[i];
        ind[i]=ind[j];
        ind[j]=tempi;
}
