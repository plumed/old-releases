/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#include "metadyn.h"

void PREFIX read_restraint(struct mtd_data_s *mtd_data)
{
  double uno, due, tre, quattro;
  int i, icv, count, exp, iw, nw, iline;
  FILE *file;
  char *str, string[500], metafile[120], *word[NWMAX], tmpmeta[120];

// Allocate a temporary array to parse the colvar's input
  mtd_data->index= (int *)calloc(mtd_data->natoms,sizeof(int));

// open PluMeD parameters file  
  file = fopen(mtd_data->metaFilename, "r");
  if(file==NULL) {
    if(mtd_data->repl==-1){
      fprintf(stderr, "MISSING PLUMED INPUT FILE %s : ABORTING RUN\n",mtd_data->metaFilename); 
      fprintf(stderr, "You need it if you want to use PLUMED\n"); 
      EXIT() ;
    }
    else if(mtd_data->repl>-1) {
      strcpy(tmpmeta,mtd_data->metaFilename);
      tmpmeta[strlen(mtd_data->metaFilename) - 4] = '\0';
      sprintf(tmpmeta+strlen(tmpmeta),"%d",mtd_data->repl);
      sprintf(metafile, "%s.dat", tmpmeta);
      file = fopen(metafile, "r");
      if(file==NULL) {
        fprintf(stderr, "MISSING PLUMED INPUT FILE %s : ABORTING RUN\n",mtd_data->metaFilename);
        fprintf(stderr, "You need it if you want to use PLUMED\n");
        EXIT() ;
      }
    }
  }

// CV counter initialization and calling routine to set the default values for many variables
  count = 0;
  iline = 0;
  read_defaults();

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//                               INPUT PARSER
//.............................................................................
// first word must be keyword (like COORD), then the parser
// seeks on the same line for additional input (like SIGMA).
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  
  fprintf(mtd_data->fplog, " \n");  
  fprintf(mtd_data->fplog, "::::::::::::::::: READING PLUMED INPUT :::::::::::::::::\n");
  while(1){
    str = fgets(string, 400, file);
    if(str==NULL) {
      fprintf(stderr, "\n|-%s FINISHED WITHOUT 'ENDMETA'!\n\n",mtd_data->metaFilename);
      EXIT();
    }
    iline++;

    nw = get_words(str,word);
    if(nw==-1) {
      fprintf(stderr,"ERROR: input line too long (increase NWMAX in metadyn.h), exiting.\n");
      EXIT();
    }
    if(nw==0) continue;
//    fprintf(mtd_data->fplog,"\n<input line #%i>\n", iline);

    if(seek_word(word,"ENDMETA")==0) {
      fprintf(mtd_data->fplog, "\n|-------------------------\n");
      fprintf(mtd_data->fplog, "|-ENDMETA - %s read!\n",mtd_data->metaFilename);
      fprintf(mtd_data->fplog, "|-------------------------\n\n");
      break;
    } else if(strcspn(word[0],"!")==0 || strcspn(word[0],"#")==0 ){
      fprintf(mtd_data->fplog, "\nCOMMENT: ");
      for(i=0;i<nw;i++)fprintf(mtd_data->fplog, "%s ", word[i]);
      fprintf(mtd_data->fplog,"\n");
      continue;
    } else if(seek_word(word,"COMMITMENT")==0) {
      if(logical.do_hills == 1){
        fprintf(stderr, "!!!!!! KEYWORD 'COMMITMENT' AND 'HILLS' ARE NOT COMPATIBLE !!!!!\n");
        EXIT();
      }
      logical.commitment = 1;
      fprintf(mtd_data->fplog, "|-COMMITOR ANALYSIS: YOU WILL ONLY MONITOR YOUR CVs MICRODYNAMICS\n");
      iw = seek_word(word,"NCV");
      if(iw>=0) sscanf(word[iw+1],"%i",&colvar.commit);
      for(i=0;i<colvar.commit;i++){
        str = fgets(string, 80, file);
        sscanf(str,"%lf %lf %lf %lf", &uno, &due, &tre, &quattro);
        colvar.Amin[i] = (real) uno;
        colvar.Amax[i] = (real) due;
        colvar.Bmin[i] = (real) tre;
        colvar.Bmax[i] = (real) quattro;
        fprintf(mtd_data->fplog, "|--CV %i: A min %f, max %f -- B min %f, max %f\n", i, colvar.Amin[i], colvar.Amax[i], colvar.Bmin[i], colvar.Bmax[i]);
        iline++;
      }
      fprintf(mtd_data->fplog, "\n");
    } else if(seek_word(word,"HILLS")==0) {
      if(logical.commitment == 1){
        fprintf(stderr, "!!!!!! KEYWORD 'COMMITMENT' AND 'HILLS' ARE NOT COMPATIBLE !!!!!\n");
        EXIT();
      }
      logical.do_hills = 1;
      iw = seek_word(word,"HEIGHT");
      if(iw>=0) {sscanf(word[iw+1],"%lf",&uno); hills.wwr = (real) uno*mtd_data->eunit;}
      iw = seek_word(word,"W_STRIDE");
      if(iw>=0) sscanf(word[iw+1],"%i",&hills.nt_hills);
      fprintf(mtd_data->fplog,"|-HILLS:\n|--HEIGHT %f  WRITING STRIDE %i \n",hills.wwr/mtd_data->eunit, hills.nt_hills);
      iw=seek_word(word,"R_STRIDE");
      if(iw>=0) { 
       sscanf(word[iw+1],"%i",&hills.nr_hills);
       fprintf(mtd_data->fplog,"|--READING STRIDE %i\n", hills.nr_hills);
      }
      iw=seek_word(word,"RESTART");
      if(iw>=0) {
       logical.restart_hills = 1;
       fprintf(mtd_data->fplog,"|-RESTARTING METADYNAMICS!\n");
      }
      fprintf(mtd_data->fplog, "\n");
    } else if(seek_word(word,"MULTIPLE_WALKERS")==0) {
      iw = seek_word(word,"HILLS_DIR");
      if(iw>=0) sscanf(word[iw+1], "%s", hills.dir);
      iw = seek_word(word,"WALKERS");
      if(iw>=0) sscanf(word[iw+1], "%i", &nwalkers);
      fprintf(mtd_data->fplog,"|-%i MULTIPLE WALKERS:\n DIRECTORY FOR HILLS I/O %s\n\n", nwalkers, hills.dir);
    } else if(seek_word(word,"PRINT")==0) {
      iw = seek_word(word,"W_STRIDE");
      sscanf(word[iw+1],"%i", &colvar.nt_print);
      fprintf(mtd_data->fplog,"|-PRINTING EVERY %i STEP\n",colvar.nt_print);
      logical.print = 1;
    } else if(seek_word(word,"PTMETAD")==0){
      #if defined (NAMD) || defined (DL_POLY) || defined (AMBER)  
          fprintf(mtd_data->fplog,"|-PTMETAD: NOT YET IMPLEMENTED IN THIS CODE \n");
          EXIT(); 
      #else
      fprintf(mtd_data->fplog, "|-PARALLEL TEMPERING METADYNAMICS\n");
      logical.remd = 1;
      fprintf(mtd_data->fplog, "|--REPLICA 0 TEMPERATURE = %f\n", mtd_data->rte0);
      fprintf(mtd_data->fplog, "|--REPLICA %i TEMPERATURE = %f\n", mtd_data->repl, mtd_data->rteio);
      if(mtd_data->repl==-1) {
        fprintf(mtd_data->fplog, "\n!!!! mdrun not in replica exchange mode, keyword PTMETAD will not be considered !!!!\n");
        logical.remd = 0;
      }
      fprintf(mtd_data->fplog, "\n");
      #endif
    } else if(seek_word(word,"BIASXMD")==0){
      #if defined (NAMD) || defined (DL_POLY) || defined (AMBER) 
          fprintf(mtd_data->fplog,"|-BIASXMD: NOT YET IMPLEMENTED IN THIS CODE \n");
          EXIT();
      #else
      fprintf(mtd_data->fplog, "|-BIAS EXCHANGE METADYNAMICS\n");
      logical.rpxm = 1;
      logical.remd = 1;
      if(mtd_data->repl==-1) {
        fprintf(mtd_data->fplog, "\n!!!! mdrun not in replica exchange mode, keyword BIASXMD will not be considered !!!!\n");
        logical.rpxm = 0;
        logical.remd = 0;
      }
      fprintf(mtd_data->fplog, "\n");
      #endif
    } else if(seek_word(word,"WELLTEMPERED")==0){
      logical.welltemp = 1;
      int read_biasfactor = 0;
      int read_cvtemp = 0;
      iw = seek_word(word,"CVTEMP");
      if(iw>=0) {
        sscanf(word[iw+1], "%lf", &uno);
        colvar.wtemp = (real) uno;
        read_cvtemp = 1; 
      } 
      iw = seek_word(word,"BIASFACTOR");
      if(iw>=0) {
        sscanf(word[iw+1], "%lf", &uno);
        colvar.wfactor = (real) uno;
        read_biasfactor = 1;
      }
      iw = seek_word(word,"SIMTEMP");
      if(iw>=0) {
        sscanf(word[iw+1], "%lf", &uno);
        colvar.simtemp = (real) uno;
      } else { 
        fprintf(mtd_data->fplog, "|-ERROR: WITH WELLTEMPERED YOU ALWAYS HAVE TO SPECIFY THE \"SIMTEMP \" KEYWORD\n");EXIT(); 
      } 

      if((read_biasfactor==0 && read_cvtemp==0) || (read_biasfactor==1 && read_cvtemp==1)) {
       fprintf(mtd_data->fplog, "|-ERROR: WITH WELLTEMPERED YOU HAVE TO SPECIFY EITHER \"CVTEMP \" OR \"BIASFACTOR \" KEYWORD\n");
       EXIT();
      }

      if(read_cvtemp)     colvar.wfactor = colvar.wtemp / colvar.simtemp;  
      if(read_biasfactor) colvar.wtemp   = colvar.wfactor * colvar.simtemp;

      if (colvar.wfactor<=1.0) {  
        printf("Error temperature factor less than or equal to 1.0 ( %f ) \n",colvar.wfactor);
        EXIT(); 
      } 

      fprintf(mtd_data->fplog, "|-WELL TEMPERED METADYNAMICS WITH BIAS FACTOR %f (CVTEMP = %f) \n\n", colvar.wfactor,colvar.wtemp);
   
    } else if(seek_word(word,"DEBUG")==0){
      fprintf(mtd_data->fplog,"|- CV DERIVATIVES DEBUGGING \n"); 
      logical.debug = 1;
    } else if(seek_word(word,"DISTANCE")==0){
      iline += read_dist(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"MINDIST")==0){
      iline += read_mindist(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"COORD")==0){
      iline += read_coord(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"ANGLE")==0){
      iline += read_angle(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"HBONDS")==0){
      iline += read_hbonds(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"TORSION")==0){
      iline += read_torsion(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"RGYR")==0 || seek_word(word,"INERTIA")==0){
      iline += read_rgyr(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"RMSDTOR")==0){
      iline += read_rmsdtor(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"DIPOLE")==0){
      iline += read_dipole(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"DIHCOR")==0) {
      iline += read_dihcor(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"WATERBRIDGE")==0) {
      iline += read_waterbridge(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"ALPHABETA")==0) {
      iline += read_alfabeta(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"S_PATH")==0) {
      colvar.type_s[count]   = 30;
      iline += read_path(str, word, count, file, mtd_data->fplog);
      count++;
    } else if(seek_word(word,"Z_PATH")==0) {
      colvar.type_s[count]   = 31;
      iline += read_path(str, word, count, file, mtd_data->fplog);
      count++;   
/* Atom position */      
    } else if(seek_word(word,"POSITION")==0) {
      colvar.type_s[count]   = 32;
      iline += read_position(str, word, count, file, mtd_data->fplog);
      count++;   
      
    } else if(seek_word(word,"UWALL")==0){
      iw = seek_word(word,"CV");
      if(iw>=0){ sscanf(word[iw+1], "%i", &icv);}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH UWALL YOU ALWAYS HAVE TO SPECIFY THE \"CV\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"LIMIT");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &uno);cvw.upper[icv-1]      = (real) uno;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH UWALL YOU ALWAYS HAVE TO SPECIFY THE \"LIMIT\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"KAPPA");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &due);  cvw.sigma[icv-1]      = (real) due*mtd_data->eunit; }
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH UWALL YOU ALWAYS HAVE TO SPECIFY THE \"KAPPA\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"EXP");
      if(iw>=0){ sscanf(word[iw+1], "%i", &exp); cvw.uexp[icv-1]       = exp;}
      iw = seek_word(word,"EPS");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &tre);  cvw.ueps[icv-1]       = (real) tre;}
      iw = seek_word(word,"OFF");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &quattro);  cvw.uoff[icv-1]       = (real) quattro;}
      logical.upper[icv-1]  = 1;
      fprintf(mtd_data->fplog, "|-WALL ON COLVAR %i: UPPER LIMIT = %f, KAPPA = %f, EXPONENT = %i, REDUX = %f, OFFSET = %f \n\n",
             icv, cvw.upper[icv-1], cvw.sigma[icv-1]/mtd_data->eunit, cvw.uexp[icv-1], cvw.ueps[icv-1], cvw.uoff[icv-1]);
    } else if(seek_word(word,"LWALL")==0){
      iw = seek_word(word,"CV");
      if(iw>=0){ sscanf(word[iw+1], "%i", &icv);}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH LWALL YOU ALWAYS HAVE TO SPECIFY THE \"CV\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"LIMIT");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &uno); cvw.lower[icv-1]      = (real) uno;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH LWALL YOU ALWAYS HAVE TO SPECIFY THE \"LIMIT\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"KAPPA");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &due); cvw.lsigma[icv-1]     = (real) due*mtd_data->eunit;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH LWALL YOU ALWAYS HAVE TO SPECIFY THE \"KAPPA\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"EXP");
      if(iw>=0){ sscanf(word[iw+1], "%i", &exp);  cvw.lexp[icv-1]       = exp;}
      iw = seek_word(word,"EPS");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &tre);cvw.leps[icv-1]       = (real) tre;}
      iw = seek_word(word,"OFF");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &quattro);  cvw.loff[icv-1]       = (real) quattro;}
      logical.lower[icv-1]  = 1;
      fprintf(mtd_data->fplog, "|-WALL ON COLVAR %i: LOWER LIMIT = %f, KAPPA = %f, EXPONENT = %i, REDUX = %f, OFFSET = %f \n\n",
             icv, cvw.lower[icv-1], cvw.lsigma[icv-1]/mtd_data->eunit, cvw.lexp[icv-1], cvw.leps[icv-1], cvw.loff[icv-1]);       

    } else if(seek_word(word,"STEER")==0){
      iw = seek_word(word,"CV");
      if(iw>=0){ sscanf(word[iw+1], "%i", &icv); cvsteer.impose_start[icv-1] = 0;}
      else {fprintf(mtd_data->fplog, "|-ERROR: WITH STEER YOU ALWAYS HAVE TO SPECIFY THE \"CV\" KEYWORD\n");EXIT(); } 
      iw = seek_word(word,"FROM");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &quattro); cvsteer.start[icv-1] = (real) quattro;  cvsteer.impose_start[icv-1]  = 1;}
      iw = seek_word(word,"TO");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &quattro); cvsteer.max[icv-1] = (real) quattro;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH STEER YOU ALWAYS HAVE TO SPECIFY THE \"TO\" KEYWORD\n");EXIT(); }   
      iw = seek_word(word,"VEL");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &due); due=fabs(due); cvsteer.delta[icv-1] = (real) due; } 
      else {fprintf(mtd_data->fplog, "|-ERROR: WITH STEER YOU ALWAYS HAVE TO SPECIFY THE \"VEL\" KEYWORD\n");EXIT(); } 
      iw = seek_word(word,"KAPPA");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &tre); cvsteer.spring[icv-1] = (real) tre*mtd_data->eunit;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH STEER YOU ALWAYS HAVE TO SPECIFY THE \"KAPPA\" KEYWORD\n");EXIT(); }

      logical.steer[icv-1]  = 1; 
      if(cvsteer.impose_start[icv-1]==0){
        fprintf(mtd_data->fplog, "|-STEERING COLVAR %i TO %f: VELOCITY=%lf cvunit/kstep, SPRING=%lf\n\n", icv,cvsteer.max[icv-1],cvsteer.delta[icv-1],cvsteer.spring[icv-1]/mtd_data->eunit);
      } else { 
        fprintf(mtd_data->fplog, "|-STEERING COLVAR %i FROM %f TO %f: VELOCITY=%lf cvunit/kstep, SPRING=%lf\n\n", icv, cvsteer.start[icv-1],cvsteer.max[icv-1],cvsteer.delta[icv-1],cvsteer.spring[icv-1]/mtd_data->eunit);
      } 

    } else if(seek_word(word,"UMBRELLA")==0){
      iw = seek_word(word,"CV");
      if(iw>=0){ sscanf(word[iw+1], "%i", &icv); 
        cvsteer.impose_start[icv-1]  = 1;
        cvsteer.delta[icv-1]         = 0.;
      }
      else {fprintf(mtd_data->fplog, "|-ERROR: WITH UMBRELLA YOU ALWAYS HAVE TO SPECIFY THE \"CV\" KEYWORD\n");EXIT(); } 
      iw = seek_word(word,"KAPPA");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &tre);cvsteer.spring[icv-1] = (real) tre*mtd_data->eunit;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH UMBRELLA YOU ALWAYS HAVE TO SPECIFY THE \"KAPPA\" KEYWORD\n");EXIT(); }
      iw = seek_word(word,"AT");
      if(iw>=0){ sscanf(word[iw+1], "%lf", &quattro);cvsteer.max[icv-1]=cvsteer.start[icv-1]=(real) quattro;}
      else{fprintf(mtd_data->fplog, "|-ERROR: WITH UMBRELLA YOU ALWAYS HAVE TO SPECIFY THE \"AT\" KEYWORD\n");EXIT(); }   

      logical.steer[icv-1]  = 1; 
      fprintf(mtd_data->fplog, "|-UMBRELLA SAMPLING OF COLVAR %i AT %f: SPRING=%lf\n\n", icv,cvsteer.max[icv-1],cvsteer.spring[icv-1]/mtd_data->eunit);

    } else if(seek_word(word,"NOHILLS")==0){
      iw = seek_word(word,"CV");
      if(iw>=0) sscanf(word[iw+1], "%i", &icv);
      colvar.on[icv-1] = 0;
      fprintf(mtd_data->fplog, "|-NO HILLS ON COLVAR %i\n", icv);
    } else if(seek_word(word,"UREFLECT")==0){
      iw = seek_word(word,"CV");
      if(iw>=0) sscanf(word[iw+1], "%i", &icv);
      iw = seek_word(word,"LIMIT");
      if(iw>=0) sscanf(word[iw+1], "%lf", &uno);
      cvw.upper[icv-1] = (real) uno;
      logical.ureflect[icv-1] = 1;
      fprintf(mtd_data->fplog, "|-UPPER REFLECTING WALL ON CV %i, AT %f\n\n", icv, cvw.upper[icv-1]);
    } else if(seek_word(word,"LREFLECT")==0){
      iw = seek_word(word,"CV");
      if(iw>=0) sscanf(word[iw+1], "%i", &icv);
      iw = seek_word(word,"LIMIT");
      if(iw>=0) sscanf(word[iw+1], "%lf", &uno);
      cvw.lower[icv-1] = (real) uno;
      logical.lreflect[icv-1] = 1;
      fprintf(mtd_data->fplog, "|-LOWER REFLECTING WALL ON CV %i, AT %f\n\n", icv, cvw.lower[icv-1]);
    }/* else {
      fprintf(stderr, "\nATTENTION: Line %i Unkwown Keyword %s \n", iline, str);
      EXIT();
    }*/
  }

// set the number of collective variables
  colvar.nconst = count;

// check the correctenes of the input parsed
  if(colvar.nconst > nconst_max) {
    fprintf(stderr, "\n!!!!!!!!  Too many colvars. Change NCONST_MAX in metadyn.h !!!!!!!!!!!\n");	
    EXIT();
  }

// checking for conflicts in directive keywords
  if(!logical.do_hills && !logical.commitment){
    fprintf(mtd_data->fplog, "|-ANALYSIS: YOU WILL ONLY MONITOR YOUR CVs MICRODYNAMICS\n\n");
  }

  if(logical.welltemp && !logical.do_hills) {fprintf(stderr, "ERROR! WELLTEMPERED must be used with HILLS keyword\n\n"); EXIT();}

// in case of parallel or solute tempering rescale hills heigth with temperature
  if(logical.do_hills&&logical.remd&&(!logical.rpxm)) hills.wwr *= mtd_data->rteio/mtd_data->rte0;

// in case of PTMETAD and well tempered set the right simtemp
  if(logical.do_hills&&logical.remd&&(!logical.rpxm)&&logical.welltemp) colvar.simtemp = mtd_data->rteio;

// printout PLEASE_CITE

  cite_please(1,mtd_data->fplog);
  if(logical.do_hills) cite_please(0,mtd_data->fplog);
  if(logical.remd && !logical.rpxm) cite_please(4,mtd_data->fplog);
  if(logical.rpxm) cite_please(2,mtd_data->fplog);
  if(logical.welltemp) cite_please(3,mtd_data->fplog);
  int logical_path=0;
  for(i=0;i<colvar.nconst;i++) if(colvar.type_s[i]==30 || colvar.type_s[i]==31) logical_path=1; 
  if(logical_path) cite_please(5,mtd_data->fplog);
  if(nwalkers>1) cite_please(6,mtd_data->fplog);
  fprintf(mtd_data->fplog,"\n"); 

  disclaimer(mtd_data->fplog);
// flushing output
  fflush(mtd_data->fplog);

// freeing temporary array
  free(mtd_data->index);
}

//-----------------------------------------------------------------------------------------------------------------

void PREFIX read_defaults()
{
  int icv;
 
  colvar.nt_print 		= 10;
  colvar.nconst 		= 0;
  logical.restart_hills 	= 0;
  logical.remd 			= 0;
  logical.rpxm			= 0;
  logical.do_hills 		= 0;
  logical.commitment 		= 0;
  logical.print 		= 0;
  logical.widthadapt            = 0;
  logical.welltemp              = 0;
  logical.debug                 = 0;
  hills.wwr 			= 0.;
  nwalkers 			= 1;
  hills.n_hills			= 0;
  hills.nt_hills                = 999999999; 
  hills.nr_hills                = 1; 
  hills.read                    = 0;
  nsz                           = 0;
  repmeta.first                 = 1;

  for(icv=0;icv<nconst_max;icv++){
    logical.steer[icv]            = 0; 
    logical.upper[icv] 		= 0;
    logical.lower[icv] 		= 0;
    logical.ureflect[icv]       = 0;
    logical.lreflect[icv]       = 0;
    cvw.sigma[icv] 		= 0.;
    cvw.upper[icv] 		= 0.;
    cvw.lower[icv] 		= 0.;
    cvw.lsigma[icv] 		= 0.;
    cvw.fwall[icv] 		= 0;
    cvw.uexp[icv] 		= 4;
    cvw.lexp[icv] 		= 4;
    cvw.ueps[icv] 		= 1.;
    cvw.leps[icv] 		= 1.;
    cvw.uoff[icv]               = 0.;
    cvw.loff[icv]               = 0.;
    colvar.on[icv] 		= 1;
    colvar.Mss0[icv]            = 0.;
    colvar.M2ss0[icv]           = 0.;
    colvar.type_s[icv]          = 0;
    colvar.logic[icv]           = 0;
    colvar.natoms[icv]          = 0;
  }
}

//-----------------------------------------------------------------------------------------------------------------

// routine which splits a line into its words (separated by spaces or \n),
// it returns the number of words
int  PREFIX get_words(char *line, char *word[NWMAX])
{
  int i;

  word[0]=strtok(line," \n");
  if (word[0]==NULL) return 0;
  for (i=1;i<NWMAX-1;i++) {
    word[i]=strtok(NULL," \n");
    if (word[i]==NULL) return i;
  }
  return -1;
}

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

int PREFIX seek_word(char *word[NWMAX], char *wanted)
{
  int i;

  for (i=0;i<NWMAX-1;i++) {
    if (word[i]==NULL) return -1;
    if (strcmp(word[i],wanted)==0) return i;
  }
  return -1;
}

// Added By Paolo to progrssively seek in the input string
int PREFIX seek_word2(char *word[NWMAX], char *wanted, int is)
{
  int i;

  for (i=is;i<NWMAX-1;i++) {
    if (word[i]==NULL) return -1;
    if (strcmp(word[i],wanted)==0) return i;
  }
  return -1;
}
/*
 check group takes a word  and looks if it's in <mygroup> format:
 if it's so it reads the file and looks for a group specified as

 mygroup->       
   4567 678 678 567 4567
   67 89 678 34 234
   5 7
 mygroup-<       

  IT returns the number of found field for the group ( in the case above 12 ) 
  it places the member of the group in  a vector vec , starting from position n
  ( so the new positions will be stored in vec[i] i=n,i<n+j,i++  ) and reallocate the 
  vector if necessary    
   
*/
int PREFIX check_group(const char *word, int **vec,int n,  char meta[120],FILE *fplog){
  int i,j,nw,nn; 
  char ww[100],startword[100],endword[100];
  int go=1;
  int found_head=0; 
  int found_tail=0; 
  int found_head2=0; 
  int found_tail2=0; 
  char *str, string[500];
  char *ww2[NWMAX];
  int start, finish, stride;
  FILE *file;
  i=0;j=0;nn=0;
  while(go){
    if( (found_head)  && (!found_tail) ) { 
      if(strncmp(&word[i],">",1)==0) {found_tail=1;strcpy(&(ww[j]),"\0");}
      else {
        strncpy(&(ww[j]),&(word[i]),1);  j++;  
      }   
    }
    if (strncmp(&word[i],"\0",1)==0)go=0;
    if( (!found_head) && (!found_tail) && (strncmp(&word[i],"<",1)==0) )found_head=1;
    i++;
  }
  if( found_head==0 || found_tail==0 ){
//    fprintf(fplog,"|-FOUND NO GROUP\n") ;
    return 0; 
  }
  
  if(found_head && found_tail){

    strcpy(startword,ww);
    strcpy(endword,ww);
    strncpy((&startword[j]),"->\0",3);
    strncpy((&endword[j]),"<-\0",3);
    
    //fprintf(fplog,"|-FOUND GROUP %s\n",ww);
    file = fopen(meta,"r");
    go=0;
    while (1){
      str = fgets(string, 400, file);
      if(str==NULL)break;
      nw = get_words(str,ww2);
      if (nw==0)continue;
      if( (!strncmp(endword,ww2[0],j+2)) && (go==1)  ){
        go=0;break;
      } 
      if(go){ 
        if(atoi(ww2[0])==0){
          if(strcmp(ww2[0],"LOOP")!=0){fprintf(fplog,"error in reading THE LINE :: '%s'\n",string);EXIT();}
          if(nw==2){start=finish=atoi(ww2[1])-1;stride=1;}
          if(nw==3){start=atoi(ww2[1])-1;finish=atoi(ww2[2]);stride=1;}
          if(nw==4){start=atoi(ww2[1])-1;finish=atoi(ww2[2]);stride=atoi(ww2[3]);}
          for(i=start;i<finish;i+=stride)nn++;
        }else {
          for (i=0;i<nw;i++){
            if(atoi(ww2[i])==0){
              fprintf(fplog,"ERROR IN READING THE LINE 1 :: '%s'\n",str);EXIT();
            }else{
              nn++; 
            }
          }
        }
      }
      if( (!strncmp(startword,ww2[0],j+2)) && (go==0) )go=1;

    }
    /* rewind allocate and reread */ 
    if(n==0){ /* allocate brand new vector */ 
        snew(*vec,nn); 
    } else { 
      /* create a vector */ 
      int  *vec2;   
      snew(vec2, n);
      /* copy things in it*/ 
      for(i=0;i<n;i++) vec2[i]=(*vec)[i];
      /* reallocate old vector bigger */
      free(*vec);
      snew(*vec,n+nn );
      /* copy back things */ 
      for(i=0;i<n;i++){(*vec)[i]=vec2[i];}
      free(vec2);
    } 
    nn=0; 
    rewind(file);
    go=0;
    while (1){
      str = fgets(string, 400, file);
      if(str==NULL)break;
      nw = get_words(str,ww2);
      if (nw==0)continue;
      if( (!strncmp(endword,ww2[0],j+2)) && (go==1) ){
        go=0;break;
      } 
      if(go){ 
        if(atoi(ww2[0])==0){
          if(nw==2){start=finish=atoi(ww2[1])-1;stride=1;}
          if(nw==3){start=atoi(ww2[1])-1;finish=atoi(ww2[2]);stride=1;}
          if(nw==4){start=atoi(ww2[1])-1;finish=atoi(ww2[2]);stride=atoi(ww2[3]);}
          for(i=start;i<finish;i+=stride){
            (*vec)[nn+n]=i; 
            nn++;
          }
        }else {
          for (i=0;i<nw;i++){
            (*vec)[nn+n]=atoi(ww2[i])-1; 
            nn++;
          }
        }
      }
      if( (!strncmp(startword,ww2[0],j+2)) && (go==0) ) go=1;
    }
    //fprintf(fplog,"|-MEMBERS: ");for(i=n;i<n+nn;i++){fprintf(fplog," %d ",(*vec)[i]+1);}fprintf(fplog,"\n");
  }
  fclose(file);  
  return (nn);
};

// routine to read a single atom and allocate/reallocate the vector if necessary
void PREFIX read_single(const char *word, int **vec,int n){
int index, i;

    if(n==0){ /* allocate brand new vector */ 
        snew(*vec,1); 
    } else { 
      /* create a vector */ 
      int  *vec2;   
      snew(vec2, n);
      /* copy things in it*/ 
      for(i=0;i<n;i++) vec2[i]=(*vec)[i];
      /* reallocate old vector bigger */
      free(*vec);
      snew(*vec,n+1);
      /* copy back things */ 
      for(i=0;i<n;i++){(*vec)[i]=vec2[i];}
      free(vec2);
    } 

    sscanf(word,"%i", &index);
    (*vec)[n] = index - 1;
};

void PREFIX cite_please (int re, FILE *fplog){


 fprintf(fplog, "\n++++ PLEASE READ AND CITE THE FOLLOWING REFERENCE ++++\n"); 
 switch (re) {
  
  case 0:
    fprintf(fplog, "  A. Laio and M. Parrinello\n");
    fprintf(fplog, "  Escaping free energy minima\n");
    fprintf(fplog, "  Proc. Natl. Acad. Sci. USA. 2002 vol. 99 (20) pp. 12562-6\n");
    break;
  case 1:
    fprintf(fplog, "  M. Bonomi, D. Branduardi, G. Bussi, C. Camilloni, D. Provasi, P. Raiteri, \n");
    fprintf(fplog, "  D. Donadio, F. Marinelli, F. Pietrucci, R. A. Broglia and M. Parrinello \n");
    fprintf(fplog, "  PLUMED: a portable plugin for free-energy calculations with molecular dynamics\n");
    fprintf(fplog, "  arXiv:0902.0874 [physics.comp-ph] \n");
    break;
  case 2:
    fprintf(fplog, "  S. Piana and A. Laio\n");
    fprintf(fplog, "  A Bias-Exchange Approach to Protein Folding \n");
    fprintf(fplog, "  J. Phys. Chem. B. 2007 vol. 111 (17) pp. 4553-9\n");
    break;
  case 3:
    fprintf(fplog, "  A. Barducci, G. Bussi and M. Parrinello\n");
    fprintf(fplog, "  Well-Tempered Metadynamics: A Smoothly Converging and Tunable Free-Energy Method \n");
    fprintf(fplog, "  Phys. Rev. Lett. 2008 vol. 100 (2) pp. 020603 \n");
    break;
  case 4:    
    fprintf(fplog, "  G. Bussi, F.L. Gervasio, A. Laio and M. Parrinello \n");
    fprintf(fplog, "  Free-energy landscape for beta hairpin folding from combined parallel tempering and metadynamics\n");
    fprintf(fplog, "  J. Am. Chem. Soc. 2006 vol. 128 (41) pp. 13435-41 \n");
    break;
  case 5:
    fprintf(fplog, "  D. Branduardi, F.L. Gervasio and M. Parrinello \n");
    fprintf(fplog, "  From A to B in free energy space\n");
    fprintf(fplog, "  Jour. Chem. Phys. 2007 vol. 126 (5) pp. 054103\n");
    break;
  case 6:
    fprintf(fplog, "  P. Raiteri, A. Laio, F.L. Gervasio, C. Micheletti and M. Parrinello \n");
    fprintf(fplog, "  Efficient Reconstruction of Complex Free Energy Landscapes by Multiple Walkers Metadynamics \n"); 
    fprintf(fplog, "  J. Phys. Chem. B. 2006 vol. 110 (8) pp. 3533-3539 \n");
    break;
 }

 fprintf(fplog, "-------- -------- --- Thank You --- -------- --------\n\n"); 
};

void PREFIX disclaimer (FILE *fplog){

 fprintf(fplog,"** PLUMED is free software: you can redistribute it and/or modify \n");
 fprintf(fplog,"** it under the terms of the GNU Lesser General Public License as published by \n");
 fprintf(fplog,"** the Free Software Foundation, either version 3 of the License, or \n");
 fprintf(fplog,"** (at your option) any later version. \n\n");
 fprintf(fplog,"** PLUMED is distributed in the hope that it will be useful,\n");
 fprintf(fplog,"** but WITHOUT ANY WARRANTY; without even the implied warranty of \n");
 fprintf(fplog,"** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the \n");
 fprintf(fplog,"** GNU Lesser General Public License for more details. \n\n");
 fprintf(fplog,"** You should have received a copy of the GNU Lesser General Public License\n");
 fprintf(fplog,"** along with PLUMED.  If not, see <http://www.gnu.org/licenses/>.  \n\n");
 fprintf(fplog,"** For more info, see:  http://merlino.mi.infn.it/plumed \n");
 fprintf(fplog,"** or subscribe to plumed-users@googlegroups.com \n\n");

}; 
