/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#include "metadyn.h"

void PREFIX hbonds_restraint(int i_c, struct mtd_data_s *mtd_data)
{
  int j, ix, i, kk, firstAtom, secondAtom;
  double nn, mm;
  rvec rij;
  real mod_rij, rdist;
  double nhbond, r6dist, r12dist, num, iden;
  double rijfmod, deriv;

  nhbond = 0.;
  nn = (double) colvar.nn[i_c];
  mm = (double) colvar.mm[i_c];
  for(i=0;i<colvar.natoms[i_c];i++) for(ix=0;ix<3;ix++) colvar.myder[i_c][i][ix] = 0.;

  for(i=0;i<colvar.list[i_c][0];i++) {						// cycle over acceptors
    firstAtom = colvar.cvatoms[i_c][i];						// acceptors atom
    for(j=colvar.list[i_c][0];j<colvar.natoms[i_c];j++) {	                // cycle over hydrogens
      kk=i-j+colvar.list[i_c][0];
      if(colvar.type[i_c]==1) {
        if(abs(kk)<=4) continue;
        if(kk%2==0) continue;
      } else if(colvar.type[i_c]==2) {
        if(abs(kk)!=4) continue;
      } else if(colvar.type[i_c]==3) {
        if(abs(kk)<=4) continue;
        if(kk%2==1) continue;
      }
      secondAtom = colvar.cvatoms[i_c][j];			// hydrogen atom
      if(firstAtom==secondAtom) continue;
      minimal_image(mtd_data->pos[firstAtom], mtd_data->pos[secondAtom], &mod_rij, rij);	// distance acceptor/donor
      rdist = mod_rij/colvar.r_0[i_c];				// weighted distance
      if(rdist>0.99998 && rdist<1.00002) rdist = 0.99999;	// to keep the function continuos
      r6dist = pow(rdist, nn);	
      num = 1.-r6dist;						// numerator
      r12dist = pow(rdist, mm);	
      iden = 1./(1.-r12dist);					// denominator

      nhbond += num*iden;
      for(ix=0;ix<3;ix++) {
        rijfmod = (double) rij[ix]/(mod_rij*mod_rij);
        deriv = -rijfmod*(-mm*r12dist+r6dist*(nn+(mm-nn)*r12dist))*iden*iden;
        colvar.myder[i_c][i][ix] += (real) deriv;
        colvar.myder[i_c][j][ix] += (real) -deriv;
      }
    }
  }
  colvar.ss0[i_c] = (real) nhbond;
  
}

// --------------------------------------------------------------------------------------------------------------

int PREFIX read_hbonds(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog)
{
  double delta = 0.0;
  double r_0;
  int iat, i, j, iw, help;
  char string[400];

  help=0;
  colvar.nn[count] = 6;
  colvar.mm[count] = 12;
#if defined (GROMACS3) || defined (GROMACS4)
  r_0 = 0.25;
#else
  r_0 = 2.5;
#endif

  iw = seek_word(word,"LIST");
  if(iw>=0){
             j=check_group(word[iw+1],&colvar.cvatoms[count], colvar.natoms[count],mtd_data.metaFilename,fplog);
             if(j==0){read_single(word[iw+1],&colvar.cvatoms[count], colvar.natoms[count]); colvar.natoms[count]+=1; colvar.list[count][0]=1; }
             else { colvar.natoms[count]+=j; colvar.list[count][0]=j; }

             j=check_group(word[iw+2],&colvar.cvatoms[count],colvar.natoms[count],mtd_data.metaFilename,fplog);
             if(j==0){read_single(word[iw+2],&colvar.cvatoms[count], colvar.natoms[count]); colvar.natoms[count]+=1; colvar.list[count][1]=1; }
             else{ colvar.natoms[count]+=j;  colvar.list[count][1]=j;   }

  }  else {fprintf(fplog,"|- NEEDED LIST KEYWORD FOR HBONDS\n"); help=1;}
  iw=seek_word(word,"SIGMA");
  if(iw>=0) {sscanf(word[iw+1],"%lf", &delta); } else if (logical.do_hills) { fprintf(fplog,"|- NEEDED SIGMA KEYWORD FOR HBONDS\n"); help=1;} 
  iw=seek_word(word,"NN");
  if(iw>=0) {sscanf(word[iw+1],"%i", &colvar.nn[count]); }
  iw=seek_word(word,"MM");
  if(iw>=0) {sscanf(word[iw+1],"%i", &colvar.mm[count]); }
  iw=seek_word(word,"R_0");
  if(iw>=0) {sscanf(word[iw+1],"%lf", &r_0); } 
  iw=seek_word(word,"TYPE");
  if(iw>=0) {sscanf(word[iw+1],"%i", &colvar.type[count]); } else {fprintf(fplog,"|- NEEDED TYPE KEYWORD FOR HBONDS\n"); help=1;}

  if(help){
          fprintf(fplog, "\n-HBONDS CV: WRONG SYNTAX\n");
          fprintf(fplog, "e.g.:     \n");
          fprintf(fplog, "HBONDS LIST <H> <O> TYPE 0 SIGMA 0.1 [NN 6 MM 12 R_0 2.5]\n");
          fprintf(fplog, "         H->    \n");
          fprintf(fplog, "         6 10    \n");
          fprintf(fplog, "         H<-    \n");
          fprintf(fplog, "                 \n");
          fprintf(fplog, "         O->    \n");
          fprintf(fplog, "         8 12 \n");
          fprintf(fplog, "         O<-    \n");
          fprintf(fplog, "                 \n"); 
          fprintf(stderr, "PluMed dead with errors: check log file  \n");
          EXIT(); 
  }

  colvar.delta_r[count]  = (real) delta;
  colvar.r_0[count]	 = (real) r_0;
  colvar.type_s[count]   = 7;

  fprintf(fplog, "\n%1i-HBONDS: NN %i MM %i R_0 %lf ", count+1, colvar.nn[count], colvar.mm[count], colvar.r_0[count]);
  if (logical.do_hills) fprintf(fplog," SIGMA %f\n",colvar.delta_r[count]);
  else fprintf(fplog,"\n"); 
  fprintf(fplog, "|--HBONDS: WILL COUNT INTRA PROTEIN HBONDS, TYPE = %i (0 = ALL, 1 = BETA ODD, 2 = ALPHA, 3 = BETA EVEN)\n", colvar.type[count]);

  iat=0;
  fprintf(fplog,"|- 1st SET MEMBERS: ");
  for(i=0;i<colvar.list[count][0];i++){fprintf(fplog," %d ",colvar.cvatoms[count][iat++]+1);if((i+1)%20==0)fprintf(fplog,"\n                    ");}fprintf(fplog,"\n");
  fprintf(fplog,"|- 2nd SET MEMBERS: ");
  for(i=0;i<colvar.list[count][1];i++){fprintf(fplog," %d ",colvar.cvatoms[count][iat++]+1);if((i+1)%20==0)fprintf(fplog,"\n                    ");}fprintf(fplog,"\n\n");  

  snew(colvar.myder[count], colvar.natoms[count]);

  return colvar.natoms[count];
}
