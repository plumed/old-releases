/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#include "metadyn.h"

void ptmetad(real *Epota, real *Epotb, real *Epotba, real *Epotab, int a, int b)
{
#ifdef MPI
  real Vhillsab, Vhillsba, dp2, dp[nconst_max];
  int j;
  long int ih, dp2index;

  Vhillsab = 0.;
  Vhillsba = 0.;
  for(ih=0;ih<repmeta.nhills[a];ih++){
    dp2 = 0.;
    for(j=0;j<colvar.nconst;j++){
      if(repmeta.on[j][a]){
        dp[j] = (repmeta.ss0[j][b]-repmeta.ss0_t[ih][j][a])/repmeta.delta_r[ih][j][a];
        dp2 += dp[j]*dp[j];
      }
    }
    dp2 *= 0.5;
    
    if(dp2<DP2CUTOFF) {
      dp2index = dp2*GTAB/DP2CUTOFF;
      Vhillsab += repmeta.ww[ih][a]*hills.exp[dp2index];
    }
  }

  for(ih=0;ih<repmeta.nhills[b];ih++){
    dp2 = 0.;
    for(j=0;j<colvar.nconst;j++){
      if(repmeta.on[j][b]){
        dp[j] = (repmeta.ss0[j][a]-repmeta.ss0_t[ih][j][b])/repmeta.delta_r[ih][j][b];
        dp2 += dp[j]*dp[j];
      }
    }
    dp2 *= 0.5;
    if(dp2<DP2CUTOFF) {
      dp2index = dp2*GTAB/DP2CUTOFF;
      Vhillsba += repmeta.ww[ih][b]*hills.exp[dp2index];
    }
  }

  *Epotab += Vhillsab + repmeta.RVwalls[a]; // b configuration with a hamiltonian 
  *Epotba += Vhillsba + repmeta.RVwalls[b]; // a configuration with b hamiltonian 
  *Epota += repmeta.RVhills[a]+repmeta.RVwalls[a];
  *Epotb += repmeta.RVhills[b]+repmeta.RVwalls[b];

#endif
}
//-------------------------------------------------------------------------------------------------------
void ptmetad_sharepot(int nrepl, int repl)
{
#ifdef MPI
  int i, j;
  if(logical.widthadapt){
    for(i=0;i<colvar.nconst;i++) {
      for(j=0;j<nrepl;j++) {
        repmeta.fluct[i][j] = 0.;
        repmeta.fluct2[i][j] = 0.;
      }
      repmeta.fluct[i][repl] = colvar.Mss0[i];
      repmeta.fluct2[i][repl] = colvar.M2ss0[i];
#ifndef GROMACS4
      gmx_sum(nrepl, repmeta.fluct[i], mtd_data.mcr);
      gmx_sum(nrepl, repmeta.fluct2[i], mtd_data.mcr);
#else
      gmx_sum_sim(nrepl, repmeta.fluct[i], mtd_data.mcr->ms);
      gmx_sum_sim(nrepl, repmeta.fluct2[i], mtd_data.mcr->ms);
#endif
    }
  }

  // cleaning stuff 
  for(i=0;i<nrepl;i++) {
    repmeta.RVwalls[i] = 0.;
    repmeta.RVhills[i] = 0.;
    repmeta.nhills[i] = 0;
  }
  for(j=0;j<colvar.nconst;j++) for(i=0;i<nrepl;i++) repmeta.ss0[j][i] = 0.;
  // sharing hills potential 
  repmeta.RVhills[repl] = Vhills;
#ifndef GROMACS4
  gmx_sum(nrepl, repmeta.RVhills, mtd_data.mcr);
#else
  gmx_sum_sim(nrepl, repmeta.RVhills, mtd_data.mcr->ms);
#endif
  // sharing wall potential 
  repmeta.RVwalls[repl] = Vwall;
#ifndef GROMACS4
  gmx_sum(nrepl, repmeta.RVwalls, mtd_data.mcr);
#else
  gmx_sum_sim(nrepl, repmeta.RVwalls, mtd_data.mcr->ms);
#endif
  // sharing current CVs value
  for(i=0;i<colvar.nconst;i++) {
    repmeta.ss0[i][repl] = colvar.ss0[i];
#ifndef GROMACS4
    gmx_sum(nrepl, repmeta.ss0[i], mtd_data.mcr);
#else
    gmx_sum_sim(nrepl, repmeta.ss0[i], mtd_data.mcr->ms);
#endif
  }
  // sharing number of hills 
  repmeta.nhills[repl] = hills.n_hills;
#ifndef GROMACS4
  gmx_sumli(nrepl, repmeta.nhills, mtd_data.mcr);
#else
  gmx_sumli_sim(nrepl, repmeta.nhills, mtd_data.mcr->ms);
#endif

#endif
}

//-------------------------------------------------------------------------------------------------------------

void ptmetad_exchflut(int repl)
{
  int j;
  
  for(j=0;j<colvar.nconst;j++) {
    colvar.Mss0[j] = repmeta.fluct[j][repl];
    colvar.M2ss0[j] = repmeta.fluct2[j][repl];
  }
}
