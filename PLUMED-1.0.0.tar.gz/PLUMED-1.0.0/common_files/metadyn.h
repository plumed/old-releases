/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#ifndef EXTERNALS
#ifndef NAMD
   #define MYEXT extern
#else
   #define MYEXT
#endif   
#else
   #define MYEXT
#endif
// common header files
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

// NAMD header files and definition
#ifdef NAMD
#define PREFIX GlobalMasterMetaDynamics::
typedef double real;
typedef double rvec[3];
#define snew(ptr,nelem) (ptr)= (nelem==0 ? NULL : (typeof(ptr)) calloc(nelem,sizeof(*(ptr)))) 
#define sfree(ptr) if (ptr != NULL) free(ptr)   
#include "ComputeHomePatches.h"
#include "GlobalMaster.h"
#include "GlobalMasterEasy.h"
#include "NamdTypes.h"
#include "SimParameters.h"
#include "Molecule.h"
#include "Node.h"
#include "Vector.h" 
#include "signal.h"

// GROMACS header files
#elif defined (GROMACS3) || defined (GROMACS4)
#define PREFIX
#include "config.h"
#include "typedefs.h"
#include "smalloc.h"
#include "pbc.h"
#include "vec.h"
#include "physics.h"
#include "network.h"
#include "nrnb.h"
#include "bondf.h"
#include "random.h"
#ifdef GMX_MPI
#define MPI
#include "mpi.h"
#endif
//OPEP headers
#elif OPEP
#define PREFIX
#define TRUE 1 
#include <math.h>
#ifdef MPI
#include "mpi.h"
#endif
typedef double real;
typedef double rvec[3];
#define snew(ptr,nelem) (ptr)= (nelem==0 ? NULL : (typeof(ptr)) calloc(nelem,sizeof(*(ptr)))) 
#define sfree(ptr) if (ptr != NULL) free(ptr)   

//DRIVER HEADERS
#elif DRIVER
#define PREFIX
#define TRUE 1
#include <math.h>
typedef double real;
typedef double rvec[3];
#define snew(ptr,nelem) (ptr)= (nelem==0 ? NULL : (typeof(ptr)) calloc(nelem,sizeof(*(ptr))))
#define sfree(ptr) if (ptr != NULL) free(ptr)

//DL_POLY headers
#elif DL_POLY
#define PREFIX
#define TRUE 0 
#include <math.h>
typedef double real;
typedef double rvec[3];
#define snew(ptr,nelem) (ptr)= (nelem==0 ? NULL : (typeof(ptr)) calloc(nelem,sizeof(*(ptr)))) 
#define sfree(ptr) if (ptr != NULL) free(ptr)   
//AMBER headers
#elif AMBER
#define PREFIX
#define TRUE 0 
#include <math.h>
typedef double real;
typedef double rvec[3];
#define snew(ptr,nelem) (ptr)= (nelem==0 ? NULL : (typeof(ptr)) calloc(nelem,sizeof(*(ptr)))) 
#define sfree(ptr) if (ptr != NULL) free(ptr)   
#endif

// common global structures and definitions
#define nconst_max 20					// fixed maximum number of COLVARS
#define DP2CUTOFF 6.25					// sigma^2 considered for gaussian
#define GTAB 1000000					// mesh for exponential tablature
#define NWMAX 500 
#ifndef M_PI
#define M_PI 3.14159265
#endif
#ifndef M_2PI
#define M_2PI 6.2831853 
#endif
// in case of namd kcal/mol/K 
#if defined (NAMD) || defined (AMBER) || defined (OPEP) || defined (DRIVER)
#define BOLTZ 0.001987191 
// in case of dl_poly 10Joule/mol/K 
#elif defined (DL_POLY)
#define BOLTZ 0.831451115
#endif
// path dimensions
#define MAXATOMS_PATH 160 
#define NMAX_PATH 6 
#define MAXFRAMES_PATH 22 
#define MAXATOMS_RMSD 160
#define MAXCHARS_PATH 40
// cmap 
#define MAXDIM_CMAP 3800 
#define MAXNUM_GROUP 10
#define MAXATOM_GROUP 30
// stackdimension for hills
#define STACKDIM  10000 

#if defined (OPEP) || defined (DRIVER)
typedef struct {
  int nodeid,nnodes;
  int left,right;
  int threadid,nthreads;
} t_commrec;
#endif
// common NAMD/GROMACS interface
struct mtd_data_s
{
   int  natoms;
   real **pos;
   real **vel;
   real **force;
   real *charge;
   real *mass;
   int  repl;
   int  nrepl;
   int  repl_ex_nst;   
   real rte0;
   real rteio;
   real time;
   FILE *fplog;
   char metaFilename[120];
   real dt;
   int  istep;
   int  istep_old;
   real eunit;
   int  *index;
#ifdef GROMACS3   
   const t_commrec *mcr;  
   real cell[3][3];
#elif GROMACS4   
   const t_commrec *mcr;  
   real cell[3][3];
   int  ePBC;
#elif OPEP
   const t_commrec *mcr;
   char log[120];
   int imcon;
#elif DL_POLY
   // straightforward copy of cell 
   real cell[9];
   // periodic cell variable
   int imcon;
#elif AMBER
   // straightforward copy of cell 
   real cell[3];
   // periodic cell variable
   int imcon;
#elif DRIVER
   int imcon;
   real cell[3];
   const t_commrec *mcr;
#endif
};
// other common types 
typedef real arrm[nconst_max];

struct logical_s
{
  int    do_hills;					// hills on/off
  int    widthadapt;
  int    restart_hills;					// restart yes/no
  int    upper[nconst_max];				// upper walls
  int    lower[nconst_max];				// lower walls
  int    steer[nconst_max];				// steering cv on/off
  int    remd;						// replica exchange parallel tempering
  int    rpxm;						// replica exchange metadynamics
  int    commitment;					// committors analysis
  int    print;						// do COLVAR 
  int    welltemp;
  int    lreflect[nconst_max];
  int    ureflect[nconst_max];
  int    debug;
  int    not_same_step;
  int    meta_inp;
};

struct adapt
{
  int    block;
  int    stride;
  int    on;
  real   inf;
  real   sup;
  real   widthmultiplier;                               // Hills width adapt
};

struct colvar_s
{
  int    nconst;					// # CVs
  int    nt_print;					// step for printing colvar and enercv
  int    it;						// PluMeD step counter
  real   delta_r [nconst_max];				// Hills width along CVs
  real   **delta_s;					// Hills width along CVs in time
  struct adapt adapt[nconst_max];                             // adaptive width structure
  real   ff_hills[nconst_max];				// force due to hills
  int    on      [nconst_max];				// hills on/off on a CV
  int    type_s  [nconst_max];				// colvar type (DIST, ...)
  int    nn      [nconst_max];				// used by for numerator exponent
  int    mm      [nconst_max];				// used by for denominator exponent
  real   r_0     [nconst_max];				// used by for binding distance
  real   d_0     [nconst_max];				// used by for binding distance
  int    intpar  [nconst_max][10];                      // array of integers (general use)
  rvec   realpar [nconst_max][10];                      // array of reals (general use)
  rvec   vecpar  [nconst_max][2];                       // array of vecors (general use)
  real   *map0   [nconst_max]; 				// inter e intra contact starting maps
  int    groups  [nconst_max];				// energy groups id, other id
  int    type    [nconst_max];				// type id (beta sheet, alpha elicas, none, ecc..)
  real   Amin    [nconst_max];				// A state for committors analysis
  real   Amax    [nconst_max];				// ""
  real   Bmin    [nconst_max];				// B ""
  real   Bmax    [nconst_max];				// ""
  int    commit;					//
  rvec   *myder  [nconst_max];				// derivatives
  real   ss0     [nconst_max];                          // CVs value 
  real   Mss0    [nconst_max];				// Hills width adapt
  real   M2ss0   [nconst_max];				// Hills width adapt
  real   wtemp;	         				// well tempered temperature
  real   simtemp;                                       // simulation temperature
  real   wfactor;                                       // welltemp factor = wtemp/simtemp
  int    list[nconst_max][4];                           // structure definition for list 
  int    natoms  [nconst_max];
  int    *cvatoms[nconst_max];
  int    logic[nconst_max];
};

struct hills_s
{
  real   wwr;						// Hill height
  real   *ww;						// Hill height history
  long int n_hills;					// Hills added
  int    nt_hills;					// Period in step to add hills
  int    nr_hills;					// Period in step to read hills
  real   **ss0_t;					// Hills center history
  char   dir[100];					// HILLS place
  long int ntothills;					// max number of hills
  real   exp[GTAB];					// table for exponential
  long int read;
};

struct wall
{
  real   upper   [nconst_max];				// upper limit where start the wall
  real   lower   [nconst_max];				// lower limit
  real   lsigma  [nconst_max];				// lower force constant
  real   sigma   [nconst_max];				// upper force constant
  real   fwall   [nconst_max];				// force due to wall
  int    uexp    [nconst_max];				// upper softwall exponent
  int    lexp    [nconst_max];				// lower softwall exponent
  real   ueps    [nconst_max];				// redux factor for upper wall 
  real   leps    [nconst_max];				// redux factor for lower wall 
  real   uoff    [nconst_max];                          // offset for upper wall
  real   loff    [nconst_max];                          // offset for lower wall     
  int    st_inv  [nconst_max];
};

struct steer {
 real    pos     [nconst_max];				// position of umbrella
 real    delta   [nconst_max];				// increment of umbrella along cv
 real    spring  [nconst_max];				// elastic constant of umbrella
 real    max     [nconst_max];				// limit
 real    start   [nconst_max];				// start position
 int     sign    [nconst_max];
 int     impose_start [nconst_max];                      // logical for imposing a starting point
} ;

struct repmeta_s
{
  real   ***delta_r;					// hills width for each replica
  real   ***ss0_t;					// hills center for each replica
  real   **ww;						// hills weight for each replica
  int    **on;						// hills on for each replica
  real   *RVhills;
  real   *RVwalls;
  real   **ss0;
  long int *nhills;
  real   **fluct;
  real   **fluct2;
  fpos_t line_counter;
  int    first;
};
struct rmsd_inpack{
       int natoms;
       real r0[3][MAXATOMS_RMSD];
       real r1[3][MAXATOMS_RMSD];
       real mass[MAXATOMS_RMSD];
};

struct rmsd_outpack{
       real r0p[3][MAXATOMS_RMSD];//centered reference  frame
       real r1p[3][MAXATOMS_RMSD];//centered running frame  
       real cmr0[3]; //center of mass of reference frame
       real cmr1[3]; //center of mass of running frame
       real err;
       real derr_dr0[3][MAXATOMS_RMSD];
       real derr_dr1[3][MAXATOMS_RMSD];
       real dderr_dr1_dr1[3][MAXATOMS_RMSD][3][MAXATOMS_RMSD];
       real dderr_dr0_dr0[3][MAXATOMS_RMSD][3][MAXATOMS_RMSD];
       real dderr_dr1_dr0[3][MAXATOMS_RMSD][3][MAXATOMS_RMSD];
       real dderr_dr0_dr1[3][MAXATOMS_RMSD][3][MAXATOMS_RMSD];
       real d[3][3];
       real dd_dr0[3][3][3][MAXATOMS_RMSD];
       real dd_dr1[3][3][3][MAXATOMS_RMSD];
};
struct rmsd_mini_outpack{
     real r0p[3][MAXATOMS_RMSD];//centered reference  frame
     real r1p[3][MAXATOMS_RMSD];//centered running frame  
     real cmr0[3]; //center of mass of reference frame
     real cmr1[3]; //center of mass of running frame
     real err;
     real derr_dr0[3][MAXATOMS_RMSD];
     real derr_dr1[3][MAXATOMS_RMSD];
     real d[3][3];
     real dd_dr0[3][3][3][MAXATOMS_RMSD];
     real dd_dr1[3][3][3][MAXATOMS_RMSD];
};
// For path in contact map space
struct group_struct{
       int number;
       int numatom[MAXNUM_GROUP];
       int index[MAXNUM_GROUP][MAXATOM_GROUP];
       int index_to_list[MAXNUM_GROUP][MAXATOM_GROUP];
       real rcm[MAXNUM_GROUP][3];
};
struct cmap_pack {
       int index1[MAXDIM_CMAP];
       int index2[MAXDIM_CMAP];       
       int index_from1[MAXDIM_CMAP];
       int index_from2[MAXDIM_CMAP];
       int atoms;
       int list[MAXATOMS_RMSD];
       int nn[MAXDIM_CMAP];
       int nd[MAXDIM_CMAP];
       int number;
       int gnumber;
       real r0[MAXDIM_CMAP];
       real weight[MAXDIM_CMAP];
       real cutoff[MAXDIM_CMAP];
       real cmap[MAXFRAMES_PATH][MAXDIM_CMAP];
       int logical_group;
       struct group_struct group;
       };
struct cmap_inpack{
       real r0[MAXATOMS_PATH][3];
       real cmap[MAXDIM_CMAP];
};
struct cmap_outpack{
       real err;
       real derr_dr0[3][MAXATOMS_PATH];
       real derr_dcm[MAXDIM_CMAP];
};
struct coordinates_frameset {
        int natoms;
        int resid[MAXATOMS_PATH],atmnum[MAXATOMS_PATH];
        char resname[MAXATOMS_PATH][MAXCHARS_PATH];
        char label[MAXATOMS_PATH][MAXCHARS_PATH];
        real pos[MAXATOMS_PATH][3];
        char residue[MAXATOMS_PATH];
        real align[MAXATOMS_PATH];    // for each atom is 1 if used for alignment, else 0
        int displace[MAXATOMS_PATH]; // for each atom is 1 if used for displacement, else 0
        int frameset_to_coord[MAXATOMS_PATH]; // for each atoms in the frameset provides the corresponding index on running coord
        int frameset_to_align[MAXATOMS_PATH]; // for each atoms in the frameset provides the corresponding index used alignment(-1 if not involved in rmsd) 
        int nalign;
        int align_to_coord[MAXATOMS_PATH];
        int align_to_frameset[MAXATOMS_PATH];
        int ndisplace;
        int displaced[MAXATOMS_PATH];
};
struct sz_data {
        int    number;
        real lambda;
        struct coordinates_frameset **frameset;
        char   names[MAXCHARS_PATH];
        int grad_on,umb_on,mass_on;
        real gradmax,gradmin,gradk;
        int umblagsteps,umbblocksize,umbstride,umbcount,umbpermanency,countperm;
        real umbtolerance;
        real ****umb_block;// dimensions:  3,natoms,nframes,nblock
        real ***umb_avg;// dimensions:  3,natoms,nframes
        real ***umb_map_block;// dimensions:  tot_con,nframes,nblock
        real **umb_map_avg;// dimensions:  tot_con,nframes
        struct cmap_pack my_cmap_pack;
        char   path_type[10];
        int nneigh,*lneigh,neigh,neigh_time;
};

// NAMD CLASS DEFINITION AND PECULIAR METHODS
#ifdef NAMD
class GlobalMasterMetaDynamics : public GlobalMasterEasy 
{

 public:
 GlobalMasterMetaDynamics(); 
 virtual void easy_init(const char *);
 void easy_calc(void);
 void mtd_data_init(  );
 void init_metadyn( );
 void rvec2vec(rvec rv,Vector *v);
#elif GROMACS3
 void mtd_data_init (real *charge, real *mass,
                    int natoms, real dt, int repl_ex_nst, int repl,
                    int nrepl, real rte0, real rteio, const t_commrec *mcr, FILE *fplog);

 void init_metadyn(int natoms, real box[3][3], real *charge, real *mass,
                  real dt, int repl_ex_nst, int repl, int nrepl,
                  real rte0, real rteio, const t_commrec *mcr, FILE *fplog);
 void ptmetad(real *Epota, real *Epotb, real *Epotba, real *Epotab, int a, int b);
 void ptmetad_exchflut(int repl);
 void ptmetad_sharepot(int nrepl, int repl);
 void bias_exchange_traj(int nrepl, int *seed, int *ind);
 void meta_force_calculation(real (*pos)[3], real (*force)[3], real (*vel)[3], real box[3][3], int istep);
 void gmx_sumli(int nr,long int r[], const t_commrec *mcr);
#elif GROMACS4
 void mtd_data_init (int ePBC, real *charge, real *mass,
                    int natoms, real dt, int repl_ex_nst, int repl,
                    int nrepl, real rte0, real rteio, const t_commrec *mcr, FILE *fplog);

 void init_metadyn(int natoms, real box[3][3], int ePBC, real *charge, real *mass,
                  real dt, int repl_ex_nst, int repl, int nrepl,
                  real rte0, real rteio, const t_commrec *mcr, FILE *fplog);
 void ptmetad(real *Epota, real *Epotb, real *Epotba, real *Epotab, int a, int b);
 void ptmetad_exchflut(int repl);
 void ptmetad_sharepot(int nrepl, int repl);
 void bias_exchange_traj(int nrepl, int *seed, int *ind);
 void meta_force_calculation(real (*pos)[3], real (*force)[3], real (*vel)[3], real box[3][3], int istep);
 void gmx_sumli_sim(int nr,long int r[], const gmx_multisim_t *ms);
#define oprod cprod
#elif OPEP
 void init_metadyn_(int *atoms, real *ddt, int *pbc_opep,
                   int *repl, int *nrepl,real *rte0, real *rteio, real *mass,
                   char *lpath, char *logfile, char *metainp, int ll, int mm, int jj);
 void meta_force_calculation_(real *pos, real *force);
 real pbc_mic_(real *rin);
 void mtd_data_init(int pbc, real tstep,int atoms, int repl, int nrepl, real rte0, real rteio, real *mass, char *lpath, char *logfile, char *metainp);
 real rando(int *ig);
 void ptmetad(real *Epota, real *Epotb, real *Epotba, real *Epotab, int a, int b);
 void meta_corrections_(int *r1,int *r2, real *delta1, real *delta2);
 void share_bias_(int *nrep, int *task);
 void ptmetad_sharepot(int nrepl, int repl);
 void bias_exchange_traj(int nrepl, int *seed, int *ind);
 void ptmetad_exchflut(int repl);
 void gmx_sum(int nr,real r[], const t_commrec *mcr);
 void gmx_sumi(int nr,int r[], const t_commrec *mcr);
 void gmx_sumli(int nr,long int r[], const t_commrec *mcr);
#elif DL_POLY
 void init_metadyn_(int *atoms, real *ddt, real *mass, real *charge, int *imcon, real *eunit, char *metain, int pp);
 void mtd_data_init(int atoms, real dt , real *mass, real *charge , int *imcon, real *eunit, char *metainp);
 void meta_force_calculation__(real *cell,real *xxx,real *yyy,real *zzz,real *fxx,real *fyy,real *fzz); 
 void images_(int *i,int *j,int *k,int *natoms,real *cell,real *xxx,real *yyy,real *zzz); 
#elif DRIVER
 void init_metadyn_(int *atoms, real *mass, real *charge, int *pbc, real *box, char *metainp, int ll);
 void mtd_data_init(int atoms, real *mass, real *charge, char *metainp, int pbc, real *box);
 void cv_calculation_(real *pos, int *ncv, real *cv);
 real rando(int *ig);
 void ptmetad(real *Epota, real *Epotb, real *Epotba, real *Epotab, int a, int b);
 void ptmetad_sharepot(int nrepl, int repl);
 void bias_exchange_traj(int nrepl, int *seed, int *ind);
 void ptmetad_exchflut(int repl);
#elif AMBER
 void init_metadyn__(int *atoms, real *ddt, real *mass, real *charge ,char *metainp, int ll);
 void mtd_data_init(int atoms,  real ddt , real *mass, real *charge, char *metainp);
 void meta_force_calculation__(real *box,real *rrr,real *fff, int *nn); 
#endif
#if defined (NAMD) || defined (AMBER) || defined (OPEP) || defined (DRIVER) || defined (DL_POLY)
// Vector operation
 void oprod(const rvec a,const rvec b,rvec c);
 real iprod(const rvec a,const rvec b);
 real norm(const rvec a);
 real norm2(const rvec a);
 real cos_angle(const rvec a,const rvec b);
 real dih_angle(rvec xi, rvec xj, rvec xk, rvec xl,
               rvec r_ij,rvec r_kj,rvec r_kl,rvec m,rvec n,
               real *cos_phi,real *sign);
 void clear_rvec(rvec a);
#endif
// common declarations
 void EXIT();
 void read_restraint(struct mtd_data_s *mtd_data);
 void read_defaults(  );
 int  get_words(char *line, char *word[NWMAX]);
 int  seek_word(char *word[NWMAX], char *wanted);
 int  seek_word2(char *word[NWMAX], char *wanted, int is);
 int  check_group(const char *,int **vec,int ,char  meta[120],FILE *fplog);
 void read_single(const char *word, int **vec,int n);
 int  get_atom_list_from(char *word[NWMAX]);
 int  get_atom_list_to(char *word[NWMAX]);
// PBS
 void minimal_image(rvec pos1, rvec pos2, real *mod_rij, rvec rij);
// HILLS stuff
 void hills_add(struct mtd_data_s *mtd_data);
 void hills_force();
 void apply_force(int i_c, struct mtd_data_s *mtd_data );
 void soft_walls_up(int, real);
 void soft_walls_lo(int, real);
 void steer_cv(int);
 void print_colvar_enercv(real time_s);
 void hills_adapt();
 void commit_analysis();
 void read_hills(struct mtd_data_s *mtd_data, int restart, int first_read);
 void hills_reallocate(struct mtd_data_s *mtd_data);
// CV routines
 void restraint(struct mtd_data_s *mtd_data);
 void test_derivatives(struct mtd_data_s *mtd_data);
// reading...
 int  read_dist(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_mindist(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog); 
 int  read_coord(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog); 
 int  read_angle(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_torsion(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_alfabeta(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_hbonds(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_dipole(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_rgyr(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_rmsdtor(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_dihcor(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_waterbridge(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_path(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog);
 int  read_position(char *str, char *word[NWMAX], int count, FILE *file, FILE *fplog); 
// calculating
 void dist_restraint(int i_c, struct mtd_data_s *mtd_data);
 void mindist_restraint(int i_c, struct mtd_data_s *mtd_data);
 void coord_restraint(int i_c, struct mtd_data_s *mtd_data);
 void angle_restraint(int i_c, struct mtd_data_s *mtd_data);
 void torsion_restraint(int i_c,struct mtd_data_s *mtd_data);
 void alfabeta_restraint(int i_c, struct mtd_data_s *mtd_data);
 void hbonds_restraint(int i_c, struct mtd_data_s *mtd_data);
 void dipole_restraint(int i_c, struct mtd_data_s *mtd_data);
 void radgyr_restraint(int i_c, struct mtd_data_s *mtd_data);
 void rmsdtor_restraint(int i_c, struct mtd_data_s *mtd_data);
 void dihcor_restraint(int i_c, struct mtd_data_s *mtd_data);
 void waterbridge_restraint(int i_c, struct mtd_data_s *mtd_data);
 void spath_restraint(int i_c, struct mtd_data_s *mtd_data);
 void zpath_restraint(int i_c, struct mtd_data_s *mtd_data);
 void position_restraint(int i_c, struct mtd_data_s *mtd_data);

// misc routines
 void cmap_running(struct cmap_inpack *inpack, struct cmap_pack *my_cmap_pack);
 void cmdist_eval(int frame,struct cmap_inpack *inpack,struct cmap_outpack *outpack, 
      struct cmap_pack *my_cmap_pack,int dr1_calc);
 real pow2(real x);
 void power(real x,int p,int q,real *xp,real *xq);
 void read_sz_map(struct sz_data *my_sz, char file_maps[129], char file_maps2[129],
                        char file_group[129], FILE *fplog);
 int  read_sz_rmsd(struct sz_data *my_sz, FILE *fplog);
 int  read_sz_coord (char *filename, struct coordinates_frameset *p, FILE *fplog);
 void msd_calculation(struct coordinates_frameset *pframeset,struct cmap_inpack *c_inpack,
                             struct cmap_outpack *c_outpack,real dmsd_dr1[3][MAXATOMS_PATH]);
 int  rmsd_pack(struct rmsd_inpack inpack,struct rmsd_outpack *outpack,int iopt,int iopt2);
 int  rmsd_mini_pack(struct rmsd_inpack inpack,struct rmsd_mini_outpack *outpack,int iopt);
 void mean_rmsd(struct sz_data *pmy_sz, real dCV_dr1[MAXFRAMES_PATH][3][MAXATOMS_PATH],
                        int i_c, FILE *fplog); 
 void mean_map(struct sz_data *pmy_sz, real dCV_dcm[MAXFRAMES_PATH][MAXDIM_CMAP],
                        int i_c, FILE *fplog);
 void dmsd_calculation(int i_c,struct coordinates_frameset *pframeset,struct cmap_inpack *c_inpack,
                             struct cmap_outpack *c_outpack,real dmsd_dr1[3][MAXATOMS_PATH]);
 void cite_please (int re, FILE *fplog);
 void disclaimer (FILE *fplog);
 // allocators and destructors
 real ****float_4d_array_alloc(int i,int j,int k,int l);
 real ***float_3d_array_alloc(int i,int j,int k);
 real **float_2d_array_alloc(int ii,int jj);
 int  **int_2d_array_alloc(int ii,int jj);
 int free_2dr_array_alloc(real **xx,int ii); // 2d real
 int free_3dr_array_alloc(real ***xx,int ii,int jj); // 3d read
 int free_4dr_array_alloc(real ****xx,int ii,int jj, int kk); //4d real
 int free_2di_array_alloc(int **xx,int ii);  //2d integer
 int free_3di_array_alloc(int ***xx,int ii,int jj); //3d integer
 int free_4di_array_alloc(int ****,int ii,int jj, int kk); //4d integer
 // neighbour list tools for quicksorting
 void realquicksort ( real *v , int *ind , int left , int right ); // quicksort for neighbour list search
 void swap (real *v,int *ind,int i,int j); // used by quicksort
 void ql77_driver(real m[][4],real* lambda);
 void ql77 (int n,real *x,real *d);
/* COMMON DATA STRUCTURES  */
    MYEXT struct mtd_data_s    mtd_data;
    MYEXT struct repmeta_s     repmeta;
    MYEXT struct steer         cvsteer;
    MYEXT struct wall          cvw;
    MYEXT struct logical_s     logical;
    MYEXT struct colvar_s      colvar;
    MYEXT struct hills_s       hills;
    MYEXT int   firstTime;					// first PluMed step
    MYEXT int    nwalkers;					// # walkers in parallel
    MYEXT char   colfilen[800];					// COLVAR and ENERCV files
    MYEXT char   hilfilen[800];					// HILLS file
    MYEXT char   locfilen[800];					// LOCK file
    MYEXT real   Vhills;					// Hills potential
    MYEXT real   Vwall;						// Wall potential
// path stuff
    MYEXT struct sz_data my_sz_list[NMAX_PATH];
    MYEXT int ic_to_sz[nconst_max];
    MYEXT int nsz;
    MYEXT int kill_me[nconst_max];
#ifdef DL_POLY
    MYEXT real tstep;
#elif GROMACS3
    MYEXT t_pbc  metapbc;
#elif GROMACS4
    MYEXT t_pbc  metapbc;
    typedef struct gmx_repl_ex {
      int  repl;
      int  nrepl;
      real temp;
      int  type;
      real *q;
      bool bNPT;
      real *pres;
      int  *ind;
      int  nst;
      int  seed;
      int  nattempt[2];
      real *prob_sum;
      int  *nexchange;
    } t_gmx_repl_ex;
#elif NAMD
};
#endif
