/*
*******************************************************************************
*                                                                             *
*                                PLUMED                                       *
*   A Portable Plugin for Free Energy Calculations with Molecular Dynamics    *
*                              VERSION 1.0                                    *
*                                                                             *
*******************************************************************************
*
*  
*  Copyright (c) 2009 The PLUMED team.
*  See http://merlino.mi.infn.it/plumed for more information. 
*
*  This file is part of PLUMED.
*
*  PLUMED is free software: you can redistribute it and/or modify
*  it under the terms of the GNU Lesser General Public License as 
*  published by the Free Software Foundation, either version 3 of 
*  the License, or (at your option) any later version.
*
*  PLUMED is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General
*  Public License along with PLUMED.  
*  If not, see <http://www.gnu.org/licenses/>.
*
*  For more info, see:  http://merlino.mi.infn.it/plumed
*  or subscribe to plumed-users@googlegroups.com
*
*/
#include "metadyn.h"

// This routine calculates, from the variaton of a collective variable, the width
// of the gaussian hills along the CV direction.

void PREFIX hills_adapt()
{
  real fluct, step;
  real Mss02, M2ss0;
  int i_c;

  for(i_c=0;i_c<colvar.nconst;i_c++){
   if(colvar.adapt[i_c].on){ 
// Time for recording fluctuations???
    if((logical.not_same_step) && colvar.it%colvar.adapt[i_c].stride==0 && !firstTime ){
      colvar.Mss0[i_c] += colvar.ss0[i_c];
      colvar.M2ss0[i_c] += colvar.ss0[i_c]*colvar.ss0[i_c];
    }
// Time for evaluating width???    
    if((logical.not_same_step) && colvar.it%colvar.adapt[i_c].block==0 && !firstTime ){
      step = (real) colvar.adapt[i_c].stride / colvar.adapt[i_c].block;      
      M2ss0 = colvar.M2ss0[i_c]*step;
      Mss02 = colvar.Mss0[i_c]*colvar.Mss0[i_c]*step*step;  
      if(M2ss0>Mss02) fluct = sqrt(M2ss0-Mss02);
      else fluct = 0.;
      colvar.delta_r[i_c] = colvar.adapt[i_c].widthmultiplier*fluct;
      if(colvar.delta_r[i_c] > colvar.adapt[i_c].sup) colvar.delta_r[i_c] = colvar.adapt[i_c].sup;
      if(colvar.delta_r[i_c] < colvar.adapt[i_c].inf) colvar.delta_r[i_c] = colvar.adapt[i_c].inf;
      colvar.M2ss0[i_c] = 0.;
      colvar.Mss0[i_c] = 0.;
    }
   }
  }
}

//------------------------------------------------------------------------------------------

// This routine add the gaussian hills
void PREFIX hills_add(struct mtd_data_s *mtd_data)

{
  int i, done, wall;
  FILE *file;
  real inv_ss0[nconst_max];

  wall = 0;

  if(hills.n_hills+10>hills.ntothills){
          //  fprintf(mtd_data->fplog,"MAXIMUM NUMBER OF HILLS REACHED hills.ntothills\n" ); EXIT();
            hills_reallocate(mtd_data); 
            //EXIT() ;
  }

  if(logical.welltemp) {
    hills_force();
    hills.ww[hills.n_hills] = hills.wwr*exp(-Vhills/(BOLTZ*(colvar.wfactor-1.0)*colvar.simtemp));
    for(i=0;i<colvar.nconst;i++) colvar.ff_hills[i] = 0.;
    Vhills = 0.; 
  } else hills.ww[hills.n_hills] = hills.wwr;	// new hill height 

  if(logical.remd){
    repmeta.ww[hills.n_hills][mtd_data->repl] = hills.ww[hills.n_hills];
#ifdef MPI
#ifndef GROMACS4
    gmx_sum(mtd_data->nrepl, repmeta.ww[hills.n_hills], mtd_data->mcr);
#else
    gmx_sum_sim(mtd_data->nrepl, repmeta.ww[hills.n_hills], mtd_data->mcr->ms);
#endif
#endif
  }

  if(nwalkers>1){				// multiple walkers sincronization 
    done = 0;
    while(!done){				// waiting for LOCFILE to disapper 
      file = fopen(locfilen, "r");		// checking LOCFILE 
      if(!file){                                 
        file = fopen(locfilen, "wt");
        fclose(file);
	done = 1;
      }
    }
  }

  file = fopen(hilfilen, "at");
  fprintf(file, "%10.3f   ", mtd_data->time);
  for(i=0;i<colvar.nconst;i++) {
    hills.ss0_t[hills.n_hills][i] = colvar.ss0[i];	// new hill center
    if(colvar.on[i]) fprintf(file, "%10.5f   ", hills.ss0_t[hills.n_hills][i]);
  }

//  for(i=0;i<=hills.n_hills;i++) fprintf(mtd_data->fplog, "ADDING # %i HILLS %f %f \n",i,hills.ss0_t[i][0],hills.ss0_t[i][1]);

  for(i=0;i<colvar.nconst;i++) {
    colvar.delta_s[hills.n_hills][i] = colvar.delta_r[i];	// new hill width
    if(colvar.on[i]) fprintf(file, "%10.5f   ", colvar.delta_s[hills.n_hills][i]);
    if(logical.remd){
      repmeta.ss0_t[hills.n_hills][i][mtd_data->repl] = colvar.ss0[i];
      repmeta.delta_r[hills.n_hills][i][mtd_data->repl] = colvar.delta_r[i];
#ifdef MPI
#ifndef GROMACS4
      gmx_sum(mtd_data->nrepl, repmeta.ss0_t[hills.n_hills][i], mtd_data->mcr);
      gmx_sum(mtd_data->nrepl, repmeta.delta_r[hills.n_hills][i], mtd_data->mcr);
#else
      gmx_sum_sim(mtd_data->nrepl, repmeta.ss0_t[hills.n_hills][i], mtd_data->mcr->ms);
      gmx_sum_sim(mtd_data->nrepl, repmeta.delta_r[hills.n_hills][i], mtd_data->mcr->ms);
#endif
#endif
    }
  }

  if(logical.welltemp){
   fprintf(file, "%10.5f   %4.3f \n", hills.ww[hills.n_hills]*colvar.wfactor/(colvar.wfactor-1.0)/mtd_data->eunit,colvar.wfactor);
  } else {
   fprintf(file, "%10.5f   %4.3f \n", hills.ww[hills.n_hills]/mtd_data->eunit,0.0);
  } 
  
  hills.n_hills++;                              // hills added

  for(i=0;i<colvar.nconst;i++) {
    inv_ss0[i] = colvar.ss0[i];
    
    if(logical.ureflect[i] && colvar.ss0[i]>(cvw.upper[i]-colvar.delta_r[i]) && 
       colvar.ss0[i]<cvw.upper[i] && colvar.on[i]) { inv_ss0[i] = 2.*cvw.upper[i]-colvar.ss0[i]; wall=1;}
    else if(logical.lreflect[i] && colvar.ss0[i]<(cvw.lower[i]+colvar.delta_r[i]) && 
       colvar.ss0[i]>cvw.lower[i] && colvar.on[i]) { inv_ss0[i] = 2.*cvw.lower[i]-colvar.ss0[i]; wall=1;}
  }

  if(wall) {
    hills.ww[hills.n_hills] = hills.ww[hills.n_hills-1];

    if(logical.remd){
      repmeta.ww[hills.n_hills][mtd_data->repl] = hills.ww[hills.n_hills];
#ifdef MPI
#ifndef GROMACS4
      gmx_sum(mtd_data->nrepl, repmeta.ww[hills.n_hills], mtd_data->mcr);
#else
      gmx_sum_sim(mtd_data->nrepl, repmeta.ww[hills.n_hills], mtd_data->mcr->ms);
#endif
#endif
    }

    fprintf(file, "%10.3f   ", mtd_data->time);
    for(i=0;i<colvar.nconst;i++) {
      hills.ss0_t[hills.n_hills][i] = inv_ss0[i];      // new hill center
      if(colvar.on[i]) fprintf(file, "%10.5f   ", hills.ss0_t[hills.n_hills][i]);
    }

    for(i=0;i<colvar.nconst;i++) {
      colvar.delta_s[hills.n_hills][i] = colvar.delta_r[i];       // new hill width
      if(colvar.on[i]) fprintf(file, "%10.5f   ", colvar.delta_s[hills.n_hills][i]);
      if(logical.remd){
        repmeta.ss0_t[hills.n_hills][i][mtd_data->repl] = inv_ss0[i];
        repmeta.delta_r[hills.n_hills][i][mtd_data->repl] = colvar.delta_r[i];
#ifdef MPI
#ifndef GROMACS4
        gmx_sum(mtd_data->nrepl, repmeta.ss0_t[hills.n_hills][i], mtd_data->mcr);
        gmx_sum(mtd_data->nrepl, repmeta.delta_r[hills.n_hills][i], mtd_data->mcr);
#else
        gmx_sum_sim(mtd_data->nrepl, repmeta.ss0_t[hills.n_hills][i], mtd_data->mcr->ms);
        gmx_sum_sim(mtd_data->nrepl, repmeta.delta_r[hills.n_hills][i], mtd_data->mcr->ms);
#endif
#endif
      }
    
      wall=0;
    }

    fprintf(file, "%10.5f\n", hills.ww[hills.n_hills]);
    hills.n_hills++;                              // hills added
  }

  fclose(file);

  if(nwalkers>1) remove(locfilen);
}

//-----------------------------------------------------------------------------------------------

// This routine calculate the hills contribution
void PREFIX hills_force()
{
  long int ih, i, dp2index;
  real dp2, dp[nconst_max], VhillsLast, diff;

  for(ih=0;ih<hills.n_hills;ih++){
     dp2 = 0.;
     for(i=0;i<colvar.nconst;i++){
       if(colvar.on[i]){
         dp[i] = (colvar.ss0[i]-hills.ss0_t[ih][i])/colvar.delta_s[ih][i];	// (cv(now)-hil(ih))/sigma
         if(colvar.type_s[i]==5) {
            diff = colvar.ss0[i]-hills.ss0_t[ih][i];
            if(diff>M_PI) diff-=2.*M_PI;
            else if(diff<-M_PI) diff+=2.*M_PI;
            dp[i] = diff/colvar.delta_s[ih][i];
         }
         dp2 += dp[i]*dp[i];			// sum dp*dp
       }
     }
     dp2 = 0.5*dp2;
     if(dp2<DP2CUTOFF){
       //VhillsLast = hills.ww[ih]*exp(-dp2);						// last hill potential
       //printf("norm = %f ", VhillsLast);
       dp2index =  dp2*GTAB/DP2CUTOFF;
       VhillsLast = hills.ww[ih]*hills.exp[dp2index];
       //printf("tab = %f , dp2 %f , dp2index %i\n", VhillsLast, dp2, dp2index);
       //fflush(stdout);
       Vhills += VhillsLast;                                                            // hills potential energy
       for(i=0;i<colvar.nconst;i++) 
         if(colvar.on[i]) colvar.ff_hills[i] += dp[i]/colvar.delta_s[ih][i]*VhillsLast;	// -dU/dCV 
     }
   }
}

//-----------------------------------------------------------------------------------------------

// This routine read the HILLS file
void PREFIX read_hills(struct  mtd_data_s *mtd_data, int restart, int first_read)
{
  double dummy;//,old_factor;
  int i,j,nactive;
  long int line, ix;
  FILE *file;
  char *str, stringa[800];
  
  /***************************** *RESTARTING *************************/
  if(restart){									         	// restarting with hill
        file = fopen(hilfilen, "r");								// open
        fflush(file);										// open
        if(file==NULL) {										// not exist
          fprintf(stderr, "!!!!!! Cannot read HILLS file :: %s\n", hilfilen);
          EXIT();
        }
        line = 0;
        while(1){											// read cycle
          str = fgets(stringa, 800, file);
          if(str == NULL){										// end of file
            fclose(file);
            break;
          }
          line++;											// line counter
        }
        
        hills.ntothills =  ceil( line / STACKDIM  + 1 ) * STACKDIM ; 
        //fprintf(mtd_data->fplog,"ALLOCATION VALS %d\n",hills.ntothills ); 
        hills.ss0_t     = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst); 
        hills.ww        = (real *) calloc(hills.ntothills,sizeof(real));
        colvar.delta_s  = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst);   
        if(logical.remd){
            repmeta.ww      = float_2d_array_alloc(hills.ntothills,mtd_data->nrepl);  
            repmeta.delta_r = float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data->nrepl);  
            repmeta.ss0_t   = float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data->nrepl); 
            repmeta.RVhills = (real *)calloc(mtd_data->nrepl,sizeof(real));
            repmeta.RVwalls = (real *)calloc(mtd_data->nrepl,sizeof(real));
            repmeta.ss0     = float_2d_array_alloc(colvar.nconst,mtd_data->nrepl);
            repmeta.nhills  = (long int *)calloc(mtd_data->nrepl,sizeof(long int));
            if(logical.widthadapt){
                repmeta.fluct   = float_2d_array_alloc(colvar.nconst,mtd_data->nrepl);
                repmeta.fluct2  = float_2d_array_alloc(colvar.nconst,mtd_data->nrepl);
            }
        }
        repmeta.first=0;  
  }
  /****************************** END RESTARTING *************************/

  file = fopen(hilfilen, "r");									// open

  /****************************** UPDATING *************************/
  if(!restart && !first_read)fsetpos(file,&(repmeta.line_counter));

  fflush(file);											// open
  if(file==NULL) {										// not exist
    fprintf(stderr, "!!!!!!  Cannot read HILLS file :: %s !!!!!\n", hilfilen);
    EXIT();
  }

  line = hills.read;

  int active_to_ind[nconst_max];
  nactive=0.; //number of active cvs 
  for(i=0;i<colvar.nconst;i++){
     if(colvar.on[i]){active_to_ind[nactive]=i;nactive++;}
  }

  while(1){											// read cycle
    str = fgets(stringa, 800, file);
    if(str == NULL){
      break;
    }

    // reallocate if needed during reading
    if(line+10>hills.ntothills) hills_reallocate(mtd_data);  

    j=0;
    str =(char *) strtok(stringa," ");
    while (str != NULL)
    {
      if( j>0 && j <=nactive  ) { 
          i=active_to_ind[j-1];
          sscanf(str, "%lf", &dummy);
          hills.ss0_t[line][i] = (real) dummy; 
          if(logical.remd) repmeta.ss0_t[line][i][mtd_data->repl] = hills.ss0_t[line][i];
      //    printf("POS %d   %f ",i,  hills.ss0_t[line][i] );
      }
      else if( j>nactive && j<= 2*nactive ) { 
          i=active_to_ind[j-nactive-1];
          sscanf(str, "%lf", &dummy);
          colvar.delta_s[line][i] = (real) dummy;							// read the hills dimension
          if(logical.remd) repmeta.delta_r[line][i][mtd_data->repl] = colvar.delta_s[line][i];
      //    printf("DELTA %d   %f ",i, colvar.delta_s[line][i]);
      }
      else if(j==2*nactive+1) { 
         sscanf(str, "%lf", &dummy);
         if(logical.welltemp){
            //str =(char *) strtok(NULL, " ");
            //sscanf(str, "%lf", &old_factor);
            hills.ww[line] = ((real) dummy) * mtd_data->eunit * (colvar.wfactor-1.0) / colvar.wfactor;          		// read the hills height
         } else {
            hills.ww[line] = (real) dummy * mtd_data->eunit;                                                              // read the hills height
         }
         if(logical.remd) repmeta.ww[line][mtd_data->repl] = hills.ww[line];
      //   printf("WW   %f \n", hills.ww[line]);
      }
      str =(char *) strtok(NULL, " ");
      j++;
    }
      
    line++;
  }
  
  fgetpos(file,&(repmeta.line_counter));

  fclose(file);
  hills.n_hills = line;

  if(restart){
    fprintf(mtd_data->fplog, "|- RESTARTING HILLS: # read %li \n",hills.n_hills);
  }else{
    fprintf(mtd_data->fplog, "|- UPDATING HILLS @ %lf fs from %li to %li : TOT %li HILLS read!\n", mtd_data->time,hills.read,hills.n_hills-1,hills.n_hills-hills.read);
  }
  hills.read=hills.n_hills;

//  for(i=hills.read;i<hills.n_hills;i++) fprintf(mtd_data->fplog, "UPDATING # %i HILLS %f %f \n",i,hills.ss0_t[i][0],hills.ss0_t[i][1]);
//  for(i=0;i<hills.n_hills;i++) fprintf(mtd_data->fplog, "AFTER UPDATE # %i HILLS %f %f \n",i,hills.ss0_t[i][0],hills.ss0_t[i][1]);
  fprintf(mtd_data->fplog,"\n");
  fflush(mtd_data->fplog);

#ifdef MPI
  if(logical.remd) {
    for(ix=0;ix<hills.n_hills;ix++){
        for(i=0;i<colvar.nconst;i++){
#ifndef GROMACS4
        gmx_sum(mtd_data->nrepl, repmeta.ss0_t[ix][i], mtd_data->mcr);
        gmx_sum(mtd_data->nrepl, repmeta.delta_r[ix][i], mtd_data->mcr);
#else
        gmx_sum_sim(mtd_data->nrepl, repmeta.ss0_t[ix][i], mtd_data->mcr->ms);
        gmx_sum_sim(mtd_data->nrepl, repmeta.delta_r[ix][i], mtd_data->mcr->ms);
#endif
      }
#ifndef GROMACS4
      gmx_sum(mtd_data->nrepl, repmeta.ww[ix], mtd_data->mcr);
#else
      gmx_sum_sim(mtd_data->nrepl, repmeta.ww[ix], mtd_data->mcr->ms);
#endif
    }
  }
#endif
}

//------------------------------------------------------------------------------------------

void PREFIX hills_reallocate( struct mtd_data_s *mtd_data) { 
      int i,j,k,oldtot;
      real  **ss0_t_tmp;
      real  *ww_tmp;
      real  **delta_s_tmp; 
      real  ***ss0_t_tmp_r;
      real  **ww_tmp_r;
      real  ***delta_s_tmp_r; 

      fprintf(mtd_data->fplog,"ENTERED REALLOCATION\n" );
      fprintf(mtd_data->fplog,"OLDALLOCATION DIMENSION %lu\n",hills.ntothills );
      oldtot=hills.ntothills;
      // allocate  
      ss0_t_tmp     = (real **)float_2d_array_alloc(oldtot,colvar.nconst);   ;
      ww_tmp        = (real *) calloc(oldtot,sizeof(real));
      delta_s_tmp   = (real **)float_2d_array_alloc(oldtot,colvar.nconst);          
      // copy values
      for (i=0;i<hills.n_hills;i++){
            ww_tmp[i]=hills.ww[i];  
            for (j=0;j<colvar.nconst;j++){
               ss0_t_tmp[i][j]=hills.ss0_t[i][j]; 
            }
            for (j=0;j<colvar.nconst;j++){
               delta_s_tmp[i][j]=colvar.delta_s[i][j]; 
            }
      } 
      // deallocate
      free(hills.ww);
      free_2dr_array_alloc(hills.ss0_t,oldtot);
      free_2dr_array_alloc(colvar.delta_s,oldtot);
      // reallocate to the new stackdim
      hills.ntothills+=STACKDIM ;
      hills.ss0_t     = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst); 
      hills.ww        = (real *) calloc(hills.ntothills,sizeof(real));
      colvar.delta_s  = (real **)float_2d_array_alloc(hills.ntothills,colvar.nconst);   
      // copy back 
      for (i=0;i<hills.n_hills;i++){
            hills.ww[i]=ww_tmp[i];  
            for (j=0;j<colvar.nconst;j++){
               hills.ss0_t[i][j]=ss0_t_tmp[i][j]; 
            }
            for (j=0;j<colvar.nconst;j++){
               colvar.delta_s[i][j]=delta_s_tmp[i][j]; 
            }
      } 
      // free temporary vectors 
      free(ww_tmp);
      free_2dr_array_alloc(ss0_t_tmp,oldtot);
      free_2dr_array_alloc(delta_s_tmp,oldtot);
      // and the current replica ???? 
      if(logical.remd){
           ww_tmp_r        = (real **) float_2d_array_alloc(oldtot,mtd_data->nrepl);
           ss0_t_tmp_r     = (real ***)float_3d_array_alloc(oldtot,colvar.nconst,mtd_data->nrepl);
           delta_s_tmp_r   = (real ***)float_3d_array_alloc(oldtot,colvar.nconst,mtd_data->nrepl);          
           // copy values 
           for (i=0;i<hills.n_hills;i++){
                 for(k=0;k<mtd_data->nrepl;k++){
                     ww_tmp_r[i][k]=repmeta.ww[i][k];  
                 }
                 for (j=0;j<colvar.nconst;j++){
                     for(k=0;k<mtd_data->nrepl;k++){
                         ss0_t_tmp_r[i][j][k]=repmeta.ss0_t[i][j][k]; 
                         delta_s_tmp_r[i][j][k]=repmeta.delta_r[i][j][k]; 
                     }  
                 }
           } 
           // deallocate
           free_2dr_array_alloc(repmeta.ww,oldtot);
           free_3dr_array_alloc(repmeta.ss0_t,oldtot,colvar.nconst);
           free_3dr_array_alloc(repmeta.delta_r,oldtot,colvar.nconst);
           // reallocate to the new stackdim
           repmeta.ww        = (real **)float_2d_array_alloc(hills.ntothills,mtd_data->nrepl);
           repmeta.ss0_t     = (real ***)float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data->nrepl); 
           repmeta.delta_r   = (real ***)float_3d_array_alloc(hills.ntothills,colvar.nconst,mtd_data->nrepl);   
           // copy values 
           for (i=0;i<hills.n_hills;i++){
                 for(k=0;k<mtd_data->nrepl;k++){
                     repmeta.ww[i][k]=ww_tmp_r[i][k];  
                 }
                 for (j=0;j<colvar.nconst;j++){
                     for(k=0;k<mtd_data->nrepl;k++){
                       repmeta.ss0_t[i][j][k]=  ss0_t_tmp_r[i][j][k]  ;  
                       repmeta.delta_r[i][j][k]= delta_s_tmp_r[i][j][k] ;  
                     }  
                 }
           } 
           // deallocate
           free_2dr_array_alloc(ww_tmp_r,oldtot);
           free_3dr_array_alloc(ss0_t_tmp_r,oldtot,colvar.nconst);
           free_3dr_array_alloc(delta_s_tmp_r,oldtot,colvar.nconst);
 
 
      }
      fprintf(mtd_data->fplog,"NEWALLOCATION DIMENSION %lu\n",hills.ntothills );
      fprintf(mtd_data->fplog,"END REALLOCATION\n" );
}
